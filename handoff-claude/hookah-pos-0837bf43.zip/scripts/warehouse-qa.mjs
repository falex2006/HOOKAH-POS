import assert from 'node:assert/strict';
const base = process.argv[2] || 'http://127.0.0.1:3107';
if (!['127.0.0.1','localhost'].includes(new URL(base).hostname)) throw Error('Use isolated local QA server');
let checks = 0;
const qaSuffix = Date.now();
async function req(path, method='GET', data, status=200) {
 const response = await fetch(base+path,{method,headers:{'Content-Type':'application/json'},body:data===undefined?undefined:JSON.stringify(data)});
 const result = await response.json(); assert.equal(response.status,status,`${method} ${path}: ${JSON.stringify(result)}`); checks++; return result;
}
const fields={name:`QA — Сироп ${qaSuffix}`,unit:'мл',department:'bar',itemType:'ingredient',cost:0.5,minLevel:20,packMultiplier:1000,purchaseUnit:'бутылка'};
const item=await req('/api/inventory/items','POST',fields,201);
try {
 await req('/api/inventory/items','POST',{...fields,packMultiplier:0},400);
 await req(`/api/inventory/items/${item.id}`,'PATCH',{onHand:999,id:'hijack'},400);
 await req(`/api/inventory/items/${item.id}`,'PATCH',{cost:-1},400);
 await req(`/api/inventory/items/${item.id}`,'PATCH',{name:'QA — Сироп обновлён',itemType:'consumable',purchaseUnit:'канистра',packMultiplier:500});
 await req('/api/inventory/supplies','POST',{itemId:item.id,quantity:2,unit:'кг',unitCost:100},400);
 await req('/api/inventory/movements','POST',{itemId:item.id,delta:2,unit:'кг',reason:'QA несовместимая единица'},400);
 await req('/api/inventory/movements','POST',{itemId:item.id,delta:100,reason:'QA поставка'},201);
 await req('/api/inventory/movements','POST',{itemId:item.id,delta:-30,reason:'QA списание'},201);
 await req('/api/inventory/movements','POST',{itemId:item.id,delta:-100,reason:'QA сверх остатка'},409);
 const stock=await req('/api/inventory'); assert.equal(stock.items.find(x=>x.id===item.id).onHand,70); checks++;
 await req(`/api/inventory/items/${item.id}`,'PATCH',{unit:'кг'},409);
 await req(`/api/inventory/items/${item.id}`,'DELETE',undefined,409);
 await req('/api/inventory/movements','POST',{itemId:item.id,delta:-70,reason:'QA очистка'},201);
 const supply=await req('/api/inventory/supplies','POST',{itemId:item.id,quantity:2,unit:'л',unitCost:100,supplier:'QA поставщик'},201);
 assert.equal(supply.sourceUnit,'л'); assert.equal(supply.unit,'мл'); checks++;
 await req('/api/inventory/movements','POST',{itemId:item.id,delta:-2000,reason:'QA очистка поставки'},201);
 const autoOrder = await req('/api/inventory/auto-orders');
 assert.ok(autoOrder.items.some((entry) => entry.id === item.id), 'low stock item must appear in auto-order suggestions'); checks++;
 const request = await req('/api/inventory/auto-orders','POST',{items:[{itemId:item.id,quantity:500}],note:'QA автозаказ'},201);
 assert.equal(request.status,'sent'); assert.equal(request.lines[0].receivedQuantity,0); checks++;
 await req(`/api/inventory/auto-orders/${request.id}`,'PATCH',{status:'received'},409);
 await req(`/api/inventory/auto-orders/${request.id}`,'PATCH',{status:'partially_received',receipts:[{itemId:item.id,quantity:250}]},409);
 assert.equal((await req('/api/inventory')).items.find((entry) => entry.id === item.id).onHand,0); checks++;
 await req(`/api/inventory/auto-orders/${request.id}`,'PATCH',{status:'cancelled'},200);
 await req(`/api/inventory/auto-orders/${request.id}`,'PATCH',{status:'received',receipts:[{itemId:item.id,quantity:1}]},409);
} finally { await req(`/api/inventory/items/${item.id}`,'DELETE'); }
const category=await req('/api/product-categories','POST',{name:`QA категория ${qaSuffix}`,department:'bar'},201);
const product=await req('/api/products','POST',{name:`QA напиток ${qaSuffix}`,category:category.name,price:150},201);
await req(`/api/products/${product.id}`,'PATCH',{price:175});
await req(`/api/products/${product.id}`,'DELETE');
await req(`/api/product-categories/${category.id}`,'DELETE');
 const recipeIngredient=await req('/api/inventory/items','POST',{name:`QA — Вода для техкарты ${qaSuffix}`,unit:'мл',itemType:'ingredient',cost:0.01},201);
 await req('/api/recipes','POST',{name:`QA без выхода ${qaSuffix}`,ingredients:[{ingredientId:recipeIngredient.id,name:recipeIngredient.name,quantity:'100 мл'}]},400);
 const recipe=await req('/api/recipes','POST',{name:`QA рецепт ${qaSuffix}`,ingredients:[{ingredientId:recipeIngredient.id,name:recipeIngredient.name,quantity:'100 мл'}],yieldQuantity:1,yieldUnit:'порция',portionCount:1},201);
assert.equal(recipe.yieldQuantity,1); assert.equal(recipe.yieldUnit,'порция'); assert.equal(recipe.portionCount,1); checks++;
await req(`/api/recipes/${recipe.id}`,'PATCH',{yieldQuantity:2,yieldUnit:'л',portionCount:4});
await req(`/api/recipes/${recipe.id}`,'PATCH',{yieldUnit:'мл'});
const outputPatched=(await req('/api/recipes')).items.find(x=>x.id===recipe.id); assert.equal(outputPatched.yieldQuantity,2); assert.equal(outputPatched.yieldUnit,'мл'); assert.equal(outputPatched.portionCount,4); checks++;
await req(`/api/recipes/${recipe.id}`,'PATCH',{yieldQuantity:0},400);
await req(`/api/recipes/${recipe.id}`,'PATCH',{name:`QA рецепт изменён ${qaSuffix}`,technology:'Смешать'});
await req(`/api/recipes/${recipe.id}`,'PATCH',{name:'Should not persist',technology:'x'.repeat(4001)},400);
assert.equal((await req('/api/recipes')).items.find(x=>x.id===recipe.id).name,`QA рецепт изменён ${qaSuffix}`);checks++;
 await req(`/api/recipes/${recipe.id}`,'DELETE');
 await req(`/api/inventory/items/${recipeIngredient.id}`,'DELETE');
const costItem=await req('/api/inventory/items','POST',{name:`QA — Вода ${qaSuffix}`,unit:'мл',itemType:'ingredient',cost:0.5},201);
try {
 const costRecipe=await req('/api/recipes','POST',{name:`QA конвертация ${qaSuffix}`,ingredients:[{ingredientId:costItem.id,name:costItem.name,quantity:'2 л'}],yieldQuantity:2,yieldUnit:'л',portionCount:1},201);
 const cost=await req(`/api/recipes/${costRecipe.id}/cost`);
 assert.equal(cost.lines[0].quantity,2000); assert.equal(cost.lines[0].unit,'мл'); assert.equal(cost.totalCost,1000); assert.equal(cost.costPerPortion,1000); checks++;
 await req(`/api/recipes/${costRecipe.id}`,'DELETE');
} finally { await req(`/api/inventory/items/${costItem.id}`,'DELETE'); }
console.log(`WAREHOUSE QA: ${checks} checks passed`);
