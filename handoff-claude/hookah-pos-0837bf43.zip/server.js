const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { createRepositories, allocatePremixBatchConsumption } = require('./db');
const { scaleBatchRecipeIngredients } = require('./recipe-depletion');
const { validateDataUrl: validatePurchasePaymentDocument } = require('./purchase-document-validation');
const { isValidIsoDate, countInclusiveDays, calculatePayrollAmount, canTransitionPayroll } = require('./payroll');
const isValidIsoTimestamp = (value) => {
  if (typeof value !== 'string' || !value.trim()) return false;
  const text = value.trim();
  const match = text.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?(Z|[+-]\d{2}:\d{2})$/);
  if (!match) return false;
  const [, year, month, day, hour, minute, second = '00', , offset] = match;
  if (Number(hour) > 23 || Number(minute) > 59 || Number(second) > 59 || (offset !== 'Z' && (Number(offset.slice(1, 3)) > 23 || Number(offset.slice(4)) > 59))) return false;
  const calendar = new Date(Date.UTC(Number(year), Number(month) - 1, Number(day)));
  if (calendar.getUTCFullYear() !== Number(year) || calendar.getUTCMonth() !== Number(month) - 1 || calendar.getUTCDate() !== Number(day)) return false;
  return !Number.isNaN(Date.parse(text));
};
const scryptAsync = require('util').promisify(crypto.scrypt);
const catalogSeed = require('./catalog-seed');

function normalizeTaskDeadline(input) {
  const changed = input.dueDate !== undefined || input.dueAt !== undefined;
  if (!changed) return { changed: false };
  const present = (value) => value !== undefined && value !== null && value !== '';
  const validDay = (value) => typeof value === 'string' && /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(value)
    && value.slice(0, 4) !== '0000' && Number.isFinite(Date.parse(`${value}T00:00:00Z`))
    && new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value;
  if (present(input.dueDate) && present(input.dueAt)) return { error: 'invalid_task_deadline' };
  if (present(input.dueDate)) return validDay(input.dueDate)
    ? { changed, dueDate: input.dueDate, dueAt: null } : { error: 'invalid_task_due_date' };
  if (!present(input.dueAt)) return { changed, dueDate: null, dueAt: null };
  if (validDay(input.dueAt)) return { changed, dueDate: input.dueAt, dueAt: null };
  const match = typeof input.dueAt === 'string' && input.dueAt.match(/^([0-9]{4}-[0-9]{2}-[0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})(?:\.[0-9]{1,6})?(Z|[+-]([0-9]{2}):([0-9]{2}))$/);
  if (!match || !validDay(match[1]) || Number(match[2]) > 23 || Number(match[3]) > 59 || Number(match[4]) > 59
      || (match[5] !== 'Z' && (Number(match[6]) > 23 || Number(match[7]) > 59)) || !Number.isFinite(Date.parse(input.dueAt))) {
    return { error: 'invalid_task_due_at' };
  }
  return { changed, dueDate: null, dueAt: input.dueAt };
}

const root = __dirname;
// Local development convenience: load ignored .env without adding a runtime dependency.
try {
  const envPath = path.join(root, '.env');
  if (fs.existsSync(envPath)) {
    for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
      const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
      if (match && process.env[match[1]] === undefined) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
    }
  }
} catch (_) {}
const repositories = createRepositories();
const firstRunSetupEnabled = process.env.FIRST_RUN_SETUP_ENABLED === 'true';
const orderRepository = repositories?.orders || null;
const sessionRepository = repositories?.sessions || null;
// The selected network point is process-wide for the current local POS server.
// It starts from VENUE_ID and is updated by the network selector so subsequent
// floor, orders, inventory and reporting requests use the selected point.
let defaultVenueDbId = process.env.VENUE_ID || '00000000-0000-0000-0000-000000000001';
const venue = {
  id: 'venue-territory', name: 'Территория', format: 'кальян-бар', city: 'Тюмень',
  address: 'ул. Пермякова, 77, этаж -1', phone: '+7 (996) 641-95-10', logoUrl: null,
  timezone: 'Asia/Yekaterinburg', vipRoomMinimums: { vip_room_1: 1500, vip_room_2: 2500 }
};
const integrations = {
  telegram: { enabled: false, status: 'planned' }
};
const networkVenues = [{ id: venue.id, name: venue.name, format: venue.format, city: venue.city, address: venue.address, phone: venue.phone, phoneNumbers: [], logoUrl: venue.logoUrl, timezone: venue.timezone, vipRoomMinimums: { ...venue.vipRoomMinimums }, status: 'active', isCurrent: true }];
let currentVenueId = venue.id;
const saasAccount = { id: 'org-territory', name: 'Территория', slug: 'territory', plan: 'starter', subscriptionStatus: 'trialing', seatsLimit: 5, venuesLimit: 1 };
const saasPlans = { starter: { name: 'Starter', monthlyPrice: 0, seatsLimit: 5, venuesLimit: 1, description: 'Для первого тестового заведения' }, growth: { name: 'Growth', monthlyPrice: 0, seatsLimit: 15, venuesLimit: 3, description: 'Для растущей команды' }, network: { name: 'Network', monthlyPrice: 0, seatsLimit: 50, venuesLimit: 10, description: 'Для сети заведений' }, enterprise: { name: 'Enterprise', monthlyPrice: 0, seatsLimit: 9999, venuesLimit: 9999, description: 'Индивидуальные лимиты' } };
const saasOrganizations = [{ id: 'org-territory', name: 'Территория', slug: 'territory', plan: 'starter', status: 'trialing', city: 'Тюмень', venues: 1, seats: 2, seatsLimit: 5, venuesLimit: 1, monthlyPrice: 0, createdAt: '2026-09-16T00:00:00.000Z', isActive: true, ownerName: 'Владелец организации', ownerLogin: 'owner@example.com', ownerActive: true, owners: [{ id: 'owner-territory', name: 'Владелец организации', login: 'owner@example.com', active: true }] }];
const products = [
  { id: 'hookah-darkside', name: 'Кальян — Darkside Blueberry', price: 1200, station: 'hookah', aliases: ['кальян', 'darkside', 'blueberry'], imageUrl: null },
  { id: 'lemonade-maracuya', name: 'Лимонад Маракуйя', price: 300, station: 'bar', aliases: ['лимонад', 'маракуйя', 'maracuya'], imageUrl: null },
  { id: 'redbull', name: 'Red Bull', price: 250, station: 'bar', aliases: ['red bull', 'ред булл', 'энергетик'], imageUrl: null },
  { id: 'tea-earl-grey', name: 'Чай Эрл Грей', price: 300, station: 'bar', aliases: ['чай', 'earl grey'], imageUrl: null },
  { id: 'clay-bowl', name: 'Чаша глиняная', price: 500, station: 'hookah', aliases: ['чаша'], imageUrl: null },
  { id: 'coco-nara', name: 'Уголь Coco Nara', price: 600, station: 'hookah', aliases: ['уголь', 'coco nara'], imageUrl: null },
  { id: 'energy-tiger', name: 'Tiger Energy', price: 220, station: 'bar', aliases: ['тигр', 'энергетик tiger'], imageUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUAAAADICAIAAAAWZq/8AAAJ50lEQVR42u3dZ29lRxnA8eczULV9193rXu61b3G377V3XdZtvc273l3vBtFEE1U00URTGqlKI40U0kkjjZQlDQgkkFCSEEIgkFBCSeiCF5YQEpPE55yZOTPn/KXfF5j/PM+bW86R16ypAOApee2aCgCektetqQDgKXn9mkoAnpI3rKkE4Cl549pKAJ6SNWurAHhK1q6tAuApWbe2CoCnZP26agCekg3rqgF4SjatqwbgKdm8rgaAp2TL+hoAnpKK9TUAPCWV62sBeEqq19cC8JTUbKgF4Cmp3VAHwFNSt6EOgKekfkMdAE9Jw8Z6AJ6Sxo31ADwlTRvrAXhKmjduBeApadm0FYCnpHVTAwBPSfumBgCeko5NDQA8JZ2bGn10fFspHE/PCyhJZnOjR45vL+ni18EBJclubnTfCe0lc7woAChJ9+Yml53YXrbD8Q6AkuQ2N7nppPayfc7WAJQkv6XJNSd1lOPlYBNASQpbmt1xckfZHU6VAZSkuKXZEU5t7wp34gBK0rul2QVf6ii7yZE+gJL0VbTE65SOUffFXglQkv6Klhh5sb0r4g0FKMlARUtcTu0Y9UuMrQAlGaxojcVpHaM+iisXoCTDla32nd456q9YigFKMlLZapnX27vCfjRASUqVbZad0TnmO/vRACUpV7bZlIDtXWG5G6Ako1Vt1pzZOZYkNtMBSjJW1W5HwrZ3hbV6gJJsr2q346zOseSxVg9QkvGqdgsSub0r7AQElGSiusOCszPbkspOQEBJJqs7TEvw9q6w0BBQkqnqTtPOyWxLNgsNASWZru406tzMtjQwnRFQkpmaTqNSssCmMwJKMluTMee8zPb0MFoSUJK5mow5qVpgoyUBJZmvyZjz5cz29DBaElCShZqsIednxtPGXExASXbVZg25IDueNuZiAkqyuzZrSAoX2FxMQEn21HaZcGF2PJ0M9QSUZG9tlwmpXWBDPQElWazrMuGi7Hg6GeoJKMn+um4TLs5OpJOhnoCSHKjrNuEr2Yl0MtQTUJKlum4TUrvAhnoCSnKwPmfCJV0T6WSoJ6Akh+pzJqR2gQ31BJRkuT5nwqVdE+lkqCegJEfq8yZc1jWZToZ6AkpydGvehNQusKGegJIctzVvwuVdk+lkqCegJG/aWjAhtQtsqCegJG/eWjDhiq7JdDLUE1CStzQUTbiieyqdDPUElOStDUUTruyeSidDPQEleVtD0YTULrChnoCSvL2hx4SruqfSyVBPQEne0dhjwtW5qXQy1BNQknc29hiSwu01FxNQknc19hpyTW5H2piLCTtT59155d2NvYZcm9uRNuZiwv6keXF2eU9Trzmp2l6jJRHjdLkcQd7b1GfOdbnp9DBaEi4MlYM15H1NfeZ8LTedHkZLwp1xcqqJvL+pz6iUbK/pjCnHjb8c+UBTv1HX56bTwHTG1OLeX5l8sLnftOvz08lmoWEKMQCrIR9q7jfthvx0sllomCqMwerJh5sHLLgxP5NUdgKmB8MQiHykecCCm/IzSWUnYEowD0HJR1sG7Ejk9lqrl3gMRjjysZZBO27OzySPtXrJxmyEJh9vGbQmYTdkM12CJXJ7rU2IfKJl0Kav52eSwXK3pErMPMQ1J/LJ1iHLbinM+s5+tERKwCTEPi3yqdYhyxJwJfajJU9Kttf0wMinW4fsu7Uw669YiiWM1wPg1NjIZ1qHY3FbYdZHceVKEk+v3s3hkc+2Dcfl9sKsX2JslRjeXbrjIySfaxuJ0e2FOV/EGyoZPLpuXwZJPt82Eq87CnPui71SMnhx137NknyhbcQFzuZ2pE8CsLomhkq+2F5yxDeKc65xJ47vHLzcZIyWHN9ecsedxTl3OFXGa05da8IGTE5oL7km9rIONvEau2puzOTE9rKb7irO2+dsDX/Fco++iJ5XTuoou+zu4rwdjnfwl7Ub9FH0vHJyR9l9RiN6UcBTrKjp8ZNTOkY9ck9xXhe/Du4pjfeVVBELy6kdoz46VpwPx9PzpuqO0iZKZDmtcxQw4VjPPFYjSmQ5vXMM0O6bPTuxeqE7yxmdY4B27GQgoTvLmZ1jgF739uxEUOFSy1md2wC97utZQFDhUsvZmW2AXvf3LiCocKnlnMw2QCNWMbQQteXczHZAowd6FxBOiNpyXmY7oBF7GFqI2nJ+djugy4O9C4giaHC5IDsO6PKt3l2IImhwuTA7DujCBkYUNLhclB0HdPl27y5EETS4XNw1AWjxnb5diC5Qc7mkawLQ4qG+XYguUHO5tGsS0OKhvt2ILlBzuaxrEtDiu327EV2g5nJ59ySgBbunRaDm8tXuKUCL7/XtRnSBmsuV3VOAFg/37UZ0gZrLVd1TgBaP9O1GdIGay9W5HYAWj/TvQXSBmss1uR2AFt/v34PoAjWXa3M7AC3YPS0CNZfrctOAFj/o34PoAjWX6/PTgBaP9u9BdIGayw35aUALdk+LQM3lxvwMoMVj/XsRXaDmclN+BtCC3dMiUHO5uTADaPHDgb2ILlBzuaUwC2jxo4F9iC5Qc7m1MAto8eOBfYguUHO5rTALaMHuaRGoudxemAO0+MnAPkQXqLncUZwDdGH9IgoaXO4szgG6PD6wD1EEDS53FecBXZ4YWEQUQYPL3cV5QJcnBxYRRdDgck/PTkCjJwcXEU6I2nKsZyeg0U8HFxFOiNpyb89OQKOnBhcRTojacl/PAqDXU4P7EVS41HJ/7wKg188G9yOocKnlgd4FQC+2MYRwqeXB3l2Adk8P7sfqhe4svBMdJrCTgYTuLLxPGYY8M7QfqxElsvA6VhjyzNABrEaUyMLbHGHOL4YO4JVFLCy8zRHmsJ+vKmJhebh/D2DOL4cP4OVEzyu8igZGPTt8AC8nel7hVTQwjUVV0tJWHu3fCxj1q+El/D8tbeWxgb2Aab8eXsL/0hVWeBA+7GBp/0tjVeExvLDmueEl6E0qPMgT1jw/vAS9SeXxwX2ANc+PLKWZ9p7yxOAiYNNvRg6mk4mYwqMAYV8Kt9dQSeFJYojFb0cOpoe5jMKjTBCX340cSgOjDeXpof1AXH4/cijZTAeUnw8dAGKU4O21UE94HgJi98LIoeSxk074RzVckLDttdZNnh1eAhzxh9Jh31kuJvyrC075Y+mwv+znEv4aAtd4ur2xtJLnhg8CDvpT6bAvYqwkz48cBJz159Jhl8XeR1L1izZ46sXSYdc4UkZS8nM2JMCLpWUXONVEEv9bNiTMS6XluDhYQ14oHQJ89FJ52Q6XI0gCvjpHyv2lvGyCF2cXjz6sB17VX8vLUXh3XnH8Y3oAr0BeLC8D8JRY+yQAgHZi6AMAABbI38pHAHhK/j56BICn5B+jRwB4Sv45ehSAp+Rfo0cBeEr+PXYcAE/9B4cXlZ2qZMJBAAAAAElFTkSuQmCC' },
  { id: 'lemonade-berry', name: 'Лимонад Лесные ягоды', price: 320, station: 'bar', aliases: ['ягоды', 'лесные ягоды', 'лимонад'], imageUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUAAAADICAIAAAAWZq/8AAAJ1UlEQVR42u3dd5dV1RnH8ec1CIIgCNLLML3e6RV7wYZdEXsFpEiT3gYYYGhDkzJUqUaNiRpNYovRaNTUVxNXyloxHsycc/azz95nf9f6vIHz3fv3B9w758oV46YA8JSQAPB5wOOnAvCUXDGhCICnZNDEIgCekkGTpgHwlAyaXAzAUzJoSjEAT8ngqSUAPCWDi0oBeEoGTysF4CkZXFwGwFNyZXE5AE/JlSXlADwlV5ZWAPCUDCmrBOApGVJeCcBTMqSiCoCnZEhlNQBPydCqagCekqHVNQA8JUNragF4SobW1gLwlFxVVwfAU98PuADAU3JVoQDAUzKsvh6Ap2RYQwMAT8mwxgYAnpJhTY0+Kl4zJxlPnxeIJMObmzySeLc/5teDA5FkeEuz+4rXztXjRQEgkgxvbXaZ6nR/MGO3OwCRZHhbi5uK1821z9kaQCS5ur3VNSXr5mXLwSZAJLm6o9UdJevnucOpMkCk7wfc5gin1vufDbcBLpMRne0uKNnwspsc6QNEkhFd7dlydro/mHHWlYBIMmJ6R4ZKNs73RbahgEgy4rrOrHi03n9vOLtWQCQZeX1nJko3zfdRVrmASDLyhi77Sjct8FcmxYBIMvLG6ZaVdi/wnf1oQCQZedN0y/IwYOvRgEhyzc3X2VS6eWE+WO4GRJJrbrnemtItC/PEZjogkrBeNgyPBzzq1hvsKNuyKH+s1QMiyajbbrSgbOuivLITEIgko26/0YI8D9hKQCCSjJpxk7aynlfyzUJDIJKMvuNmbeU9i/PNQkMgkoy+82ZV5dsWh0A7IxBJRt91i6pQBqycEYgko+++VU/59iXhUC0JRJJr77lVT1ADVi0JRJJrZ96mp3zHknColgQiybX33q6kvHdpaPRiApFkzL0zlFT0Lg2NXkwgkoy5b4aSEAesFhOIJGPuv0NDxc5lYVLqCUSSMQ/cqSHcAev0BCLJ2Afv1FCxa1mYlHoCkWTsQ3dpqNi1PExKPYFIMvbhuzVU7F4eJqWeQCQZ+8jdGsIdsE5PIJKMe/QeDZV7Xg2TUk8gkoybNVND5d4VYVLqCUSScY/N1BDugHV6ApFk3Ox7NVT2rQiTUk8gkoyffZ+Gyr6VYVLqCUSS8Y/fpyHcAev0BCLJ+Cfu11C5b2WYlHoCkWTCkw9oqNq3KkxKPYFIMuGpBzRU7V8VJqWeQCSZ8PSDGsIdsE5PIJJMeOYhDVUHVodJqScQSSY++5CGYAes1BOIJBOfe1hD1cHVYVLqCUSSic8/oqTq0JrQ6MUEIsnEFx5REuKA1WLCzq3z7nll0guPKqk+tDY0ejFh/6Z58ewy6cVZeqpfWxsO1ZLI8Ha5HEEmvTRLT1gD1iwJFy6VgzVk8pzH9FQfXhcO1ZJw5zo51UQmz52tKpT1KmcMHCd+OTJ53uOqqo+sD4F2xmBx7j9NJr/8uLb8r1e/YYC4AAMhU+Y/oa3m6Pp8s9AwKFyDgZMpC560oObYhryyEzAcXIZYZMrCJy3I84CtBAwE9yEumbLoKTtq+jfkj7V6ucfFSEamvvK0HbX9G/PHWr18424kJpwT62W9/t4Qmbr4GZtqj2/MB8vd8io39yGreyJFS561rPb4Jt/Zj5ZLObgJmd8WKVr6rGW1Jzb5zn60/MnBNXDhwkjRsufsqz3R7a9MiuWM1xfAqWsjRcufz0TtyW4fZZUrTzw9ejcvj0x79fms1J3s9kuGrXLDu0N3/ArJtBUvZKju1GZfZBsqHzw6bl8ukkxb+WK26k5vdl/mlfLBi7P26y7JtFUvusDd3G70yQGmq3GppHj1S46oO7PFNe7E8Z2Dh5uPqyXFa+a4w63ELpXxGnPVu2DCeTNdBuzxgEvWznVT4fWt9jlbw1+ZnKMv0ueVknXzXGYvpdsd/MVKVW+dlKyf577C2a16vCjgKdWDy4eUhaVkw8seKZztMcWvB/eUwfPKq5SFpXTjfB8Vzm1LxtPnDeqMQpMmspRumg9oKJzfhoFIE1lKuxcAxjHLeBtO2llKNy8EjCtc2I6BS9xZyrYsAsyqv7AdcSVLLWVbFwFm1V/cjriSpZaynlcAs+ov7kBcyVJLec9iwCCmmFiC2lK+bTFgUP2lHUgmQW0p374EMKj+Ui+SSVBbyncsBUypf6MXacQNLhW9SwFTGt7oRRpxg0vFzmWAKQ0/24k04gaXil3LAVMa3tyJNOIGl4rdywEjmJ+ZDcdpLpV7XgWMaHxrF9KL1Vwq964AjGh8azfSi9VcKvtWAEY0vr0b6cVqLlV9KwEj2J4RsZpL1b5VgBGNb+9BerGaS9X+VYARjT/fg/RiNZeqA6sBI9iemQHHaS7VB9cARjS9sxfpxWou1YfWAEY0/WIv0ovVXKpfWwsYwfbMDDhOc6k+vA4woumXfUgvVnOpObIOMILtGRGrudQcXQ8Y0fRuH9KL1Vxqjm0AjGh6dx/Si9Vcavo3AEY0vbcP6cVqLrX9GwEjmt/bj/RiNZfa45sAI9iemQHHaS61J7oBI5rfP4D0YjWXupPdgBFsz4hYzaXu1GbAiOZfHUB6sZpL3ektgCnNHxxEGnGDS92ZLYApLDDtgGMGl8LrWwFTWj48iDTiBpfC2R7AlJYPDyGNuMGlcK4HMKjl14eQTILaUji/DTCIHSYfcPzaUn9hO2BQy29eQzIJajNgsGFf1/vPAV/cAZjFGpMMOFFqabjUC5jV+tvDiCtZauE30aGh9aPDGLjEnYXfRIeG1o+OYOASd5aGN3cBGlo/PoKBSBNZ+D1lKGGZA5QmsvBrjtDT+slR/LSUhYXfkoIe9vn/B5yusDS+swfQ0/rpUVxO+rzCT9FAVdunx3A56fN+P+A+QBVDvcx6DbQVfooG2to+O4YfM9JWmt/dB2hr/6wf/81UWOE92rCj/Xf9+BeDVaX5/f2AHe2f98NsUuE1vLCm/fPjMJtUWj44CFjT/vsTITPeU3gPICwLd70KMYU3icG+9i9OhEappPAqE2Si/YuT4dDLKLzKBFnp+PJkCFQbCm8zQYbyv17lgMLbTJCtji9P5ZWFetL28VEgWx1/OJU/dtJJ2ydHgcx1fHUqT6x1E/6qC+7o+Oq07ywXk7bP+gF3dHx92l/2cwl/GgLXdH592keZtBK+XA43df7xjC8yrCSBf7kcjnN9uln3kQC/lQrvdH5zxjWOlJFAvs6GHOj85nUXONVEcvkZOnKs89uzWXGwhuTsA3SEw95uHY4gnV+dBrzW9e1ZDV48u3R+fQbIja7vzqXh3fOKR5+2Afgf4sj/7AFIQJT+/QDAAun67iwAT0nXn84B8JR0/fk8AE/J9L+cB+Apmf7XCwA8JdP/dhGAp+S6v18C4Kl/ACLiNvPRXbgrAAAAAElFTkSuQmCC' },
  { id: 'hookah-mint', name: 'Кальян — Mint Mix', price: 1100, station: 'hookah', aliases: ['кальян', 'мята', 'mint'], imageUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUAAAADICAIAAAAWZq/8AAAKAklEQVR42u3d95cW1R3H8e8fgTUGkV4s9M4WtrF9Fxa2V3rvHUGwgFQ15aQpCqLYjaCxYsOCBU2MJibRYKKpmhhjQupJ5hx/yYkjZ2fm3jv3zn2f8/oHnvd8P7/APs9Izx5DAThKevYYBsBRcmGP4QAcJReeNQKAo6TXWSMBOEp6nT0KgKPkorNHA3CU9D57DABHSe9zxgJwlPQ5ZxwAR0mfc8cDcJT0PXcCAEcFA54IwFHS77xJABwl/c/LAeAo6X9+LgBHyYDz8wA4KhhwPgBHycAvTQbgqGDABQAcJYMuKATgKBl8QREARwUDLgbgKBny5RIAjgoGPAWAo+TinmUAHCWX9CwH4KhgwBUAHCWXXlgJwFHBgKtc1JRzYzyOfl4glFzWq9ohzTk3qeLWBwdCBQOusZ/C3YYtuQZwlAztVWuz5pz9ZljeAQglwy6aaqeW3P3mWVsDCBUMeJptWnJvTpeFTYBQMrx3nT1Sn+7/sqoMECoY8HRLtOTeYht74gChZETvGTZozT1gJ0v6AKFkRJ/6dLXmHbBf6pWAUDKyT0OKWvMOuiLdUEAoGdW3MS1teQfdkmIrIFQw4KZUtOXd6qK0cgGhZHTfZvMcXe9nUikGhJLR/VoMa8s/5Drz0YBQMqZfq2Ht+YdcZz4aEErG9m8zqSP/tmww3A0IFQy43ZiO/NuzxGQ6IJSM699hRsbW+xlj9YBQMm5Apxkdkw9nj7F6QCgZP6DLgM7Jh7PKTEAglIwfOMuAzoI7sspMQCCUTBg4W7fOgjuzzUBDIJRMHDhHt66CO7PNQEMglEwcNFerroK7fKA7IxBKJg2ap5UnA9adEQglkwbP16er8G5/aC0JhJKcwQv0mVl4jz+0lgRCBQNeqI9nA14IGCa5QxZpMrPwXt/oiwmEkrwhizWZVXivb/TFBEJJ3sVLNJlVdJ9v9MUEQkn+xUt1mF10n5809QRCBQNepsPsovv9pKknEEomX7JcB28HrKknECoY8AodZhd910+aegKhpODSlTrMKX7AT5p6AqGk8NJVOng7YE09gVDBgFfrMKf4iJ809QRCSdFla3SYW3zET5p6AqGCAa/VYW7xUT9p6gmEkuKh63SYW3LUT5p6AqGkZOh6HeaVPOgnTT2BUMGAN+jg8YA3AMbIlGEbdZhX8pCfNPUEQgUD3qSDxwPeBBgjpcM36zB/ysN+0tQTCBUMeIsOHg94C2CMlA2/Qof5Ux7xk6aeQCgpH7FVhwWlj/hJU08gVDDgbTosKH3UT5p6AqGkYuSVmiwsfdQ3+mICoYIBX6XJwtLHfKMvJsxcnXOfVypHXq2JhwPWFxPmL82Jzy6Vo67RZ2HZ4/7QWhIpXpfNEaRq1HZ9FpU94Q+tJWHDUVlYQ6pH79DHqwFrLQl7zsmqJsGAr9VqUdkxH+jO6Dme+BeRmtE7tVpcdswHujN6i+d+ZlIzZpdui8ufzDYDDT3EAXSH1I7ZrVvmB2ygoVc4g+6TqWP3GLCk/KmsMhPQHxxDJMGA9xqQ6QHvBXeS1j3ItLH7zFhS/nT2GKuXeRxGPDJt3HVmLKl4OnuM1cs2biM2qRt3vTFLK57JEpPpMixjV2H4QqRu/A0mLa14NhsMd8uqzNxDWnci08d/xbBlFc+6zny0TMrAJaR+LTJj/FcNW1Zx3HXmo2VPBs7AhoORGRO+Zt6yyuPuSqVYxjh9AFadjdRP+Hoqllc+56K0cmWJo4/ezuOR+onfSMvyqufdkmKrzHDuoVt+QtIw8Zspcih9uqGywfP16jgkaZj0rXQtr3rBfqlXygYnnrVbtySNk75tgxVVL9rJkj4ZYO0jdvqopGnSdyxhYWh74riO0Wo6LWnKudEeK6pP2MOqMk6z6rFm7MCkOecm26ysPpEuC5s4LfUHaiclbaU5d7+dVla/ZJ61NdyVynN0RfK80pJ7s82MpbS8g7tYqdarCwZ8i/1WVr+sjxMFHKX1wWVDwsLSmnfAIatqXlbFrQ/uKIXPK6sSFpa2vIMuWlXzSjyOfl6vnpFvkkSWtvxbAR1YZncHnCCytOcfApRbXfMqui9252DAtwHKra45ie6L3Vk6Jt8OqLWm9iSiipdaOicfBtRaU/saooqXWjoL7gDUYo1xBhwrtXQV3AkotLb2dcQTo3Yw4LsAhdhhggFHri0zC+8GFFo79fuIJ0btYMD3AKowwsQbjhZcZhXdC6iybuoPkETU4DK76D5AlXVT30ASUYMHA74fUIUFJh5wtOAyp/gBQIn1036I5CI1DwZ8BFBi/bQ3kVyk5jK35CigxPq6N5FcpObBgB8ElFhf9xaSi9Rc5pU8BCixoe4tJBepucyf8j1AiY11P0JykZoHA34YUILtKRpwhOayoPQRQImN03+M5CI1Dwb8KKDExulvI7lIzWVh6WOAEpumv43kIjWXRWWPA0psmv4TJBepeTDgJwAl2J6iAUdoLovLjwFKXD7jp0guUvNgwE8CSrA9RQOO0FyWlD8FKHH5jJ8huUjNZUnF04ASbE/NgKM0l6UVzwBKbJ7xDpKL1FyWVT4LKLG5/l0kF6l5MODjgBJsT9GAIzSX5ZXPAUpsqf85kovUXJZXPQ8owfbUDDhKc1lR9QKgypb6U0gianBZUf0ioMqWhlNIImpwWVl9AlDliob3kETU4LKq+iVAla0N7yGJqMFlVc0rgEJbG3+BeGLUltU1rwIKbW38JeKJUVtW154EFNra+D7iiVFb1tS+Bqi1rfF9RBUvdTDg1wG1tjV+gKjipRbeiQ7ltjV9gKjipRbeiQ4drmz6FbovdmdZN+0NQDk2GW3AcTsL71OGJlc2/RrdkSSy8D5laMIyuz3g+JGFtzlCn6uaf4MzS1hYeBkc9Lmq+bc4s4SFhZfBQSsmeqb1Js4rvEsKWl3d/Dt8keR5hVfRQDeG+gXrVdBWeJMFdLum5ff4PCVthR/ChwHM9XPrVRNWNte/AxhwTcuH+IzCqrKl/l3AjO0tH0JtUuFneGHM9paPoDapXNFwCjBme+tHPlPeU/ghTxi2vfUPftIRU/gpQJi3o/WPvtFUUvgpQKTCs/Xqyij8mBjSsqP1Yx9obSj8GAJSdG3bn7JNd0Dh69RIV6bXq72e8I1qpO7a9k+yx0w64TuZsEHm1muom/CtLthjZ/ufXWe4mPC9EFhlZ/un7jKfS/hqCGzj7HpTaCWe/20qrLWr4y+uSLGSePuHqXCC9dNNuY94+FepcM7ujr/axpIysqPtY8AJtkzXpiaS+b9lQ8bs7jidFgtryM72TwAX7ek8bYbNESQD/3UOz+3p/JsOTnx22dX+KZAZCUfr3OcVh/63DcD/EQv/gR5AN8nuztMAHCWa/gEAgAGyt/PvABwle7v+AcBRsq/rnwAcJftm/guAo+S6mf8G4Ci5ftZ/ADjqv0IBuCyB6L7yAAAAAElFTkSuQmCC' }
];
const inventorySubdepartments = [];
products.forEach((product) => { product.category = product.category || (product.station === 'bar' ? 'Бар' : 'Кальянная зона'); });
products.push(...catalogSeed.products);
// The hosted demo starts with an empty business workspace. Technology cards
// remain seeded below, while menu items are created by the customer.
products.length = 0;
const productCategories = [
  { id: 'product-category-soft', name: 'Безалкогольные напитки', department: 'bar', active: true },
  { id: 'product-category-alcohol', name: 'Алкогольные напитки', department: 'bar', active: true },
  { id: 'product-category-tea', name: 'Чай и кофе', department: 'bar', active: true },
  { id: 'product-category-kitchen', name: 'Продукты и заготовки', department: 'kitchen', active: true },
  { id: 'product-category-hookah', name: 'Табак и смеси', department: 'hookah', active: true },
  { id: 'product-category-inventory', name: 'Расходники и инвентарь', department: 'inventory', active: true }
];
const importedProductCategoryNames = [...new Set(catalogSeed.products.map((item) => String(item.category || '').trim()).filter(Boolean))];
for (const name of importedProductCategoryNames) if (!productCategories.some((item) => item.name === name)) productCategories.push({ id: 'seed-category-' + name.toLowerCase().replace(/[^a-z0-9а-яё]+/gi, '-').slice(0, 32), name, active: true });
productCategories.length = 0;
const recipes = (catalogSeed.recipes || []).map((recipe, index) => ({ ...recipe, id: recipe.id || 'recipe-' + (index + 1), ingredients: Array.isArray(recipe.ingredients) ? recipe.ingredients : [] }));
products.forEach((product) => { if (!product.inventoryMode) { const normalizedName = String(product.name || '').trim().toLocaleLowerCase('ru-RU'); const directRecipes = recipes.filter((recipe) => recipe.active !== false && recipe.recipeType !== 'premix' && String(recipe.productId || '') === String(product.id)); const genericRecipes = recipes.filter((recipe) => recipe.active !== false && recipe.recipeType !== 'premix' && !recipe.productId && String(recipe.name || '').trim().toLocaleLowerCase('ru-RU') === normalizedName); const sameNameProducts = products.filter((candidate) => candidate.active !== false && String(candidate.name || '').trim().toLocaleLowerCase('ru-RU') === normalizedName); product.inventoryMode = directRecipes.length === 1 ? 'tracked' : !directRecipes.length && genericRecipes.length === 1 && sameNameProducts.length === 1 ? 'tracked' : 'needs_review'; } });
let floor = [
  { id: 'hall', name: 'Зал', tables: Array.from({ length: 12 }, (_, i) => {
    const n = i + 1;
    return { id: `table-${n}`, name: `Стол ${n}`, status: n === 8 || [2, 6, 11].includes(n) ? 'occupied' : [4, 9].includes(n) ? 'reserved' : 'free', capacity: 2, minimumOrderTotal: 0, layout: {} };
  }) },
  { id: 'vip', name: 'VIP-комнаты', tables: [
    { id: 'vip-room-1', name: 'VIP-комната 1', status: 'free', capacity: 4, minimumOrderTotal: 1500, layout: {} },
    { id: 'vip-room-2', name: 'VIP-комната 2', status: 'free', capacity: 6, minimumOrderTotal: 2500, layout: {} }
  ] }
];
floor.length = 0;
const floorByVenueId = new Map([[currentVenueId, floor]]);
const orders = [];
const discountRequests = [];
const staff = [
  { id: 'u-owner', name: 'Владелец', role: 'owner', active: true, avatarUrl: null, telegram: '', phoneNumbers: [], passportData: null, permissionScopes: [] },
  { id: 'u-maria', name: 'Мария', role: 'bartender', active: true, avatarUrl: null, telegram: '', phoneNumbers: [], passportData: null, permissionScopes: [] }
];
staff.splice(1);
const inventory = [
  { id: 'ing-redbull', name: 'Red Bull', category: 'Холодильник', unit: 'шт', onHand: 24, minLevel: 10 },
  { id: 'ing-coco', name: 'Уголь Coco Nara', category: 'Кальянная зона', unit: 'уп', onHand: 8, minLevel: 5 },
  { id: 'ing-mint', name: 'Мята', category: 'Бар', unit: 'кг', onHand: 1.8, minLevel: 2 },
  { id: 'ing-lime', name: 'Лайм', category: 'Бар', unit: 'кг', onHand: 3.2, minLevel: 1 },
  { id: 'ing-bowl', name: 'Чаша глиняная', category: 'Кальянная зона', unit: 'шт', onHand: 14, minLevel: 4 }
];
inventory.length = 0;
const stockMovements = [];
// In the local/demo runtime auto-order requests live in memory. Production
// requests are persisted in inventory_auto_orders below so a manager can
// review the same request from another device.
const autoOrderRequests = [];
const reservations = [];
const deliveries = [];
const tobaccoCatalogItems = [];
const tasks = [];
const manualExpenses = [];
const financeCategories = [
  { id: 'finance-kitchen', name: 'Кухня', kind: 'income', active: true },
  { id: 'finance-bar', name: 'Бар', kind: 'income', active: true },
  { id: 'finance-hookah', name: 'Кальяны', kind: 'income', active: true },
  { id: 'finance-stock', name: 'Склад', kind: 'expense', active: true },
  { id: 'finance-delivery', name: 'Доставка', kind: 'expense', active: true }
];
financeCategories.length = 0;
const auditEvents = [];
const staffNotifications = [];
const discountGroups = [
  { id: 'none', name: 'Без скидки', discountPercent: 0, bonusPercent: 0, depositMin: 0, active: true },
  { id: 'regular', name: 'Постоянный гость', discountPercent: 5, bonusPercent: 1, depositMin: 0, active: true },
  { id: 'vip', name: 'VIP', discountPercent: 10, bonusPercent: 2, depositMin: 3000, active: true }
];
discountGroups.length = 0;
const clients = [
  { id: 'client-anna', name: 'Анна Смирнова', phoneNumbers: [{ label: 'Основной', number: '+79991112233', primary: true }], telegram: '@anna_sm', tobaccoPreferences: ['Darkside', 'Мята'], bowlPreferences: ['Кальянная чаша'], barPreferences: ['Лимонад маракуйя', 'Red Bull'], allergies: '', notes: 'Предпочитает среднюю крепость', loyaltyPoints: 420, bonusBalance: 420, depositBalance: 0, discountGroupId: 'regular', visits: 6, totalSpent: 18400, lastVisitAt: '2026-09-18T21:30:00.000Z' },
  { id: 'client-igor', name: 'Игорь Волков', phoneNumbers: [{ label: 'Основной', number: '+79994445566', primary: true }, { label: 'Рабочий', number: '+79997778899', primary: false }], telegram: '', tobaccoPreferences: ['Tangiers', 'Ягодные миксы'], bowlPreferences: ['Калауд'], barPreferences: ['Кола', 'Виски'], allergies: 'Орехи', notes: '', loyaltyPoints: 180, bonusBalance: 180, depositBalance: 3000, discountGroupId: 'vip', visits: 3, totalSpent: 9200, lastVisitAt: '2026-09-12T20:10:00.000Z' }
];
clients.length = 0;
const sessions = new Map();
const memoryPreferencesByAccount = new Map();
const loginAttempts = new Map();
const pinUnlockAttempts = new Map();
const requestBuckets = new Map();
const configuredApiRateLimit = Number(process.env.API_RATE_LIMIT);
const API_RATE_LIMIT = Number.isInteger(configuredApiRateLimit) && configuredApiRateLimit >= 30 && configuredApiRateLimit <= 10000
  ? configuredApiRateLimit
  : 180;
const API_RATE_WINDOW_MS = 60_000;
const shifts = [];
const memoryShiftOpenPending = new Set();
const provisionedAccounts = [];
const demoAccounts = [
  { username: 'admin', venueId: process.env.VENUE_ID || '00000000-0000-0000-0000-000000000001', password: process.env.DEMO_ADMIN_PASSWORD || (process.env.AUTH_REQUIRED === 'true' ? '' : 'admin'), name: 'Александр', role: 'admin', organizationId: '00000000-0000-0000-0000-000000000010' },
  { username: 'owner', venueId: process.env.VENUE_ID || '00000000-0000-0000-0000-000000000001', password: process.env.DEMO_OWNER_PASSWORD || (process.env.AUTH_REQUIRED === 'true' ? '' : 'demo'), name: 'Владелец', role: 'owner', organizationId: '00000000-0000-0000-0000-000000000010' },
  { username: 'staff', venueId: process.env.VENUE_ID || '00000000-0000-0000-0000-000000000001', password: process.env.DEMO_STAFF_PASSWORD || (process.env.AUTH_REQUIRED === 'true' ? '' : 'demo'), pin: process.env.DEMO_STAFF_PIN || (process.env.AUTH_REQUIRED === 'true' ? '' : '1234'), name: 'Мария', role: 'bartender', organizationId: '00000000-0000-0000-0000-000000000010' },
  { username: process.env.SAAS_OWNER_EMAIL || 'platform-owner@example.com', password: process.env.SAAS_OWNER_PASSWORD || (process.env.AUTH_REQUIRED === 'true' ? '' : 'saas-demo'), name: 'Владелец SaaS', role: 'platform_owner', organizationId: null }
].filter((account) => Boolean(account.password));

const hashPassword = async (password) => { const salt = crypto.randomBytes(16).toString('hex'); const derived = await scryptAsync(String(password), salt, 64); return `scrypt$${salt}$${derived.toString('hex')}`; };
const verifyPassword = async (password, stored) => {
  if (!stored) return false;
  if (!String(stored).startsWith('scrypt$')) { const actual = Buffer.from(String(password)); const expectedPlain = Buffer.from(String(stored)); return actual.length === expectedPlain.length && crypto.timingSafeEqual(actual, expectedPlain); }
  const [, salt, encoded] = String(stored).split('$'); const derived = await scryptAsync(String(password), salt, 64); const expected = Buffer.from(encoded || '', 'hex'); return expected.length === derived.length && crypto.timingSafeEqual(derived, expected);
};

const staffPassportCipher = {
  encrypt(value) {
    const secret = process.env.STAFF_PASSPORT_KEY;
    if (!secret) return null;
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', crypto.createHash('sha256').update(secret).digest(), iv);
    const encrypted = Buffer.concat([cipher.update(JSON.stringify(value), 'utf8'), cipher.final()]);
    return { data: encrypted.toString('base64'), iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64') };
  },
  decrypt(row) {
    const secret = process.env.STAFF_PASSPORT_KEY;
    if (!secret || !row?.passport_data_encrypted) return null;
    try {
      const decipher = crypto.createDecipheriv('aes-256-gcm', crypto.createHash('sha256').update(secret).digest(), Buffer.from(row.passport_data_iv, 'base64'));
      decipher.setAuthTag(Buffer.from(row.passport_data_tag, 'base64'));
      return JSON.parse(Buffer.concat([decipher.update(Buffer.from(row.passport_data_encrypted, 'base64')), decipher.final()]).toString('utf8'));
    } catch (_) { return null; }
  }
};const rolePermissions = {
  owner: ['floor', 'orders', 'reservations', 'inventory', 'inventory_read', 'finance', 'finance_read', 'staff', 'staff_manage', 'staff_sensitive', 'tasks_manage', 'settings', 'diagnostics', 'integrations', 'delivery', 'loyalty'],
  admin: ['floor', 'orders', 'reservations', 'inventory', 'inventory_read', 'finance', 'finance_read', 'staff', 'staff_manage', 'staff_view', 'staff_sensitive', 'tasks_manage', 'settings', 'diagnostics', 'integrations', 'delivery', 'loyalty'],
  manager: ['floor', 'orders', 'reservations', 'inventory_read', 'finance_read', 'staff_view', 'tasks_manage', 'settings', 'loyalty'],
  senior_bartender: ['floor', 'orders', 'bar_tasks', 'finance_read'],
  senior_hookah_master: ['floor', 'orders', 'hookah_tasks', 'finance_read'],
  bartender: ['floor', 'orders', 'bar_tasks', 'finance_read'],
  hookah_master: ['floor', 'orders', 'hookah_tasks', 'finance_read'],
  developer: ['floor', 'orders', 'reservations', 'inventory_read', 'finance_read', 'staff', 'staff_manage', 'staff_view', 'tasks_manage', 'settings', 'diagnostics', 'integrations', 'delivery'],
  platform_owner: ['platform', 'diagnostics', 'settings'],
  cleaner: ['finance_read'],
  security: ['finance_read'],
  technician: ['finance_read'],
  other_staff: ['finance_read']
};
const staffPinCipher = {
  encrypt(pin) { const wrapped = staffPassportCipher.encrypt({ pin: String(pin) }); return wrapped; },
  decrypt(row) { const wrapped = staffPassportCipher.decrypt({ passport_data_encrypted: row?.pin_data_encrypted, passport_data_iv: row?.pin_data_iv, passport_data_tag: row?.pin_data_tag }); return wrapped?.pin || null; }
};
const permissionScopes = ['orders', 'reservations', 'inventory', 'finance', 'staff', 'delivery', 'integrations', 'settings', 'loyalty'];
const scopedPermissionMap = {
  orders: ['orders', 'floor'],
  reservations: ['reservations'],
  inventory: ['inventory', 'inventory_read'],
  finance: ['finance', 'finance_read'],
  staff: ['staff', 'staff_manage', 'staff_view', 'staff_sensitive', 'tasks_manage'],
  delivery: ['delivery'],
  integrations: ['integrations'],
  settings: ['settings'],
  loyalty: ['loyalty']
};
const normalizePermissionScopes = (value) => [...new Set((Array.isArray(value) ? value : []).map((scope) => String(scope || '').trim()).filter((scope) => permissionScopes.includes(scope)))];
const effectivePermissions = (user) => {
  const base = rolePermissions[user?.role] || [];
  const scopes = normalizePermissionScopes(user?.customRolePermissionScopes?.length ? user.customRolePermissionScopes : user?.permissionScopes);
  if (!scopes.length) return base;
  const restricted = new Set(Object.values(scopedPermissionMap).flat());
  return [...new Set([...base.filter((permission) => !restricted.has(permission)), ...scopes.flatMap((scope) => scopedPermissionMap[scope] || [])])];
};

const json = (res, status, data) => {
  const headers = { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'" };
  if (process.env.CORS_ORIGIN) headers['Access-Control-Allow-Origin'] = process.env.CORS_ORIGIN;
  res.writeHead(status, headers);
  res.end(JSON.stringify(data));
};
const MAX_BODY_BYTES = 2 * 1024 * 1024;
const BODY_TIMEOUT_MS = 15_000;
const body = (req) => new Promise((resolve, reject) => {
  let raw = '';
  let bytes = 0;
  let settled = false;
  const finish = (error, value) => {
    if (settled) return;
    settled = true;
    clearTimeout(timeout);
    if (error) reject(error); else resolve(value);
  };
  const timeout = setTimeout(() => {
    req.destroy();
    finish(Object.assign(new Error('request_body_timeout'), { code: 'request_body_timeout' }));
  }, BODY_TIMEOUT_MS);
  req.on('data', (chunk) => {
    bytes += Buffer.byteLength(chunk);
    if (bytes > MAX_BODY_BYTES) {
      req.destroy();
      finish(Object.assign(new Error('payload_too_large'), { code: 'payload_too_large' }));
      return;
    }
    raw += chunk;
  });
  req.on('end', () => {
    try { finish(null, raw ? JSON.parse(raw) : {}); } catch (error) { finish(error); }
  });
  req.on('error', (error) => finish(error));
});
const normalizePhoneNumbers = (value) => { const seen = new Set(); const contacts = (Array.isArray(value) ? value : []).map((entry) => ({ label: String(entry?.label || 'Дополнительный').trim().slice(0, 32), number: String(entry?.number || '').trim(), primary: Boolean(entry?.primary) })).filter((entry) => { const key = entry.number.replace(/\D/g, ''); if (!key || seen.has(key)) return false; seen.add(key); return true; }); if (contacts.length) { const primaryIndex = contacts.findIndex((entry) => entry.primary); contacts.forEach((entry, index) => { entry.primary = primaryIndex < 0 ? index === 0 : index === primaryIndex; }); } return contacts; };
const validEmploymentDate = (value) => !value || (/^\d{4}-\d{2}-\d{2}$/.test(String(value)) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`)));
const orderTotal = (order) => order.items.reduce((sum, item) => sum + (Number(item.unitPrice) || 0) * (Number(item.quantity) || 0), 0);
const recipeUnitAliases = { г: 'г', гр: 'г', грамм: 'г', грамма: 'г', граммов: 'г', кг: 'кг', килограмм: 'кг', килограмма: 'кг', мл: 'мл', milliliter: 'мл', миллилитр: 'мл', миллилитра: 'мл', л: 'л', liter: 'л', литр: 'л', литра: 'л', шт: 'шт', штука: 'шт', штуки: 'шт', порция: 'порция', порции: 'порция', уп: 'уп', упаковка: 'упаковка' };
const recipeUnitFactors = { г: { г: 1, кг: 0.001 }, кг: { кг: 1, г: 1000 }, мл: { мл: 1, л: 0.001 }, л: { л: 1, мл: 1000 }, шт: { шт: 1 }, порция: { порция: 1 }, уп: { уп: 1 }, упаковка: { упаковка: 1 } };
const normalizeRecipeUnit = (value) => recipeUnitAliases[String(value || '').trim().toLocaleLowerCase('ru-RU')] || null;
const parseRecipeQuantity = (value, targetUnit, fallbackUnit = null) => {
  const raw = String(value ?? '').trim().replace(',', '.'); const match = raw.match(/^([0-9]+(?:\.[0-9]+)?)\s*([a-zа-яё]+)?$/i);
  if (!match || Number(match[1]) <= 0) return { error: 'invalid_recipe_quantity' };
  const sourceUnit = normalizeRecipeUnit(match[2] || fallbackUnit || targetUnit); const normalizedTarget = normalizeRecipeUnit(targetUnit);
  if (!sourceUnit || !normalizedTarget || !recipeUnitFactors[sourceUnit]?.[normalizedTarget]) return { error: 'recipe_ingredient_unit_mismatch', sourceUnit: sourceUnit || match[2] || null, targetUnit: normalizedTarget || targetUnit || null };
  return { amount: Number(match[1]), sourceUnit, targetUnit: normalizedTarget, factor: recipeUnitFactors[sourceUnit][normalizedTarget] };
};
const explicitDemoRuntime = () => process.env.DEMO_MODE === 'true' || (!repositories?.pool && process.env.AUTH_REQUIRED !== 'true' && process.env.NODE_ENV !== 'production');
async function normalizeRecipeIngredients(input, venueId) {
  if (!Array.isArray(input) || input.length === 0) throw Object.assign(new Error('recipe_ingredients_required'), { code: 'recipe_ingredients_required' });
  if (input.length > 50) throw Object.assign(new Error('recipe_ingredients_limit_exceeded'), { code: 'recipe_ingredients_limit_exceeded' });
  const source = input;
  const normalized = source.map((item) => typeof item === 'string' ? { name: item.trim(), quantity: '' } : { name: String(item?.name || '').trim(), ingredientId: String(item?.ingredientId || item?.inventoryItemId || '').trim() || null, quantity: String(item?.quantity ?? '').trim(), unit: String(item?.unit || '').trim() || null });
  if (!repositories?.pool) {
    const byId = new Map(inventory.map((item) => [String(item.id), item]));
    const byName = new Map(inventory.map((item) => [String(item.name || '').trim().toLocaleLowerCase('ru-RU'), item]));
    return normalized.map((item) => {
      if (!item.name && !item.ingredientId) throw Object.assign(new Error('recipe_ingredient_required'), { code: 'recipe_ingredient_required' });
      const stockItem = (item.ingredientId && byId.get(item.ingredientId)) || (!item.ingredientId && byName.get(item.name.toLocaleLowerCase('ru-RU')));
      if (!stockItem) throw Object.assign(new Error('recipe_ingredient_not_found'), { code: 'recipe_ingredient_not_found', ingredient: item.name || item.ingredientId });
      const parsed = parseRecipeQuantity(item.quantity, stockItem.unit, item.unit || null);
      if (parsed.error) throw Object.assign(new Error(parsed.error), { code: parsed.error, sourceUnit: parsed.sourceUnit, targetUnit: parsed.targetUnit, ingredient: stockItem.name });
      return { name: stockItem.name, ingredientId: stockItem.id, quantity: `${parsed.amount} ${parsed.sourceUnit}`, unit: parsed.sourceUnit };
    });
  }
  if (!repositories?.inventory) return null;
  const inventoryItems = (await repositories.inventory.list(venueId)).items;
  const byId = new Map(inventoryItems.map((item) => [String(item.id), item])); const byName = new Map(inventoryItems.map((item) => [String(item.name || '').trim().toLocaleLowerCase('ru-RU'), item]));
  const result = [];
  for (const item of normalized) {
    if (!item.name && !item.ingredientId) throw Object.assign(new Error('recipe_ingredient_required'), { code: 'recipe_ingredient_required' });
    const stockItem = (item.ingredientId && byId.get(item.ingredientId)) || (!item.ingredientId && byName.get(item.name.toLocaleLowerCase('ru-RU')));
    if (!stockItem) throw Object.assign(new Error('recipe_ingredient_not_found'), { code: 'recipe_ingredient_not_found', ingredient: item.name || item.ingredientId });
    const parsed = parseRecipeQuantity(item.quantity, stockItem.unit, item.unit || null);
    if (parsed.error) throw Object.assign(new Error(parsed.error), { code: parsed.error, sourceUnit: parsed.sourceUnit, targetUnit: parsed.targetUnit, ingredient: stockItem.name });
    result.push({ name: stockItem.name, ingredientId: stockItem.id, quantity: `${parsed.amount} ${parsed.sourceUnit}`, unit: parsed.sourceUnit });
  }
  return result;
}
const calculateRecipeCostLines = (ingredients, stock) => (Array.isArray(ingredients) ? ingredients : []).map((item) => {
  const stockItem = item.ingredientId ? stock.find((entry) => entry.id === item.ingredientId) : stock.find((entry) => entry.name.toLocaleLowerCase('ru-RU') === String(item.name || '').trim().toLocaleLowerCase('ru-RU'));
  if (!stockItem) return { ...item, stockName: item.name || null, unit: null, quantity: null, unitCost: 0, cost: 0, linked: false };
  const parsed = parseRecipeQuantity(item.quantity, stockItem.unit, item.unit || null);
  if (parsed.error) throw Object.assign(new Error(parsed.error), { code: parsed.error, ingredient: stockItem.name, sourceUnit: parsed.sourceUnit, targetUnit: parsed.targetUnit });
  const quantity = Number((parsed.amount * parsed.factor).toFixed(6));
  return { ...item, stockName: stockItem.name, unit: stockItem.unit, sourceUnit: parsed.sourceUnit, quantity, unitCost: Number(stockItem.cost || 0), cost: Math.round(quantity * Number(stockItem.cost || 0) * 100) / 100, linked: true };
});
const normalizeRecipeOutput = (input = {}, previous = {}) => {
  const rawQuantity = input.yieldQuantity ?? input.yield ?? previous.yieldQuantity;
  const rawUnit = input.yieldUnit ?? previous.yieldUnit;
  const rawPortions = input.portionCount ?? input.portions ?? previous.portionCount;
  const quantity = Number(String(rawQuantity ?? '').replace(',', '.'));
  const unit = normalizeRecipeUnit(rawUnit);
  const portions = Number(rawPortions);
  if (!Number.isFinite(quantity) || quantity <= 0 || quantity > 100000) throw Object.assign(new Error('recipe_yield_required'), { code: 'recipe_yield_required' });
  if (!unit) throw Object.assign(new Error('recipe_yield_unit_invalid'), { code: 'recipe_yield_unit_invalid', targetUnit: rawUnit || null });
  if (!Number.isInteger(portions) || portions < 1 || portions > 100000) throw Object.assign(new Error('recipe_portions_invalid'), { code: 'recipe_portions_invalid' });
  return { yieldQuantity: Number(quantity.toFixed(6)), yieldUnit: unit, portionCount: portions };
};
async function depleteRecipeForOrder(pool, orderId, venueId, actorId, transactionClient = null) {
  const client = transactionClient || await pool.connect();
  const ownsTransaction = !transactionClient;
  try {
    if (ownsTransaction) await client.query('BEGIN');
    let requirements = [];
    const cardProductIds = new Set();
    const { rows: cards } = await client.query(`SELECT oi.product_id AS "productId", oi.quantity AS "orderQuantity", p.name AS "productName", p.inventory_mode AS "inventoryMode",
        EXISTS (SELECT 1 FROM recipes legacy_recipe JOIN recipe_items legacy_item ON legacy_item.product_id=legacy_recipe.product_id
          JOIN ingredients legacy_ingredient ON legacy_ingredient.id=legacy_item.ingredient_id AND legacy_ingredient.venue_id=p.venue_id
          WHERE legacy_recipe.product_id=oi.product_id AND legacy_item.quantity>0) AS "hasLegacyRecipe",
        (SELECT COUNT(*)::int FROM inventory_recipe_cards direct_card WHERE direct_card.venue_id=$2 AND direct_card.active=true AND direct_card.recipe_type='sale' AND direct_card.product_id=oi.product_id) AS "directRecipeCount",
        (SELECT COUNT(*)::int FROM inventory_recipe_cards generic_card WHERE generic_card.venue_id=$2 AND generic_card.active=true AND generic_card.recipe_type='sale' AND generic_card.product_id IS NULL AND lower(btrim(generic_card.name))=lower(btrim(p.name))) AS "unboundRecipeCount",
        (SELECT COUNT(*)::int FROM products same_name_product WHERE same_name_product.venue_id=$2 AND same_name_product.is_active=true AND lower(btrim(same_name_product.name))=lower(btrim(p.name))) AS "sameNameProductCount",
        rc.id AS "recipeId", rc.ingredients, rc.portion_count AS "portionCount", (rc.product_id IS NOT NULL) AS "directlyBound"
      FROM order_items oi JOIN products p ON p.id=oi.product_id
      LEFT JOIN LATERAL (
        SELECT candidate.id,candidate.ingredients,candidate.portion_count,candidate.product_id
        FROM inventory_recipe_cards candidate
        WHERE candidate.venue_id=$2 AND candidate.active=true AND candidate.recipe_type='sale'
          AND (candidate.product_id=oi.product_id OR (candidate.product_id IS NULL AND lower(btrim(candidate.name))=lower(btrim(p.name))))
        ORDER BY (candidate.product_id=oi.product_id) DESC NULLS LAST,candidate.updated_at DESC,candidate.created_at DESC,candidate.id
        LIMIT 1
      ) rc ON true
      WHERE oi.order_id=$1`, [orderId, venueId]);
    for (const card of cards) {
      if (card.inventoryMode === 'non_stock') continue;
      if (card.inventoryMode === 'needs_review') throw Object.assign(new Error('product_inventory_mode_required'), { code: 'product_inventory_mode_required', productId: card.productId, productName: card.productName });
      if (card.inventoryMode !== 'tracked') throw Object.assign(new Error('product_inventory_mode_invalid'), { code: 'product_inventory_mode_invalid', productId: card.productId, productName: card.productName });
      if (Number(card.directRecipeCount || 0) > 1 || (!Number(card.directRecipeCount || 0) && Number(card.unboundRecipeCount || 0) > 0
        && (Number(card.unboundRecipeCount) !== 1 || Number(card.sameNameProductCount) !== 1))) {
        throw Object.assign(new Error('product_recipe_ambiguous'), { code: 'product_recipe_ambiguous', productId: card.productId, productName: card.productName });
      }
      if (!card.recipeId && !card.hasLegacyRecipe) throw Object.assign(new Error('product_recipe_required'), { code: 'product_recipe_required', productId: card.productId, productName: card.productName });
      if (!card.recipeId) continue;
      cardProductIds.add(card.productId);
      if (!Array.isArray(card.ingredients) || card.ingredients.length === 0) throw Object.assign(new Error('recipe_invalid'), { code: 'recipe_invalid', productId: card.productId });
      let scaledIngredients;
      try { scaledIngredients = scaleBatchRecipeIngredients(card.ingredients, Number(card.orderQuantity), Number(card.portionCount || 1)); }
      catch (error) { throw Object.assign(new Error('recipe_invalid'), { code: 'recipe_invalid', detail: error.message, productId: card.productId }); }
      for (const item of scaledIngredients) {
        const name = String(item.name || '').trim(); const ingredientId = String(item.ingredientId || '').trim();
        if (!name || !/^[0-9a-f-]{36}$/i.test(ingredientId)) throw Object.assign(new Error('recipe_invalid'), { code: 'recipe_invalid', productId: card.productId });
        requirements.push({ ingredientId, name, quantityText: String(item.quantity || ''), sourceUnit: String(item.unit || '') });
      }
    }
    // Older recipe rows remain a fallback only for products without an active
    // inventory recipe card; applying both sources would double-deplete stock.
    await client.query('SAVEPOINT legacy_recipe_lookup');
    try {
      const legacy = await client.query(`SELECT oi.product_id AS "productId",ri.ingredient_id AS "ingredientId",i.name,i.unit,SUM(ri.quantity * oi.quantity)::numeric AS quantity
        FROM order_items oi JOIN recipes r ON r.product_id=oi.product_id JOIN recipe_items ri ON ri.product_id=r.product_id
        JOIN ingredients i ON i.id=ri.ingredient_id WHERE oi.order_id=$1 AND i.venue_id=$2
          AND NOT (oi.product_id=ANY($3::uuid[]))
        GROUP BY oi.product_id,ri.ingredient_id,i.name,i.unit`, [orderId, venueId, [...cardProductIds]]);
      requirements.push(...legacy.rows.map((item) => ({ ...item, quantityText: String(item.quantity), sourceUnit: item.unit })));
    } catch (error) {
      // Some installations do not have the legacy recipe tables. Their absence
      // must not prevent current recipe cards from being applied.
      if (error.code !== '42P01') throw error;
      await client.query('ROLLBACK TO SAVEPOINT legacy_recipe_lookup');
    }
    if (!requirements.length) { if (ownsTransaction) await client.query('COMMIT'); return { lines: [], totalCost: 0 }; }
    const ids = requirements.map((item) => item.ingredientId).filter((item) => /^[0-9a-f-]{36}$/i.test(String(item || '')));
    const names = requirements.map((item) => String(item.name || '').toLowerCase()).filter(Boolean);
    const queryIds = ids.length ? ids : ['00000000-0000-0000-0000-000000000000'];
    const queryNames = names.length ? names : ['__none__'];
    await client.query('SELECT id FROM ingredients WHERE venue_id=$1 AND (id=ANY($2::uuid[]) OR lower(name)=ANY($3::text[])) FOR UPDATE', [venueId, queryIds, queryNames]);
    const existing = await client.query("SELECT COUNT(*)::int AS count, COALESCE(SUM(sm.quantity * i.cost),0)::numeric AS cost FROM stock_movements sm JOIN ingredients i ON i.id=sm.ingredient_id WHERE sm.venue_id=$1 AND sm.order_id=$2 AND sm.direction='out'", [venueId, orderId]);
    if (Number(existing.rows[0]?.count || 0) > 0) {
      const snapshot = await client.query('SELECT cost FROM order_costs WHERE venue_id=$1 AND order_id=$2', [venueId, orderId]);
      const historicalCost = snapshot.rows[0] ? Number(snapshot.rows[0].cost) : Number(existing.rows[0].cost);
      if (ownsTransaction) await client.query('COMMIT');
      return { lines: [], totalCost: historicalCost, alreadyDepleted: true };
    }
    const { rows: stock } = await client.query(`SELECT i.id, i.name, i.cost, i.unit, COALESCE(SUM(CASE WHEN sm.direction IN ('in','transfer','adjustment') THEN sm.quantity WHEN sm.direction IN ('out','waste') THEN -sm.quantity ELSE 0 END),0)::numeric AS on_hand FROM ingredients i LEFT JOIN stock_movements sm ON sm.ingredient_id=i.id AND sm.venue_id=i.venue_id WHERE i.venue_id=$1 AND (i.id=ANY($2::uuid[]) OR lower(i.name)=ANY($3::text[])) GROUP BY i.id`, [venueId, queryIds, queryNames]);
    const byId = new Map(stock.map((item) => [item.id, item])); const byName = new Map(stock.map((item) => [item.name.toLowerCase(), item]));
    const grouped = new Map();
    const factors = { г: { г: 1, кг: 0.001 }, кг: { кг: 1, г: 1000 }, мл: { мл: 1, л: 0.001 }, л: { л: 1, мл: 1000 }, шт: { шт: 1 }, порция: { порция: 1 }, уп: { уп: 1 }, упаковка: { упаковка: 1 } };
    for (const item of requirements) {
      const found = (item.ingredientId && byId.get(item.ingredientId)) || byName.get(String(item.name || '').toLowerCase());
      if (!found) throw Object.assign(new Error('recipe_ingredient_not_found'), { code: 'recipe_ingredient_not_found', ingredient: item.name || item.ingredientId });
      const parsed = parseRecipeQuantity(item.quantityText, found.unit, item.sourceUnit || null);
      if (parsed.error) throw Object.assign(new Error(parsed.error), { code: parsed.error, ingredient: found.name, sourceUnit: parsed.sourceUnit, targetUnit: parsed.targetUnit });
      const converted = Number((parsed.amount * parsed.factor).toFixed(6));
      const previous = grouped.get(found.id);
      grouped.set(found.id, { ingredientId: found.id, name: found.name, unit: found.unit, quantity: (previous?.quantity || 0) + converted, stock: found });
    }
    const finalRequirements = [...grouped.values()]; const missing = finalRequirements.filter((item) => !item.stock || Number(item.stock.on_hand || 0) < Number(item.quantity));
    if (missing.length) { const error = new Error('insufficient_recipe_stock'); error.missing = missing.map((item) => ({ ...item, onHand: Number(item.stock?.on_hand || 0) })); throw error; }
    for (const item of finalRequirements) {
      const { rows: movementRows } = await client.query(`INSERT INTO stock_movements (venue_id,ingredient_id,direction,quantity,reason,order_id,created_by) VALUES ($1,$2,'out',$3,$4,$5,$6) RETURNING id`, [venueId, item.ingredientId, item.quantity, `Списание по заказу ${orderId}`, orderId, /^[0-9a-f-]{36}$/i.test(actorId || '') ? actorId : null]);
      await allocatePremixBatchConsumption(client, { venueId, ingredientId: item.ingredientId, stockMovementId: movementRows[0].id, quantity: item.quantity, onHandBefore: Number(item.stock?.on_hand || 0), createdBy: actorId, reason: `Списание по заказу ${orderId}` });
    }
    if (ownsTransaction) await client.query('COMMIT');
    return { lines: finalRequirements, totalCost: finalRequirements.reduce((sum, item) => sum + Number(item.quantity) * Number(item.stock?.cost || 0), 0) };
  } catch (error) {
    if (ownsTransaction) await client.query('ROLLBACK').catch(() => {});
    throw error;
  } finally { if (ownsTransaction) client.release(); }
}
const approvedDiscountTotal = (orderId, subtotal) => discountRequests.filter((request) => request.orderId === orderId && request.status === 'approved').reduce((sum, request) => sum + (request.type === 'percent' ? subtotal * Math.min(100, Math.max(0, Number(request.value || 0))) / 100 : Math.max(0, Number(request.value || 0))), 0);
const orderNetTotal = (order) => Math.max(0, orderTotal(order) - approvedDiscountTotal(order.id, orderTotal(order)));
const receivedOrderPayments = (order) => (order.payments || []).filter((payment) => ['paid', 'partially_paid'].includes(payment.status)).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
const moneyCents = (value) => Math.round(Number(value) * 100);
const roundMoney = (value) => moneyCents(value) / 100;
const validPaymentAmount = (value) => Number.isFinite(value) && value > 0 && Math.abs(value * 100 - moneyCents(value)) < 1e-7;
const validCashAmount = (value) => {
  if (value === null || value === undefined || typeof value === 'boolean' || Array.isArray(value) || (typeof value !== 'number' && typeof value !== 'string')) return false;
  const raw = String(value).trim();
  if (!/^\d+(?:\.\d{1,2})?$/.test(raw)) return false;
  const amount = Number(raw);
  return Number.isFinite(amount) && amount >= 0 && amount <= 100000000;
};
const memoryOrderBalance = (order) => ({ due: roundMoney(Math.max(orderNetTotal(order), Number(order.minimumOrderTotal || 0))), paid: receivedOrderPayments(order) });
const orderBalanceConflict = ({ due, paid }) => moneyCents(paid) > moneyCents(due);
const orderBalanceConflictBody = ({ due, paid }) => ({ error: 'paid_order_total_conflict', due, paid });
async function pgOrderBalance(client, orderId, minimumOrderTotal = 0) {
  const { rows: itemRows } = await client.query('SELECT quantity,unit_price AS "unitPrice" FROM order_items WHERE order_id=$1', [orderId]);
  const subtotal = itemRows.reduce((sum, item) => sum + Number(item.quantity) * Number(item.unitPrice), 0);
  const { rows: discountRows } = await client.query("SELECT type,value FROM discounts WHERE order_id=$1 AND status='approved'", [orderId]);
  const discount = discountRows.reduce((sum, item) => sum + (item.type === 'percent' ? subtotal * Math.min(100, Math.max(0, Number(item.value || 0))) / 100 : Math.max(0, Number(item.value || 0))), 0);
  const { rows: paidRows } = await client.query("SELECT COALESCE(SUM(amount),0) AS paid FROM payments WHERE order_id=$1 AND status IN ('paid','partially_paid')", [orderId]);
  return { due: roundMoney(Math.max(subtotal - discount, Number(minimumOrderTotal || 0))), paid: Number(paidRows[0]?.paid || 0) };
}
const orderStatusTransitions = { open: ['open', 'in_progress', 'cancelled'], in_progress: ['in_progress', 'ready', 'open', 'cancelled'], ready: ['ready', 'closed', 'in_progress', 'cancelled'], closed: ['closed'], cancelled: ['cancelled'] };
const validOrderTransition = (from, to) => Boolean(orderStatusTransitions[from]?.includes(to));
const vipSummary = (order) => {
  const minimum = Number(order.minimumOrderTotal || 0);
  const total = orderTotal(order);
  return { orderId: order.id, total, minimum, shortfall: Math.max(0, minimum - total), minimumApplied: minimum > 0 };
};
const businessTimezone = process.env.BUSINESS_TIMEZONE || 'Asia/Yekaterinburg';
const businessDateKey = (value) => { const raw = String(value || ''); if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw; const parsed = value instanceof Date ? value : new Date(value); if (Number.isNaN(parsed.getTime())) return raw.slice(0, 10); return new Intl.DateTimeFormat('en-CA', { timeZone: businessTimezone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(parsed); };
const medianOf = (values) => { const ordered = values.map(Number).filter(Number.isFinite).sort((a, b) => a - b); if (!ordered.length) return 0; const middle = Math.floor(ordered.length / 2); return ordered.length % 2 ? ordered[middle] : (ordered[middle - 1] + ordered[middle]) / 2; };
const allocateMoneyByGross = (items, amount, keyOf, grossOf, fallbackKey = 'other') => {
  const grouped = new Map();
  for (const item of items || []) {
    const key = String(keyOf(item) || fallbackKey);
    const gross = Math.max(0, Number(grossOf(item) || 0));
    grouped.set(key, (grouped.get(key) || 0) + gross);
  }
  const entries = [...grouped.entries()];
  const targetCents = Math.max(0, Math.round(Number(amount || 0) * 100));
  const grossTotal = entries.reduce((sum, [, gross]) => sum + gross, 0);
  if (!entries.length || grossTotal <= 0) return new Map([[fallbackKey, targetCents / 100]]);
  const shares = entries.map(([key, gross], index) => {
    const exactCents = targetCents * gross / grossTotal;
    const cents = Math.floor(exactCents);
    return { key, cents, fraction: exactCents - cents, index };
  });
  let remaining = targetCents - shares.reduce((sum, share) => sum + share.cents, 0);
  for (const share of shares.slice().sort((a, b) => b.fraction - a.fraction || a.index - b.index)) {
    if (remaining <= 0) break;
    share.cents += 1;
    remaining -= 1;
  }
  return new Map(shares.map(({ key, cents }) => [key, cents / 100]));
};
const today = () => businessDateKey(new Date());
const normalizeRecipeCard = (recipe) => ({ ...recipe, yieldQuantity: Number(recipe.yieldQuantity || 1), portionCount: Number(recipe.portionCount || 1) });
const isValidIanaTimezone = (value) => {
  const timezone = String(value || '').trim();
  if (!timezone) return false;
  try { new Intl.DateTimeFormat('en-US', { timeZone: timezone }).format(0); return true; }
  catch (_) { return false; }
};
const resolveIanaTimezone = (...values) => values.map((value) => String(value || '').trim()).find(isValidIanaTimezone) || 'Asia/Yekaterinburg';
const venueBusinessDateContext = async (pool, venueId) => {
  const { rows } = await pool.query('SELECT v.timezone AS "venueTimezone", org.timezone AS "organizationTimezone" FROM venues v LEFT JOIN organizations org ON org.id=v.organization_id WHERE v.id=$1', [venueId]);
  if (!rows[0]) return null;
  const timezone = resolveIanaTimezone(rows[0].venueTimezone, rows[0].organizationTimezone);
  const { rows: dateRows } = await pool.query('SELECT (now() AT TIME ZONE $1)::date::text AS date', [timezone]);
  return dateRows[0]?.date ? { timezone, date: dateRows[0].date } : null;
};
const recentBusinessDates = (count = 7) => { const current = new Date(`${today()}T00:00:00Z`); return Array.from({ length: count }, (_, index) => { const date = new Date(current); date.setUTCDate(current.getUTCDate() - (count - 1 - index)); return date.toISOString().slice(0, 10); }); };
const pendingPaymentSummary = (items = orders) => { const active = items.filter((order) => ['open', 'in_progress', 'ready'].includes(order.status)); const pendingRevenue = active.reduce((sum, order) => { const due = Math.max(Number(order.minimumOrderTotal || 0), orderNetTotal(order)); const paid = (order.payments || []).filter((payment) => ['paid', 'partially_paid'].includes(payment.status)).reduce((total, payment) => total + Number(payment.amount || 0), 0); return sum + Math.max(0, due - paid); }, 0); return { pendingOrders: active.length, pendingRevenue: Math.round(pendingRevenue * 100) / 100 }; };
const isBelowInventoryMinimum = (item) => Number(item.minLevel || 0) > 0 && Number(item.onHand || 0) <= Number(item.minLevel || 0);
const metrics = () => ({
  ...pendingPaymentSummary(),
  openOrders: orders.filter((order) => ['open', 'in_progress', 'ready'].includes(order.status)).length,
  closedOrders: orders.filter((order) => order.status === 'closed').length,
  discountRequests: discountRequests.filter((request) => request.status === 'requested').length,
  staffActive: staff.filter((person) => person.active).length,
  reservationsToday: reservations.filter((reservation) => reservation.date === today()).length,
  lowStock: inventory.filter(isBelowInventoryMinimum).length
});
const visibleMetrics = (req, values) => {
  const visible = {};
  const include = (permission, fields) => { if (hasPermission(req, permission)) for (const field of fields) visible[field] = values[field]; };
  include('orders', ['openOrders', 'pendingOrders', 'closedOrders']);
  include('finance_read', ['pendingRevenue', 'discountRequests']);
  if (hasPermission(req, 'staff_view') || hasPermission(req, 'staff')) visible.staffActive = values.staffActive;
  include('reservations', ['reservationsToday']);
  include('inventory_read', ['lowStock']);
  return visible;
};
const setMemoryTableStatus = (tableId, status) => { const table = floor.flatMap((zone) => zone.tables).find((entry) => entry.id === tableId); if (table && table.status !== 'blocked') table.status = status; };
const releaseMemoryTableIfIdle = (tableId) => { const hasActiveOrder = orders.some((order) => order.tableId === tableId && ['open', 'in_progress', 'ready'].includes(order.status)); const hasReservation = reservations.some((reservation) => reservation.tableId === tableId && reservation.status === 'confirmed' && reservation.date === today()); if (!hasActiveOrder) setMemoryTableStatus(tableId, hasReservation ? 'reserved' : 'free'); };
const memoryPremixRemaining = (batch) => batch.status === 'voided' ? 0 : Number(Math.max(0, Number(batch.outputQuantity || 0) + (batch.lotMovements || []).reduce((sum, row) => sum + Number(row.quantityDelta || 0), 0)).toFixed(6));
const allocateMemoryPremixConsumption = (ingredientId, quantity, onHandBefore, movementId, reason, { apply = true } = {}) => {
  const lots = stockMovements.filter((item) => item.type === 'premix' && String(item.outputItemId) === String(ingredientId) && item.status !== 'voided' && memoryPremixRemaining(item) > 0)
    .sort((a, b) => (a.expiresAt || '9999').localeCompare(b.expiresAt || '9999') || String(a.createdAt || '').localeCompare(String(b.createdAt || '')));
  const tracked = lots.reduce((sum, batch) => sum + memoryPremixRemaining(batch), 0);
  let remaining = Math.max(0, Number(quantity) - Math.min(Number(quantity), Math.max(0, Number(onHandBefore || 0) - tracked)));
  const allocations = []; let available = 0;
  for (const batch of lots) if (!batch.expiresAt || new Date(batch.expiresAt).getTime() > Date.now()) available += memoryPremixRemaining(batch);
  if (remaining > available + 0.000001) throw new Error(lots.some((batch) => batch.expiresAt && new Date(batch.expiresAt).getTime() <= Date.now()) ? 'expired_premix_stock' : 'premix_batch_balance_mismatch');
  for (const batch of lots) { if (remaining <= 0.000001) break; if (batch.expiresAt && new Date(batch.expiresAt).getTime() <= Date.now()) continue; const used = Math.min(memoryPremixRemaining(batch), remaining); allocations.push({ batch, used }); remaining -= used; }
  if (apply) for (const { batch, used } of allocations) { batch.lotMovements ||= []; batch.lotMovements.push({ movementId, type: 'consumption', quantityDelta: -used, reason, createdAt: new Date().toISOString() }); }
  return allocations;
};
const depleteMemoryOrder = (order, { reason = `Списание по заказу ${order.id}` } = {}) => {
  if (order.recipeDepleted) return { lines: [], totalCost: Number(order.costOfGoods || 0), alreadyDepleted: true };
  const requirements = [];
  for (const orderItem of order.items || []) {
    const product = products.find((entry) => String(entry.id) === String(orderItem.productId));
    const inventoryMode = product?.inventoryMode || 'needs_review';
    if (inventoryMode === 'non_stock') continue;
    if (inventoryMode === 'needs_review') throw Object.assign(new Error('product_inventory_mode_required'), { code: 'product_inventory_mode_required', productId: orderItem.productId, productName: product?.name || orderItem.name });
    if (inventoryMode !== 'tracked') throw Object.assign(new Error('product_inventory_mode_invalid'), { code: 'product_inventory_mode_invalid', productId: orderItem.productId, productName: product?.name || orderItem.name });
    const normalizedName = String(product?.name || orderItem.name || '').trim().toLocaleLowerCase('ru-RU');
    const productRecipes = recipes.filter((entry) => entry.active !== false && entry.recipeType !== 'premix' && String(entry.productId || '') === String(orderItem.productId));
    const genericRecipes = recipes.filter((entry) => entry.active !== false && entry.recipeType !== 'premix' && !entry.productId && String(entry.name || '').trim().toLocaleLowerCase('ru-RU') === normalizedName);
    const sameNameProducts = products.filter((entry) => entry.active !== false && String(entry.name || '').trim().toLocaleLowerCase('ru-RU') === normalizedName);
    if (productRecipes.length > 1 || (!productRecipes.length && genericRecipes.length && (genericRecipes.length !== 1 || sameNameProducts.length !== 1))) throw Object.assign(new Error('product_recipe_ambiguous'), { code: 'product_recipe_ambiguous', productId: orderItem.productId, productName: product?.name || orderItem.name });
    const recipe = productRecipes[0] || genericRecipes[0];
    if (!recipe) throw Object.assign(new Error('product_recipe_required'), { code: 'product_recipe_required', productId: orderItem.productId, productName: product?.name || orderItem.name });
    if (!Array.isArray(recipe.ingredients) || recipe.ingredients.length === 0) throw Object.assign(new Error('recipe_invalid'), { code: 'recipe_invalid', productId: orderItem.productId });
    let scaledIngredients;
    try { scaledIngredients = scaleBatchRecipeIngredients(recipe.ingredients, Number(orderItem.quantity), Number(recipe.portionCount || 1)); }
    catch (error) { throw Object.assign(new Error('recipe_invalid'), { code: 'recipe_invalid', detail: error.message, productId: orderItem.productId }); }
    for (const ingredient of scaledIngredients) {
      const name = String(ingredient.name || '').trim(); const ingredientId = String(ingredient.ingredientId || '').trim();
      if (!name || !ingredientId) throw Object.assign(new Error('recipe_invalid'), { code: 'recipe_invalid', productId: orderItem.productId });
      const stock = inventory.find((entry) => entry.id === ingredientId);
      if (!stock) throw Object.assign(new Error('recipe_ingredient_not_found'), { code: 'recipe_ingredient_not_found', ingredient: name });
      const parsed = parseRecipeQuantity(ingredient.quantity, stock.unit, ingredient.unit || null);
      if (parsed.error) throw Object.assign(new Error(parsed.error), { code: parsed.error, ingredient: stock.name, sourceUnit: parsed.sourceUnit, targetUnit: parsed.targetUnit });
      const quantity = Number(parsed.amount) * Number(parsed.factor);
      const previous = requirements.find((entry) => entry.stock?.id === stock.id);
      if (previous) previous.quantity += quantity; else requirements.push({ name: stock.name, ingredientId: stock.id, quantity, stock });
    }
  }
  const missing = requirements.filter((entry) => !entry.stock || !Number.isFinite(entry.quantity) || Number(entry.stock.onHand || 0) < entry.quantity);
  if (missing.length) { const error = new Error('insufficient_recipe_stock'); error.missing = missing.map((entry) => ({ ...entry, onHand: Number(entry.stock?.onHand || 0) })); throw error; }
  const movementIds = new Map(requirements.map((entry) => [entry.ingredientId, `mov-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`]));
  for (const entry of requirements) allocateMemoryPremixConsumption(entry.stock.id, entry.quantity, Number(entry.stock.onHand || 0), movementIds.get(entry.ingredientId), reason, { apply: false });
  const totalCost = requirements.reduce((sum, entry) => sum + Number(entry.quantity) * Number(entry.stock?.cost || 0), 0);
  for (const entry of requirements) { const before = Number(entry.stock.onHand || 0); const movementId = movementIds.get(entry.ingredientId); allocateMemoryPremixConsumption(entry.stock.id, entry.quantity, before, movementId, reason); entry.stock.onHand = Number((before - entry.quantity).toFixed(6)); stockMovements.push({ id: movementId, itemId: entry.stock.id, itemName: entry.stock.name, direction: 'out', delta: -entry.quantity, quantity: entry.quantity, reason, orderId: order.id, createdAt: new Date().toISOString() }); }
  order.recipeDepleted = true; order.costOfGoods = totalCost;
  return { lines: requirements, totalCost };
};

const hashToken = (token) => crypto.createHash('sha256').update(token).digest('hex');
const STANDARD_SESSION_TTL_MS = 12 * 60 * 60 * 1000;
const TRUSTED_SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const SESSION_TTL_MS = STANDARD_SESSION_TTL_MS;
const SESSION_TTL_SECONDS = Math.floor(SESSION_TTL_MS / 1000);
const sessionTtlSeconds = (ttlMs) => Math.floor(ttlMs / 1000);
const canUseTrustedDevice = (role) => ['owner', 'admin', 'developer'].includes(String(role || ''));
const requestCookies = (req) => Object.fromEntries((req.headers.cookie || '').split(';').map((part) => part.trim().split('=').map(decodeURIComponent)).filter((parts) => parts.length === 2));
const requestAuthToken = (req) => { const header = req.headers.authorization || ''; return header.startsWith('Bearer ') ? header.slice(7) : (requestCookies(req).crm_session || ''); };
const sessionFromRequest = async (req) => {
  const header = req.headers.authorization || '';
  const cookies = Object.fromEntries((req.headers.cookie || '').split(';').map((part) => part.trim().split('=').map(decodeURIComponent)).filter((parts) => parts.length === 2));
  const token = header.startsWith('Bearer ') ? header.slice(7) : (cookies.crm_session || '');
  if (!token) return null;
  if (process.env.DATABASE_URL || sessionRepository) {
    if (sessionRepository) {
      try {
        const persisted = await sessionRepository.get(hashToken(token));
        if (persisted) return { user: { id: persisted.userId, organizationId: persisted.organizationId || null, venueId: persisted.venueId || null, name: persisted.name, role: persisted.role, customRoleId: persisted.customRoleId || null, customRolePermissionScopes: normalizePermissionScopes(persisted.customRolePermissionScopes), avatarUrl: persisted.avatarUrl || null, telegram: persisted.telegram || '', phoneNumbers: persisted.phoneNumbers || [], permissionScopes: normalizePermissionScopes(persisted.permissionScopes), preferences: persisted.preferences || {}, pinConfigured: Boolean(persisted.pinUpdatedAt) } };
      } catch (_) { return null; }
    }
    const memorySession = sessions.get(token);
    if (memorySession) {
      if (Date.now() > Number(memorySession.expiresAt || memorySession.createdAt + SESSION_TTL_MS)) { sessions.delete(token); return null; }
      return memorySession.user?.role === 'platform_owner' ? memorySession : null;
    }
    return null;
  }
  const memorySession = sessions.get(token);
  if (memorySession) { if (Date.now() > Number(memorySession.expiresAt || memorySession.createdAt + SESSION_TTL_MS)) { sessions.delete(token); return null; } return memorySession; }
  return null;
};
const recordAudit = (req, action, entityType, entityId, beforeData, afterData) => {
  const event = { id: `audit-${Date.now()}-${auditEvents.length}`, venueId: req.user?.venueId || defaultVenueDbId, action, entityType, entityId: entityId || null, actor: req.user?.name || 'demo', beforeData: beforeData || null, afterData: afterData || null, createdAt: new Date().toISOString() };
  auditEvents.push(event);
  if (repositories?.audit) return repositories.audit.record({ venueId: req.user?.venueId || defaultVenueDbId, actorId: /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null, action, entityType, entityId: /^[0-9a-f-]{36}$/i.test(entityId || '') ? entityId : null, beforeData, afterData }).catch(() => {});
};
const inventoryUnitFactors = { г: { г: 1, кг: 0.001 }, кг: { кг: 1, г: 1000 }, мл: { мл: 1, л: 0.001 }, л: { л: 1, мл: 1000 }, шт: { шт: 1 }, порция: { порция: 1 }, уп: { уп: 1 }, упаковка: { упаковка: 1 } };
const normalizePurchaseInput = (input) => {
  const supplierName = String(input.supplierName || 'Не указан').trim();
  const documentNumber = String(input.documentNumber || '').trim() || null;
  const rawDocumentDate = input.documentDate === undefined || input.documentDate === null ? '' : String(input.documentDate).trim();
  const documentDate = rawDocumentDate || null;
  const note = String(input.note || '').trim() || null;
  const parsedDocumentDate = documentDate ? new Date(`${documentDate}T00:00:00.000Z`) : null;
  const validDocumentDate = !documentDate || (/^\d{4}-\d{2}-\d{2}$/.test(documentDate) && !Number.isNaN(parsedDocumentDate.getTime()) && parsedDocumentDate.toISOString().slice(0, 10) === documentDate);
  if (!supplierName || supplierName.length > 160 || (documentNumber && documentNumber.length > 80) || !validDocumentDate || (note && note.length > 2000)) { const error = new Error('invalid_purchase_document'); throw error; }
  if (input.sourceAutoOrderId !== undefined && input.sourceAutoOrderId !== null && input.sourceAutoOrderId !== '' && !/^[0-9a-f-]{36}$/i.test(String(input.sourceAutoOrderId))) { const error = new Error('invalid_source_auto_order'); throw error; }
  if (input.lines !== undefined && !Array.isArray(input.lines)) { const error = new Error('invalid_purchase_lines'); throw error; }
  const lines = (input.lines || []).map((entry) => {
    const ingredientId = String(entry.ingredientId || '').trim();
    const quantity = Number(entry.quantity); const unitCost = Number(entry.unitCost);
    const unit = String(entry.unit || '').trim();
    if (!ingredientId || !/^[0-9a-f-]{36}$/i.test(ingredientId) || !Number.isFinite(quantity) || quantity <= 0 || !Number.isFinite(unitCost) || unitCost < 0 || (!inventoryUnitFactors[unit] && unit.length > 30)) { const error = new Error('invalid_purchase_line'); error.ingredientId = ingredientId; throw error; }
    return { ingredientId, quantity, unit, unitCost };
  });
  return { supplierName, documentNumber, documentDate, note, sourceAutoOrderId: input.sourceAutoOrderId || null, lines };
};
const validImageData = (value) => /^data:image\/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/.test(String(value || '')) && String(value).length <= 700_000;
const hasPermission = (req, permission) => process.env.AUTH_REQUIRED !== 'true' || Boolean(req.user && effectivePermissions(req.user).includes(permission));
const isOperationalEmployee = (req) => ['bartender','hookah_master','senior_bartender','senior_hookah_master','cleaner','security','technician','other_staff'].includes(String(req.user?.role || '').toLowerCase());
const canAssignStaffRole = (req, role) => process.env.AUTH_REQUIRED !== 'true' || req.user?.role === 'owner';
const canCreateStaffRole = (req, role) => process.env.AUTH_REQUIRED !== 'true' || req.user?.role === 'owner' || (req.user?.role === 'admin' && ['senior_bartender','senior_hookah_master','bartender','hookah_master','cleaner','security','technician','other_staff'].includes(role));
const canManageStaffTarget = (req, targetRole) => process.env.AUTH_REQUIRED !== 'true' || req.user?.role === 'owner' || (req.user?.role === 'admin' && !['owner','admin','developer'].includes(targetRole)) || (req.user?.role === 'manager' && !['owner','admin','developer'].includes(targetRole));
const canManageVenueIdentity = (req) => process.env.AUTH_REQUIRED !== 'true' || ['owner', 'admin', 'developer'].includes(req.user?.role);
const requestOrganizationId = (req) => String(req.user?.organizationId || '').trim();
const runFloorMutation = async (req, res, expectedVenueId, selectedVenueId, operation) => {
  if (!expectedVenueId) return json(res, 428, { error: 'venue_precondition_required' });
  if (String(expectedVenueId) !== String(selectedVenueId)) return json(res, 409, { error: 'venue_context_changed' });
  let client;
  try {
    if (repositories?.pool) {
      const organizationId = requestOrganizationId(req) || null;
      if (process.env.AUTH_REQUIRED === 'true' && !organizationId) return json(res, 403, { error: 'organization_context_required' });
      client = await repositories.pool.connect();
      await client.query('BEGIN');
      const selected = await client.query('SELECT id FROM venues WHERE id=$1 AND ($2::uuid IS NULL OR organization_id=$2::uuid) AND is_active=true FOR UPDATE', [selectedVenueId, organizationId]);
      if (!selected.rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'venue_not_found' }); }
      const token = requestAuthToken(req);
      if (token) {
        const active = await client.query('SELECT COALESCE(s.active_venue_id,u.venue_id) AS venue_id FROM auth_sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>now() AND u.is_active=true AND ($2::uuid IS NULL OR u.organization_id=$2::uuid) FOR UPDATE OF s', [hashToken(token), organizationId]);
        if (!active.rows[0]) { await client.query('ROLLBACK'); return json(res, 401, { error: 'session_required' }); }
        if (String(active.rows[0].venue_id) !== String(expectedVenueId)) { await client.query('ROLLBACK'); return json(res, 409, { error: 'venue_context_changed' }); }
      } else if (process.env.AUTH_REQUIRED === 'true') { await client.query('ROLLBACK'); return json(res, 401, { error: 'session_required' }); }
    }
    const result = await operation(client);
    if (client) await client.query(result.status >= 400 ? 'ROLLBACK' : 'COMMIT');
    if (result.audit && result.status < 400) recordAudit(req, result.audit.action, result.audit.entityType, result.audit.entityId, result.audit.before, result.audit.after);
    return json(res, result.status, result.body);
  } catch (error) {
    if (client) await client.query('ROLLBACK').catch(() => {});
    if (error.code === '23503' || error.code === '23505') return json(res, 409, { error: 'floor_reference_conflict' });
    return json(res, 503, { error: 'floor_save_failed' });
  } finally { client?.release(); }
};
const requireOrganizationContext = (req, res) => {
  if (process.env.AUTH_REQUIRED === 'true' && repositories?.pool && !/^[0-9a-f-]{36}$/i.test(requestOrganizationId(req))) {
    json(res, 403, { error: 'organization_context_required' });
    return true;
  }
  return false;
};
const loadOrganizationEntitlements = async (client, organizationId, { lock = false } = {}) => {
  const suffix = lock ? ' FOR UPDATE OF o' : '';
  const { rows } = await client.query(`SELECT o.id,o.is_active AS "organizationActive",s.status AS "subscriptionStatus",s.seats_limit AS "seatsLimit",s.venues_limit AS "venuesLimit"
    FROM organizations o LEFT JOIN organization_subscriptions s ON s.organization_id=o.id WHERE o.id=$1${suffix}`, [organizationId]);
  return rows[0] || null;
};
const enforceOrganizationAccess = async (user) => {
  if (!repositories?.pool || !user?.organizationId || user.role === 'platform_owner') return null;
  try {
    const { rows } = await repositories.pool.query(`SELECT o.is_active AS active,s.status AS "subscriptionStatus",m.status AS "membershipStatus"
      FROM organizations o LEFT JOIN organization_subscriptions s ON s.organization_id=o.id
      LEFT JOIN organization_memberships m ON m.organization_id=o.id AND m.user_id=$2
      WHERE o.id=$1`, [user.organizationId, user.id]);
    const state = rows[0];
    if (!state || state.active !== true || !['trialing','active','past_due'].includes(state.subscriptionStatus) || !['active','invited','suspended'].includes(state.membershipStatus)) return { status: 403, error: 'organization_suspended' };
    if (state.membershipStatus !== 'active') return { status: 403, error: 'organization_membership_inactive' };
    return null;
  } catch (_) { return { status: 503, error: 'organization_access_unavailable' }; }
};
const checkOrganizationQuota = async (client, organizationId, kind) => {
  const entitlement = await loadOrganizationEntitlements(client, organizationId, { lock: true });
  if (!entitlement || entitlement.organizationActive !== true || !entitlement.subscriptionStatus) return { error: 'organization_unavailable', status: 403 };
  if (entitlement.subscriptionStatus === 'cancelled') return { error: 'organization_suspended', status: 403 };
  const isSeat = kind === 'seat';
  const limit = Number(isSeat ? entitlement.seatsLimit : entitlement.venuesLimit);
  if (!Number.isInteger(limit) || limit < 1) return { error: 'organization_limits_unavailable', status: 503 };
  const table = isSeat ? 'users' : 'venues';
  const { rows } = await client.query(isSeat
    ? 'SELECT COUNT(*)::int AS used FROM users WHERE organization_id=$1 AND is_active=true AND deleted_at IS NULL'
    : 'SELECT COUNT(*)::int AS used FROM venues WHERE organization_id=$1 AND is_active=true', [organizationId]);
  const used = Number(rows[0]?.used || 0);
  if (used >= limit) return { error: isSeat ? 'seat_limit_reached' : 'venue_limit_reached', status: 409, limit, used };
  return { entitlement, limit, used };
};
const canSeeSensitiveStaff = (req) => Boolean(req.user && effectivePermissions(req.user).includes('staff_sensitive'));
const canSeeStaffPhoto = (req) => Boolean(req.user && ['owner', 'admin', 'manager'].includes(req.user.role));
const validBirthDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(String(value || '')) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`));
const denyUnless = (req, res, permission) => { if (hasPermission(req, permission)) return false; json(res, 403, { error: 'forbidden', permission }); return true; };
const denyUnlessAny = (req, res, permissions) => { if (permissions.some((permission) => hasPermission(req, permission))) return false; json(res, 403, { error: 'forbidden', permission: permissions.join(' or ') }); return true; };
const notificationMemoryReads = new Map();
const notificationRoles = new Set(['owner', 'admin', 'manager', 'developer']);
const notificationVenueScope = (req, venueDbId) => {
  if (repositories?.pool) return venueDbId;
  const sessionVenueId = String(req.user?.venueId || currentVenueId);
  return sessionVenueId === 'venue-territory' ? defaultVenueDbId : sessionVenueId;
};
const notificationAccess = (req) => {
  if (process.env.AUTH_REQUIRED === 'true' && (isOperationalEmployee(req) || !notificationRoles.has(req.user?.role))) return null;
  const role = req.user?.role || '';
  const unrestricted = process.env.AUTH_REQUIRED !== 'true';
  return {
    shifts: (unrestricted || ['owner', 'admin', 'manager', 'developer'].includes(role)) && hasPermission(req, 'finance_read'),
    discounts: (unrestricted || ['owner', 'admin'].includes(role)) && hasPermission(req, 'finance_read') && hasPermission(req, 'orders'),
    autoOrders: (unrestricted || ['owner', 'admin', 'manager'].includes(role)) && hasPermission(req, 'inventory_read'),
    deletedOrders: (unrestricted || ['owner', 'admin', 'manager'].includes(role)) && hasPermission(req, 'orders'),
  };
};
async function collectNotificationEvents(req, venueId, limit = 100) {
  const access = notificationAccess(req);
  if (!access || !Object.values(access).some(Boolean)) return null;
  const items = [];
  let unreadCount = 0;
  const userId = String(req.user?.id || 'anonymous');
  if (repositories?.pool) {
    const queries = [];
    if (access.discounts) queries.push(repositories.pool.query(`SELECT 'discount:'||d.id::text AS id,'discount' AS type,'Запрошена скидка' AS title,'Запрос ожидает решения' AS summary,d.created_at AS "createdAt",d.order_id AS "orderId",r.read_at AS "readAt",count(*) FILTER (WHERE r.read_at IS NULL) OVER()::int AS "sourceUnreadCount",'/orders' AS href,true AS "requiresAction"
      FROM discounts d JOIN orders o ON o.id=d.order_id LEFT JOIN notification_reads r ON r.venue_id=o.venue_id AND r.user_id=$2 AND r.notification_key='discount:'||d.id::text
      WHERE o.venue_id=$1 AND d.status='requested' ORDER BY d.created_at DESC LIMIT $3`, [venueId, userId, limit]));
    if (access.autoOrders) queries.push(repositories.pool.query(`SELECT 'inventory_auto_order:'||a.id::text AS id,'inventory_auto_order' AS type,'Заявка на пополнение' AS title,'Заявка отправлена и ожидает обработки' AS summary,a.created_at AS "createdAt",a.id AS "autoOrderId",r.read_at AS "readAt",count(*) FILTER (WHERE r.read_at IS NULL) OVER()::int AS "sourceUnreadCount",'/inventory?view=auto-orders' AS href,false AS "requiresAction"
      FROM inventory_auto_orders a LEFT JOIN notification_reads r ON r.venue_id=a.venue_id AND r.user_id=$2 AND r.notification_key='inventory_auto_order:'||a.id::text
      WHERE a.venue_id=$1 AND a.status='sent' ORDER BY a.created_at DESC LIMIT $3`, [venueId, userId, limit]));
    if (access.deletedOrders) queries.push(repositories.pool.query(`SELECT 'order_deleted:'||e.id::text AS id,'order_deleted' AS type,'Заказ удалён' AS title,'Проверьте событие в журнале заказов' AS summary,e.created_at AS "createdAt",e.entity_id AS "orderId",r.read_at AS "readAt",count(*) FILTER (WHERE r.read_at IS NULL) OVER()::int AS "sourceUnreadCount",'/orders' AS href,false AS "requiresAction"
      FROM audit_events e LEFT JOIN notification_reads r ON r.venue_id=e.venue_id AND r.user_id=$2 AND r.notification_key='order_deleted:'||e.id::text
      WHERE e.venue_id=$1 AND e.action='order.deleted' ORDER BY e.created_at DESC LIMIT $3`, [venueId, userId, limit]));
    if (access.shifts) queries.push(repositories.pool.query(`SELECT 'shift_'||replace(e.action,'shift.','')||':'||e.entity_id::text AS id,'shift_'||replace(e.action,'shift.','') AS type,CASE WHEN e.action='shift.opened' THEN 'Смена открыта' ELSE 'Смена закрыта' END AS title,CASE WHEN e.action='shift.opened' THEN 'Проверьте состояние текущей смены' ELSE 'Смена закрыта и сохранена в журнале' END AS summary,e.created_at AS "createdAt",e.entity_id AS "shiftId",r.read_at AS "readAt",count(*) FILTER (WHERE r.read_at IS NULL) OVER()::int AS "sourceUnreadCount",'/admin#shift-control' AS href,false AS "requiresAction"
      FROM audit_events e LEFT JOIN notification_reads r ON r.venue_id=e.venue_id AND r.user_id=$2 AND r.notification_key=('shift_'||replace(e.action,'shift.','')||':'||e.entity_id::text)
      WHERE e.venue_id=$1 AND e.action IN ('shift.opened','shift.closed') ORDER BY e.created_at DESC LIMIT $3`, [venueId, userId, limit]));
    const results = await Promise.all(queries);
    for (const result of results) {
      unreadCount += Number(result.rows[0]?.sourceUnreadCount || 0);
      items.push(...result.rows.map(({ sourceUnreadCount, ...item }) => item));
    }
  } else {
    const venueMatches = (item) => String(item.venueId || '') === String(venueId);
    const recipientMatches = (item, roles) => !item.notificationRecipients?.length || !req.user?.role || (roles || item.notificationRecipients).includes(req.user.role);
    if (access.discounts) items.push(...discountRequests.filter((item) => venueMatches(item) && item.status === 'requested' && recipientMatches(item, ['owner', 'admin'])).map((item) => ({ id: `discount:${item.id}`, type: 'discount', title: 'Запрошена скидка', summary: 'Запрос ожидает решения', createdAt: item.createdAt, orderId: item.orderId, href: '/orders', requiresAction: true })));
    if (access.autoOrders) items.push(...autoOrderRequests.filter((item) => venueMatches(item) && item.status === 'sent' && recipientMatches(item, ['owner', 'admin', 'manager'])).map((item) => ({ id: `inventory_auto_order:${String(item.id).replace(/^auto-order:/, '')}`, type: 'inventory_auto_order', title: 'Заявка на пополнение', summary: 'Заявка отправлена и ожидает обработки', createdAt: item.createdAt, autoOrderId: item.id, href: '/inventory?view=auto-orders', requiresAction: false })));
    if (access.deletedOrders) items.push(...staffNotifications.filter((item) => venueMatches(item) && item.type === 'order_deleted' && recipientMatches(item, ['owner', 'admin', 'manager'])).map((item) => ({ id: `${item.type}:${item.id}`, type: item.type, title: 'Заказ удалён', summary: 'Проверьте событие в журнале заказов', createdAt: item.createdAt, ...(item.orderId ? { orderId: item.orderId } : {}), href: '/orders', requiresAction: false })));
    if (access.shifts) items.push(...auditEvents.filter((item) => venueMatches(item) && ['shift.opened', 'shift.closed'].includes(item.action)).map((item) => { const type = item.action === 'shift.opened' ? 'shift_opened' : 'shift_closed'; return { id: `${type}:${item.entityId}`, type, title: type === 'shift_opened' ? 'Смена открыта' : 'Смена закрыта', summary: type === 'shift_opened' ? 'Проверьте состояние текущей смены' : 'Смена закрыта и сохранена в журнале', createdAt: item.createdAt, shiftId: item.entityId, href: '/admin#shift-control', requiresAction: false }; }));
    items.forEach((item) => { const key = `${venueId}:${userId}:${item.id}`; item.readAt = notificationMemoryReads.get(key) || null; });
    unreadCount = items.filter((item) => !item.readAt).length;
  }
  items.sort((left, right) => Number(Boolean(right.requiresAction)) - Number(Boolean(left.requiresAction)) || new Date(right.createdAt || 0) - new Date(left.createdAt || 0) || String(right.id).localeCompare(String(left.id)));
  return { items, unreadCount };
}
const employeeNeedsShift = (req) => process.env.AUTH_REQUIRED === 'true' && ['bartender', 'hookah_master', 'senior_bartender', 'senior_hookah_master', 'staff', 'manager'].includes(req.user?.role);
const requireOpenShift = async (req, res) => {
  if (!employeeNeedsShift(req)) return false;
  try {
    if (repositories?.pool) {
      const result = await repositories.pool.query('SELECT 1 FROM shifts WHERE venue_id=$1 AND closed_at IS NULL LIMIT 1', [req.user?.venueId || defaultVenueDbId]);
      if (result.rows[0]) return false;
    } else if (shifts.some((entry) => !entry.closedAt)) return false;
  } catch (_) { json(res, 503, { error: 'shift_status_unavailable' }); return true; }
  json(res, 409, { error: 'active_shift_required', message: 'Откройте смену перед началом работы' }); return true;
};

async function api(req, res) {
  let venueDbId = defaultVenueDbId;
  const url = new URL(req.url, 'http://localhost');
  const pathname = url.pathname;
  if (req.method === 'OPTIONS') { const headers = { 'Access-Control-Allow-Methods': 'GET,POST,PATCH,PUT,DELETE,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Access-Control-Max-Age': '600', 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'Content-Security-Policy': "default-src 'self'; frame-ancestors 'none'" }; if (process.env.CORS_ORIGIN) headers['Access-Control-Allow-Origin'] = process.env.CORS_ORIGIN; res.writeHead(204, headers); return res.end(); }
  const clientIp = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').split(',')[0].trim();
  const now = Date.now(); const bucket = requestBuckets.get(clientIp); const activeBucket = bucket && now - bucket.startedAt < API_RATE_WINDOW_MS ? bucket : { startedAt: now, count: 0 }; activeBucket.count += 1; requestBuckets.set(clientIp, activeBucket);
  if (activeBucket.count > API_RATE_LIMIT) { res.setHeader('Retry-After', '60'); return json(res, 429, { error: 'rate_limited', retryAfter: 60 }); }
  if (Number(req.headers['content-length'] || 0) > 2 * 1024 * 1024) return json(res, 413, { error: 'payload_too_large', maxBytes: 2 * 1024 * 1024 });
  if (pathname === '/api/setup/status' && req.method === 'GET') {
    if (!firstRunSetupEnabled) return json(res, 200, { required: false });
    if (repositories?.pool) {
      try { const { rows } = await repositories.pool.query('SELECT COUNT(*)::int AS count FROM users WHERE is_active=true AND deleted_at IS NULL'); return json(res, 200, { required: Number(rows[0]?.count || 0) === 0 }); } catch (_) { return json(res, 503, { error: 'setup_status_unavailable' }); }
    }
    // First-run provisioning must only be offered when it can be persisted.
    // A local/static test runtime without a database should remain on sign-in.
    return json(res, 200, { required: false });
  }
  if (pathname === '/api/setup/owner' && req.method === 'POST') {
    if (!firstRunSetupEnabled) return json(res, 404, { error: 'setup_disabled' });
    const input = await body(req);
    if (String(input.website || '').trim()) return json(res, 400, { error: 'bot_detected' });
    const venueName = String(input.venueName || '').trim();
    const ownerName = String(input.ownerName || '').trim();
    const ownerLogin = String(input.ownerLogin || '').trim().toLowerCase();
    const ownerPassword = String(input.ownerPassword || '');
    const city = String(input.city || '').trim();
    const timezone = input.timezone === undefined ? 'Europe/Moscow' : String(input.timezone).trim();
    if (!venueName || venueName.length > 120 || !ownerName || ownerName.length > 120 || !/^[^\s@]+@[^\s@]+$/.test(ownerLogin) || ownerPassword.length < 8 || !isValidIanaTimezone(timezone)) return json(res, 400, { error: 'valid_setup_data_required' });
    if (!repositories?.pool) return json(res, 503, { error: 'setup_requires_database' });
    {
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        await client.query("SELECT pg_advisory_xact_lock(hashtext('territory_crm_first_run_setup'))");
        const setupState = await client.query('SELECT COUNT(*)::int AS count FROM users WHERE is_active=true AND deleted_at IS NULL');
        if (Number(setupState.rows[0]?.count || 0) > 0) {
          await client.query('ROLLBACK');
          return json(res, 409, { error: 'setup_already_completed' });
        }
        const existing = await client.query('SELECT 1 FROM users WHERE login=$1 AND is_active=true LIMIT 1', [ownerLogin]);
        if (existing.rows[0]) { await client.query('ROLLBACK'); return json(res, 409, { error: 'owner_login_already_exists' }); }
        const orgResult = await client.query('INSERT INTO organizations (name,slug,plan,timezone) VALUES ($1,$2,$3,$4) RETURNING id', [venueName, `venue-${Date.now()}`, 'starter', timezone]);
        const organizationId = orgResult.rows[0].id;
        await client.query(`INSERT INTO organization_subscriptions (organization_id,plan,status,seats_limit,venues_limit) VALUES ($1,'starter','trialing',$2,$3)`, [organizationId, saasPlans.starter.seatsLimit, saasPlans.starter.venuesLimit]);
        const venueResult = await client.query('INSERT INTO venues (organization_id,name,city,format,timezone,is_current) VALUES ($1,$2,$3,$4,$5,true) RETURNING id', [organizationId, venueName, city, 'кальян-бар', timezone]);
        const passwordHash = await hashPassword(ownerPassword);
        const ownerResult = await client.query(`INSERT INTO users (venue_id,organization_id,full_name,login,password_hash,pin_hash,role) VALUES ($1,$2,$3,$4,$5,NULL,'owner') RETURNING id,full_name AS name,login,role`, [venueResult.rows[0].id, organizationId, ownerName, ownerLogin, passwordHash]);
        await client.query('INSERT INTO organization_memberships (organization_id,user_id,membership_role,status) VALUES ($1,$2,\'owner\',\'active\')', [organizationId, ownerResult.rows[0].id]);
        await client.query('COMMIT');
        return json(res, 201, { ok: true, owner: ownerResult.rows[0] });
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'setup_failed', detail: error.message }); }
      finally { client.release(); }
    }
  }
  if (pathname === '/api/login' && req.method === 'POST') {
    const input = await body(req);
    if (input.resetToken && input.newPassword && !repositories?.pool) return json(res, 503, { error: 'password_reset_requires_database' });
    if (input.resetToken && input.newPassword && repositories?.pool) { const tokenHash = crypto.createHash('sha256').update(String(input.resetToken)).digest('hex'); const newPassword = String(input.newPassword); if (newPassword.length < 8) return json(res, 400, { error: 'password_too_short' }); try { const client = await repositories.pool.connect(); try { await client.query('BEGIN'); const result = await client.query('SELECT id,login,organization_id AS \"organizationId\" FROM users WHERE password_reset_token_hash=$1 AND password_reset_expires_at>now() AND is_active=true AND deleted_at IS NULL FOR UPDATE', [tokenHash]); if (!result.rows[0]) { await client.query('ROLLBACK'); return json(res, 400, { error: 'reset_token_invalid_or_expired' }); } const row = result.rows[0]; await client.query('UPDATE users SET password_hash=$1,password_reset_token_hash=NULL,password_reset_expires_at=NULL WHERE id=$2', [await hashPassword(newPassword), row.id]); await client.query('DELETE FROM auth_sessions WHERE user_id=$1', [row.id]); await client.query('COMMIT'); recordAudit(req, 'auth.password_reset_completed', 'organization_owner', row.id, null, { organizationId: row.organizationId, login: row.login }); return json(res, 200, { ok: true, login: row.login }); } catch (error) { await client.query('ROLLBACK').catch(()=>{}); return json(res, 503, { error: 'password_reset_failed' }); } finally { client.release(); } } catch (_) { return json(res, 503, { error: 'authentication_unavailable' }); } }
    if (process.env.DATABASE_URL && (!repositories?.pool || !sessionRepository)) return json(res, 503, { error: 'authentication_unavailable' });
    if (String(input.website || '').trim()) return json(res, 400, { error: 'bot_detected' });
    const loginKey = String(input.username || '').trim().toLowerCase() || 'anonymous';
    const requestedPin = ''; // PIN используется только для разблокировки экрана, не для входа
    const attempt = loginAttempts.get(loginKey);
    if (attempt && attempt.blockedUntil > Date.now()) return json(res, 429, { error: 'too_many_login_attempts', retryAfter: Math.ceil((attempt.blockedUntil - Date.now()) / 1000) });
    let account = null;
    // The configured platform owner is an infrastructure identity, not a tenant
    // row. It must remain available when PostgreSQL is enabled; tenant users are
    // still resolved from the database below.
    const configuredPlatformOwner = demoAccounts.find((entry) => entry.role === 'platform_owner' && entry.username === loginKey && entry.password === input.password);
    if (configuredPlatformOwner) account = configuredPlatformOwner;
    if (!account && !process.env.DATABASE_URL) {
      account = [...demoAccounts, ...provisionedAccounts].find((entry) => entry.username === loginKey && ((requestedPin && entry.pin === requestedPin) || (!requestedPin && entry.password === input.password)));
      if (!account) { const person = staff.find((entry) => entry.active && entry.login === input.username); const credential = input.password; if (person && credential && await verifyPassword(credential, person.passwordHash)) account = { username: person.login, id: person.id, organizationId: person.organizationId || saasAccount.id, name: person.name, role: person.role, avatarUrl: person.avatarUrl, telegram: person.telegram, phoneNumbers: person.phoneNumbers, permissionScopes: person.permissionScopes || [], pinHash: person.pinHash || null, pinConfigured: Boolean(person.pinHash || person.pinCode) }; }
    }
    if (!account && repositories?.pool) {
      try {
        const { rows } = await repositories.pool.query('SELECT u.id,u.login,u.organization_id AS "organizationId",u.venue_id AS "venueId",u.full_name AS name,u.role,u.custom_role_id AS "customRoleId",cr.permission_scopes AS "customRolePermissionScopes",u.password_hash AS "passwordHash",u.pin_hash,u.pin_updated_at,u.preferences,u.avatar_url AS "avatarUrl",u.telegram_url AS telegram,u.phone_numbers AS "phoneNumbers",u.permission_scopes AS "permissionScopes" FROM users u LEFT JOIN custom_staff_roles cr ON cr.id=u.custom_role_id AND cr.venue_id=u.venue_id AND cr.is_active=true WHERE u.login=$1 AND u.is_active=true LIMIT 1', [input.username]);
        const row = rows[0]; const credential = input.password; if (row && credential && await verifyPassword(credential, row.passwordHash)) {
          if (!row.organizationId || !/^[0-9a-f-]{36}$/i.test(row.organizationId)) return json(res, 403, { error: 'organization_context_required' });
          const accessError = await enforceOrganizationAccess({ id: row.id, organizationId: row.organizationId, role: row.role });
          if (accessError) return json(res, accessError.status, { error: accessError.error });
          account = { username: row.login, id: row.id, organizationId: row.organizationId || null, venueId: row.venueId || null, name: row.name, role: row.role, customRoleId: row.customRoleId || null, customRolePermissionScopes: row.customRolePermissionScopes || [], avatarUrl: row.avatarUrl, telegram: row.telegram || null, phoneNumbers: row.phoneNumbers || [], permissionScopes: row.permissionScopes || [], preferences: row.preferences || {}, pinHash: row.pin_updated_at ? row.pin_hash : null, pinConfigured: Boolean(row.pin_updated_at) };
        }
      } catch (_) { return json(res, 503, { error: 'authentication_unavailable' }); }
    }
    if (!account) { const current = loginAttempts.get(loginKey) || { count: 0, firstAt: Date.now() }; const withinWindow = Date.now() - current.firstAt < 60_000; const next = withinWindow ? { count: current.count + 1, firstAt: current.firstAt } : { count: 1, firstAt: Date.now() }; if (next.count >= 5) next.blockedUntil = Date.now() + 60_000; loginAttempts.set(loginKey, next); return json(res, next.blockedUntil ? 429 : 401, { error: next.blockedUntil ? 'too_many_login_attempts' : 'invalid_credentials', ...(next.blockedUntil ? { retryAfter: 60 } : {}) }); }
    loginAttempts.delete(loginKey);
    const userId = account.id || (account.username === 'owner' ? '20000000-0000-0000-0000-000000000001' : '20000000-0000-0000-0000-000000000002');
    const organizationId = account.organizationId === undefined ? '00000000-0000-0000-0000-000000000010' : account.organizationId;
    const userVenueId = account.venueId || null;
    const preferenceAccountKey = `${organizationId || 'none'}:${account.id || account.username}`;
    if (!repositories?.pool && !memoryPreferencesByAccount.has(preferenceAccountKey)) memoryPreferencesByAccount.set(preferenceAccountKey, account.preferences || {});
    const accountPreferences = repositories?.pool ? (account.preferences || {}) : memoryPreferencesByAccount.get(preferenceAccountKey);
    const token = crypto.randomBytes(32).toString('hex');
    const cookies = requestCookies(req);
    const deviceId = cookies.crm_device_id || crypto.randomUUID();
    const sameDeviceTokens = [...sessions.entries()].filter(([, session]) => session.user?.id === userId && session.deviceId === deviceId).map(([sessionToken]) => sessionToken);
    sameDeviceTokens.forEach((sessionToken) => sessions.delete(sessionToken));
    if (!sessionRepository) {
      const activeUserSessions = [...sessions.values()].filter((session) => session.user?.id === userId && Date.now() - session.createdAt <= SESSION_TTL_MS);
      if (activeUserSessions.length >= 2) return json(res, 409, { error: 'session_limit_reached', limit: 2 });
    }
    const ttlMs = input.trustDevice && canUseTrustedDevice(account.role) ? TRUSTED_SESSION_TTL_MS : STANDARD_SESSION_TTL_MS;
    const expiresAt = Date.now() + ttlMs;
    // The platform owner is an infrastructure identity and may not have a
    // tenant row for the auth_sessions foreign key. Keep that session in the
    // process memory; tenant users continue to use persisted PostgreSQL sessions.
    if (sessionRepository && account.role !== 'platform_owner') { try { const saved = await sessionRepository.create({ userId, deviceId, tokenHash: hashToken(token), expiresAt: new Date(expiresAt).toISOString(), activeVenueId: userVenueId }); if (!saved) return json(res, 409, { error: 'session_limit_reached', limit: 2 }); } catch (_) { return json(res, 503, { error: 'session_unavailable' }); } }
    if (!account.pinHash && account.pin) account.pinHash = await hashPassword(account.pin);
    sessions.set(token, { user: { id: userId, organizationId, venueId: userVenueId, name: account.name, role: account.role, customRoleId: account.customRoleId || null, customRolePermissionScopes: normalizePermissionScopes(account.customRolePermissionScopes), avatarUrl: account.avatarUrl || null, telegram: account.telegram || '', phoneNumbers: account.phoneNumbers || [], permissionScopes: normalizePermissionScopes(account.permissionScopes), preferences: accountPreferences, pinConfigured: Boolean(account.pinConfigured || account.pinHash) }, preferenceAccountKey, unlockHash: account.pinHash || null, deviceId, createdAt: Date.now(), expiresAt });
    [...sessions.entries()].filter(([, session]) => session.user?.id === userId).sort(([, left], [, right]) => right.createdAt - left.createdAt).slice(2).forEach(([sessionToken]) => sessions.delete(sessionToken));
    res.setHeader('Set-Cookie', [`crm_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${sessionTtlSeconds(ttlMs)}${process.env.COOKIE_SECURE === 'true' ? '; Secure' : ''}`, `crm_device_id=${encodeURIComponent(deviceId)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=31536000${process.env.COOKIE_SECURE === 'true' ? '; Secure' : ''}`]);
    return json(res, 200, { token, user: { id: userId, organizationId, venueId: userVenueId, name: account.name, role: account.role, customRoleId: account.customRoleId || null, customRolePermissionScopes: normalizePermissionScopes(account.customRolePermissionScopes), avatarUrl: account.avatarUrl || null, telegram: account.telegram || '', phoneNumbers: account.phoneNumbers || [], permissionScopes: normalizePermissionScopes(account.permissionScopes), preferences: accountPreferences, pinConfigured: Boolean(account.pinConfigured || account.pinHash) }, permissions: effectivePermissions({ role: account.role, customRolePermissionScopes: account.customRolePermissionScopes, permissionScopes: account.permissionScopes }), expiresIn: sessionTtlSeconds(ttlMs), trustedDevice: ttlMs === TRUSTED_SESSION_TTL_MS });
  }
  if (pathname === '/api/logout' && req.method === 'POST') { const header = req.headers.authorization || ''; const cookies = Object.fromEntries((req.headers.cookie || '').split(';').map((part) => part.trim().split('=').map(decodeURIComponent)).filter((parts) => parts.length === 2)); const token = header.startsWith('Bearer ') ? header.slice(7) : (cookies.crm_session || ''); if (token && sessionRepository) sessionRepository.remove(hashToken(token)).catch(() => {}); sessions.delete(token); res.setHeader('Set-Cookie', 'crm_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'); return json(res, 200, { ok: true }); }
  const hasRequestCredential = Boolean((req.headers.authorization || '').startsWith('Bearer ') || String(req.headers.cookie || '').includes('crm_session='));
  if ((process.env.AUTH_REQUIRED === 'true' || hasRequestCredential) && pathname !== '/api/health' && pathname !== '/api/login' && pathname !== '/api/public/venue-brand') {
    const session = await sessionFromRequest(req);
    if (!session) return json(res, 401, { error: 'authentication_required' });
    else {
      req.user = session.user;
      const accessError = await enforceOrganizationAccess(req.user);
      if (accessError) return json(res, accessError.status, { error: accessError.error });
      if (req.user?.venueId && /^[0-9a-f-]{36}$/i.test(req.user.venueId)) venueDbId = req.user.venueId;
      // Refresh cookies issued before the longer session policy so an active
      // browser is not logged out simply because its old cookie reached 8 hours.
      const cookieToken = requestCookies(req).crm_session;
    }
  }
  if (pathname === '/api/health') {
    if (repositories?.pool) {
      try {
        await repositories.pool.query('SELECT 1');
        return json(res, 200, { status: 'ok', service: 'hookah-pos', database: 'postgres' });
      } catch (error) {
        return json(res, 503, { status: 'degraded', service: 'hookah-pos', database: 'unavailable' });
      }
    }
    return json(res, 200, { status: 'ok', service: 'hookah-pos', database: 'memory' });
  }
  if (pathname === '/api/session/unlock' && req.method === 'POST') {
    const input = await body(req); const pin = String(input.pin || '').trim();
    if (!/^\d{4}$/.test(pin)) return json(res, 400, { error: 'invalid_staff_pin_format' });
    const header = req.headers.authorization || ''; const cookies = Object.fromEntries((req.headers.cookie || '').split(';').map((part) => part.trim().split('=').map(decodeURIComponent)).filter((parts) => parts.length === 2)); const token = header.startsWith('Bearer ') ? header.slice(7) : (cookies.crm_session || '');
    const identity = String(req.user?.id || ''); const address = String(req.socket?.remoteAddress || 'unknown'); const attemptKey = `${identity}:${address}`;
    const attempt = pinUnlockAttempts.get(attemptKey);
    if (attempt?.blockedUntil > Date.now()) return json(res, 429, { error: 'too_many_pin_attempts', retryAfter: Math.ceil((attempt.blockedUntil - Date.now()) / 1000) });
    const memorySession = sessions.get(token); let unlockHash = memorySession?.unlockHash || null; let pinConfigured = Boolean(memorySession?.user?.pinConfigured);
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(identity)) {
      try {
        const { rows } = await repositories.pool.query('SELECT pin_hash AS "pinHash",pin_updated_at AS "pinUpdatedAt",is_active AS active FROM users WHERE id=$1 AND venue_id=$2 AND deleted_at IS NULL LIMIT 1', [identity, memorySession?.user?.venueId || venueDbId]);
        unlockHash = rows[0]?.active && rows[0]?.pinUpdatedAt ? rows[0].pinHash : null;
        pinConfigured = Boolean(unlockHash);
      } catch (error) { return json(res, 503, { error: 'unlock_unavailable', detail: error.message }); }
    }
    if (!pinConfigured || !unlockHash) return json(res, 409, { error: 'pin_not_configured' });
    if (!(await verifyPassword(pin, unlockHash))) {
      const withinWindow = attempt && Date.now() - attempt.firstAt < 60_000;
      const next = withinWindow ? { count: attempt.count + 1, firstAt: attempt.firstAt } : { count: 1, firstAt: Date.now() };
      if (next.count >= 5) next.blockedUntil = Date.now() + 60_000;
      pinUnlockAttempts.set(attemptKey, next);
      return json(res, next.blockedUntil ? 429 : 401, { error: next.blockedUntil ? 'too_many_pin_attempts' : 'invalid_pin', ...(next.blockedUntil ? { retryAfter: 60 } : {}) });
    }
    pinUnlockAttempts.delete(attemptKey);
    if (memorySession) { memorySession.unlockHash = unlockHash; memorySession.user.pinConfigured = true; }
    return json(res, 200, { ok: true, token, user: req.user || memorySession?.user || null });
  }
  if (pathname === '/api/session/pin-return' && req.method === 'POST') {
    const trustedPinRoles = new Set(['owner', 'admin', 'developer']);
    if (!trustedPinRoles.has(String(req.user?.role || ''))) return json(res, 403, { error: 'pin_return_role_forbidden' });
    const input = await body(req); const pin = String(input.pin || '').trim();
    if (!/^\d{4}$/.test(pin)) return json(res, 400, { error: 'invalid_staff_pin_format' });
    const token = requestAuthToken(req);
    if (!token) return json(res, 401, { error: 'authentication_required' });
    const identity = String(req.user?.id || ''); const address = String(req.socket?.remoteAddress || 'unknown'); const attemptKey = `${identity}:${address}:return`;
    const attempt = pinUnlockAttempts.get(attemptKey);
    if (attempt?.blockedUntil > Date.now()) return json(res, 429, { error: 'too_many_pin_attempts', retryAfter: Math.ceil((attempt.blockedUntil - Date.now()) / 1000) });
    const memorySession = sessions.get(token); let unlockHash = memorySession?.unlockHash || null; let pinConfigured = Boolean(memorySession?.user?.pinConfigured);
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(identity)) {
      try {
        const { rows } = await repositories.pool.query('SELECT pin_hash AS "pinHash",pin_updated_at AS "pinUpdatedAt",is_active AS active FROM users WHERE id=$1 AND organization_id IS NOT DISTINCT FROM $2::uuid LIMIT 1', [identity, req.user?.organizationId || null]);
        unlockHash = rows[0]?.active && rows[0]?.pinUpdatedAt ? rows[0].pinHash : null;
        pinConfigured = Boolean(unlockHash);
      } catch (error) { return json(res, 503, { error: 'pin_return_unavailable', detail: error.message }); }
    }
    if (!pinConfigured || !unlockHash) return json(res, 409, { error: 'pin_not_configured' });
    if (!(await verifyPassword(pin, unlockHash))) {
      const withinWindow = attempt && Date.now() - attempt.firstAt < 60_000;
      const next = withinWindow ? { count: attempt.count + 1, firstAt: attempt.firstAt } : { count: 1, firstAt: Date.now() };
      if (next.count >= 5) next.blockedUntil = Date.now() + 60_000;
      pinUnlockAttempts.set(attemptKey, next);
      return json(res, next.blockedUntil ? 429 : 401, { error: next.blockedUntil ? 'too_many_pin_attempts' : 'invalid_pin', ...(next.blockedUntil ? { retryAfter: 60 } : {}) });
    }
    pinUnlockAttempts.delete(attemptKey);
    if (memorySession) { memorySession.unlockHash = unlockHash; memorySession.user.pinConfigured = true; }
    if (req.user) req.user.pinConfigured = true;
    const user = memorySession?.user || req.user;
    return json(res, 200, { token, user, permissions: effectivePermissions(user), expiresIn: sessionTtlSeconds(TRUSTED_SESSION_TTL_MS), trustedDevice: true });
  }
  if (pathname === '/api/session/preferences' && (req.method === 'GET' || req.method === 'PATCH')) {
    const allowed = new Set(['lockTimeoutMinutes', 'dashboardModules', 'dashboardRevenueStyle', 'insights', 'deliveryEnabled', 'integrationsEnabled', 'navigationVisibility', 'financeMetrics', 'theme']);
    const header = req.headers.authorization || ''; const cookies = Object.fromEntries((req.headers.cookie || '').split(';').map((part) => part.trim().split('=').map(decodeURIComponent)).filter((parts) => parts.length === 2)); const token = header.startsWith('Bearer ') ? header.slice(7) : (cookies.crm_session || '');
    const memorySession = sessions.get(token);
    if (req.method === 'GET') {
      if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(req.user?.id || '')) {
        try {
          const { rows } = await repositories.pool.query('SELECT preferences FROM users WHERE id=$1 AND organization_id IS NOT DISTINCT FROM $2::uuid AND is_active=true LIMIT 1', [req.user.id, req.user.organizationId || null]);
          if (!rows[0]) return json(res, 404, { error: 'user_not_found' });
          if (memorySession) memorySession.user.preferences = rows[0].preferences || {};
          return json(res, 200, { preferences: rows[0].preferences || {} });
        } catch (_) { return json(res, 503, { error: 'preferences_load_failed' }); }
      }
      return json(res, 200, { preferences: memoryPreferencesByAccount.get(memorySession?.preferenceAccountKey) || memorySession?.user?.preferences || {} });
    }
    const input = await body(req); const incoming = input && typeof input.preferences === 'object' && !Array.isArray(input.preferences) ? input.preferences : input;
    if (!incoming || typeof incoming !== 'object') return json(res, 400, { error: 'preferences_object_required' });
    const patch = {}; for (const [key, value] of Object.entries(incoming)) if (allowed.has(key)) patch[key] = value;
    if (Object.prototype.hasOwnProperty.call(patch, 'lockTimeoutMinutes') && ![0, 1, 5, 10, 15, 30].includes(Number(patch.lockTimeoutMinutes))) return json(res, 400, { error: 'invalid_lock_timeout' });
    if (Object.prototype.hasOwnProperty.call(patch, 'dashboardRevenueStyle') && !['hero', 'split', 'minimal'].includes(String(patch.dashboardRevenueStyle))) return json(res, 400, { error: 'invalid_dashboard_revenue_style' });
    if (Object.prototype.hasOwnProperty.call(patch, 'theme') && !['light', 'dark'].includes(patch.theme)) return json(res, 400, { error: 'invalid_theme_preference' });
    if (Object.prototype.hasOwnProperty.call(patch, 'navigationVisibility') && (!patch.navigationVisibility || typeof patch.navigationVisibility !== 'object' || Array.isArray(patch.navigationVisibility) || Object.entries(patch.navigationVisibility).some(([key, value]) => !['orders','clients','reservations','floor','delivery','inventory','finance','discounts','loyalty','staff','integrations'].includes(key) || typeof value !== 'boolean'))) return json(res, 400, { error: 'invalid_navigation_visibility' });
    for (const key of ['deliveryEnabled', 'integrationsEnabled']) if (Object.prototype.hasOwnProperty.call(patch, key) && typeof patch[key] !== 'boolean') return json(res, 400, { error: `invalid_${key}` });
    for (const key of ['dashboardModules', 'insights', 'financeMetrics']) if (Object.prototype.hasOwnProperty.call(patch, key) && (!patch[key] || typeof patch[key] !== 'object' || Array.isArray(patch[key]))) return json(res, 400, { error: `invalid_${key}_preferences` });
    const nestedKeys = ['dashboardModules', 'insights', 'financeMetrics', 'navigationVisibility'];
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(req.user?.id || '')) {
      try {
        let merged = "COALESCE(preferences,'{}'::jsonb) || $1::jsonb";
        for (const key of nestedKeys) if (Object.prototype.hasOwnProperty.call(patch, key)) merged = `jsonb_set(${merged}, '{${key}}', COALESCE(preferences->'${key}','{}'::jsonb) || ($1::jsonb->'${key}'), true)`;
        const { rows } = await repositories.pool.query(`UPDATE users SET preferences=${merged} WHERE id=$2 AND organization_id IS NOT DISTINCT FROM $3::uuid AND is_active=true RETURNING preferences`, [JSON.stringify(patch), req.user.id, req.user.organizationId || null]);
        if (!rows[0]) return json(res, 404, { error: 'user_not_found' });
        const preferences = rows[0].preferences || {};
        for (const session of sessions.values()) if (session.user?.id === req.user.id && session.user?.organizationId === req.user.organizationId) session.user.preferences = preferences;
        return json(res, 200, { preferences });
      } catch (error) { return json(res, 503, { error: 'preferences_save_failed', detail: error.message }); }
    }
    const current = memoryPreferencesByAccount.get(memorySession?.preferenceAccountKey) || memorySession?.user?.preferences || {};
    const next = { ...current, ...patch };
    for (const key of nestedKeys) if (Object.prototype.hasOwnProperty.call(patch, key)) next[key] = { ...((current[key] && typeof current[key] === 'object' && !Array.isArray(current[key])) ? current[key] : {}), ...patch[key] };
    if (memorySession?.preferenceAccountKey) {
      memoryPreferencesByAccount.set(memorySession.preferenceAccountKey, next);
      for (const session of sessions.values()) if (session.preferenceAccountKey === memorySession.preferenceAccountKey) session.user.preferences = next;
    }
    return json(res, 200, { preferences: next });
  }
  if (pathname === '/api/public/venue-brand' && req.method === 'GET') {
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query('SELECT name,logo_url AS "logoUrl" FROM venues WHERE id=$1', [venueDbId]); if (rows[0]) return json(res, 200, rows[0]); } catch (_) {} }
    return json(res, 200, { name: venue.name, logoUrl: venue.logoUrl || null });
  }
  const notificationReadPath = pathname.match(/^\/api\/notifications\/([^/]+)\/read$/);
  if (pathname === '/api/notifications' && ['GET', 'POST'].includes(req.method) || notificationReadPath && req.method === 'PUT') {
    const access = notificationAccess(req);
    if (!access || !Object.values(access).some(Boolean)) return json(res, 403, { error: 'forbidden', permission: 'notifications' });
    if (repositories?.pool && !/^[0-9a-f-]{36}$/i.test(String(req.user?.id || ''))) return json(res, 401, { error: 'authentication_required' });
    if (req.method === 'GET') {
      const limitValue = Number(url.searchParams.get('limit') || 20);
      const limit = Number.isInteger(limitValue) ? Math.min(50, Math.max(1, limitValue)) : 20;
      const unreadOnly = url.searchParams.get('filter') === 'unread';
      try {
    const notificationVenueId = notificationVenueScope(req, venueDbId);
    const data = await collectNotificationEvents(req, notificationVenueId, 100);
        if (!data) return json(res, 403, { error: 'forbidden', permission: 'notifications' });
        const items = data.items.filter((item) => !unreadOnly || !item.readAt).slice(0, limit);
        return json(res, 200, { items, unreadCount: data.unreadCount, hasMore: data.items.filter((item) => !unreadOnly || !item.readAt).length > limit });
      } catch (_) { return json(res, 503, { error: 'notifications_unavailable' }); }
    }
    if (req.method === 'POST') {
      try {
        if (repositories?.pool) {
          const userId = req.user.id;
          const inserts = [];
          if (access.discounts) inserts.push(repositories.pool.query(`INSERT INTO notification_reads (venue_id,user_id,notification_key)
            SELECT o.venue_id,$2,'discount:'||d.id::text FROM discounts d JOIN orders o ON o.id=d.order_id WHERE o.venue_id=$1 AND d.status='requested'
            ON CONFLICT (venue_id,user_id,notification_key) DO UPDATE SET read_at=now()`, [venueDbId, userId]));
          if (access.autoOrders) inserts.push(repositories.pool.query(`INSERT INTO notification_reads (venue_id,user_id,notification_key)
            SELECT a.venue_id,$2,'inventory_auto_order:'||a.id::text FROM inventory_auto_orders a WHERE a.venue_id=$1 AND a.status='sent'
            ON CONFLICT (venue_id,user_id,notification_key) DO UPDATE SET read_at=now()`, [venueDbId, userId]));
          if (access.deletedOrders) inserts.push(repositories.pool.query(`INSERT INTO notification_reads (venue_id,user_id,notification_key)
            SELECT e.venue_id,$2,'order_deleted:'||e.id::text FROM audit_events e WHERE e.venue_id=$1 AND e.action='order.deleted'
            ON CONFLICT (venue_id,user_id,notification_key) DO UPDATE SET read_at=now()`, [venueDbId, userId]));
          if (access.shifts) inserts.push(repositories.pool.query(`INSERT INTO notification_reads (venue_id,user_id,notification_key)
            SELECT e.venue_id,$2,'shift_'||replace(e.action,'shift.','')||':'||e.entity_id::text FROM audit_events e WHERE e.venue_id=$1 AND e.action IN ('shift.opened','shift.closed')
            ON CONFLICT (venue_id,user_id,notification_key) DO UPDATE SET read_at=now()`, [venueDbId, userId]));
          if (access.staffPins) inserts.push(repositories.pool.query(`INSERT INTO notification_reads (venue_id,user_id,notification_key)
            SELECT e.venue_id,$2,'staff_pin_updated:'||e.id::text FROM audit_events e WHERE e.venue_id=$1 AND e.action='staff.pin_updated'
            ON CONFLICT (venue_id,user_id,notification_key) DO UPDATE SET read_at=now()`, [venueDbId, userId]));
          await Promise.all(inserts);
          const data = await collectNotificationEvents(req, notificationVenueScope(req, venueDbId), 100);
          return json(res, 200, { unreadCount: data?.unreadCount || 0 });
        }
        const notificationVenueId = notificationVenueScope(req, venueDbId);
        const data = await collectNotificationEvents(req, notificationVenueId, 10000);
        if (!data) return json(res, 403, { error: 'forbidden', permission: 'notifications' });
        for (const item of data.items) notificationMemoryReads.set(`${notificationVenueId}:${req.user?.id || 'anonymous'}:${item.id}`, new Date().toISOString());
        const refreshed = await collectNotificationEvents(req, notificationVenueId, 10000);
        return json(res, 200, { unreadCount: refreshed?.unreadCount || 0 });
      } catch (_) { return json(res, 503, { error: 'notifications_unavailable' }); }
    }
    let notificationId;
    try { notificationId = decodeURIComponent(notificationReadPath[1]); } catch (_) { return json(res, 400, { error: 'invalid_notification_id' }); }
    if (!/^(discount|inventory_auto_order|order_deleted|shift_opened|shift_closed):[A-Za-z0-9-]{1,150}$/.test(notificationId)) return json(res, 404, { error: 'notification_not_found' });
    const type = notificationId.slice(0, notificationId.indexOf(':'));
    if ((type === 'discount' && !access.discounts) || (type === 'inventory_auto_order' && !access.autoOrders) || (type === 'order_deleted' && !access.deletedOrders) || (type.startsWith('shift_') && !access.shifts)) return json(res, 404, { error: 'notification_not_found' });
    try {
      if (repositories?.pool) {
        const notificationVenueId = notificationVenueScope(req, venueDbId);
        const available = await collectNotificationEvents(req, notificationVenueId, 10000);
        if (!available?.items.some((item) => item.id === notificationId)) return json(res, 404, { error: 'notification_not_found' });
        await repositories.pool.query(`INSERT INTO notification_reads (venue_id,user_id,notification_key) VALUES ($1,$2,$3)
          ON CONFLICT (venue_id,user_id,notification_key) DO UPDATE SET read_at=now()`, [venueDbId, req.user.id, notificationId]);
      } else {
        const notificationVenueId = notificationVenueScope(req, venueDbId);
        const available = await collectNotificationEvents(req, notificationVenueId, 10000);
        if (!available?.items.some((item) => item.id === notificationId)) return json(res, 404, { error: 'notification_not_found' });
        notificationMemoryReads.set(`${notificationVenueId}:${req.user?.id || 'anonymous'}:${notificationId}`, new Date().toISOString());
      }
      const refreshed = await collectNotificationEvents(req, notificationVenueScope(req, venueDbId), 10000);
      return json(res, 200, { id: notificationId, readAt: new Date().toISOString(), unreadCount: refreshed?.unreadCount || 0 });
    } catch (_) { return json(res, 503, { error: 'notifications_unavailable' }); }
  }
  if (pathname === '/api/saas/account' && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['settings', 'diagnostics'])) return;
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(venueDbId)) {
      try {
        const { rows } = await repositories.pool.query(`SELECT o.id,o.name,o.slug,o.plan,o.timezone,
          COALESCE(s.status,'trialing') AS "subscriptionStatus",COALESCE(s.plan,o.plan) AS "subscriptionPlan",
          COALESCE(s.seats_limit,5) AS "seatsLimit",COALESCE(s.venues_limit,1) AS "venuesLimit",
          (SELECT COUNT(*)::int FROM users u WHERE u.organization_id=o.id AND u.is_active=true) AS "activeSeats",
          (SELECT COUNT(*)::int FROM venues v2 WHERE v2.organization_id=o.id AND v2.is_active=true) AS "activeVenues"
          FROM organizations o
          LEFT JOIN organization_subscriptions s ON s.organization_id=o.id WHERE o.id=$1 LIMIT 1`, [req.user?.organizationId || saasAccount.id]);
        if (rows[0]) return json(res, 200, { ...rows[0], seatsLimit: Number(rows[0].seatsLimit), venuesLimit: Number(rows[0].venuesLimit), activeSeats: Number(rows[0].activeSeats), activeVenues: Number(rows[0].activeVenues) });
      } catch (_) { return json(res, 503, { error: 'saas_account_unavailable' }); }
      return json(res, 404, { error: 'organization_not_found' });
    }
    const account = saasOrganizations.find((item) => item.id === req.user?.organizationId) || saasAccount;
    return json(res, 200, { ...account, subscriptionStatus: account.status || account.subscriptionStatus || 'trialing', subscriptionPlan: account.plan, activeSeats: Number(account.seats ?? staff.filter((person) => person.active).length), activeVenues: Number(account.venues ?? networkVenues.filter((item) => item.status !== 'archived').length) });
  }
  if (pathname === '/api/platform/plans' && req.method === 'GET') {
    if (denyUnless(req, res, 'platform')) return;
    return json(res, 200, { billingMode: 'test_free', currency: 'RUB', plans: saasPlans });
  }
  if (pathname === '/api/platform/overview' && req.method === 'GET') {
    if (denyUnless(req, res, 'platform')) return;
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query(`SELECT COUNT(*)::int AS companies, COUNT(*) FILTER (WHERE is_active=true)::int AS active_companies FROM organizations`); const subs = await repositories.pool.query(`SELECT COUNT(*)::int AS trials FROM organization_subscriptions WHERE status='trialing'`); return json(res, 200, { companies: Number(rows[0]?.companies || 0), activeCompanies: Number(rows[0]?.active_companies || 0), trials: Number(subs.rows[0]?.trials || 0) }); } catch (_) { return json(res, 503, { error: 'platform_overview_unavailable' }); } }
    return json(res, 200, { companies: saasOrganizations.length, activeCompanies: saasOrganizations.filter((item) => item.isActive).length, trials: saasOrganizations.filter((item) => item.status === 'trialing').length });
  }
  if (pathname === '/api/platform/organizations' && req.method === 'GET') {
    if (denyUnless(req, res, 'platform')) return;
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query(`SELECT o.id,o.name,o.slug,o.plan,o.is_active AS "isActive",o.created_at AS "createdAt",o.timezone,COALESCE(s.status,'trialing') AS status,(SELECT COUNT(*)::int FROM venues v WHERE v.organization_id=o.id AND v.is_active=true) AS venues,(SELECT COUNT(*)::int FROM users u WHERE u.organization_id=o.id AND u.is_active=true) AS seats,(SELECT city FROM venues v2 WHERE v2.organization_id=o.id ORDER BY v2.created_at LIMIT 1) AS city,(SELECT json_agg(json_build_object('id',u.id,'name',u.full_name,'login',u.login,'active',u.is_active,'isPrimary',m.is_primary) ORDER BY u.full_name) FROM users u JOIN organization_memberships m ON m.user_id=u.id AND m.organization_id=o.id WHERE u.organization_id=o.id AND m.membership_role='owner' AND u.deleted_at IS NULL) AS owners FROM organizations o LEFT JOIN organization_subscriptions s ON s.organization_id=o.id ORDER BY o.created_at DESC`); return json(res, 200, { items: rows }); } catch (_) { return json(res, 503, { error: 'platform_organizations_unavailable' }); } }
    return json(res, 200, { items: saasOrganizations.slice().reverse().map((item) => ({ ...item, ...(saasPlans[item.plan] || saasPlans.starter), monthlyPrice: 0 })) });
  }
  if (pathname === '/api/platform/organizations' && req.method === 'POST') {
    if (denyUnless(req, res, 'platform')) return;
    const input = await body(req);
    const name = String(input.name || '').trim();
    const transliteration = { а:'a', б:'b', в:'v', г:'g', д:'d', е:'e', ё:'e', ж:'zh', з:'z', и:'i', й:'y', к:'k', л:'l', м:'m', н:'n', о:'o', п:'p', р:'r', с:'s', т:'t', у:'u', ф:'f', х:'h', ц:'c', ч:'ch', ш:'sh', щ:'sh', ъ:'', ы:'y', ь:'', э:'e', ю:'yu', я:'ya' };
    const generatedSlug = name.toLowerCase().replace(/[а-яё]/g, (letter) => transliteration[letter] || '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    const slug = String(input.slug || generatedSlug || `company-${Date.now()}`).trim().toLowerCase();
    const ownerName = String(input.ownerName || '').trim();
    const ownerLogin = String(input.ownerLogin || '').trim().toLowerCase();
    const ownerPassword = String(input.ownerPassword || '');
    const timezone = input.timezone === undefined ? 'Europe/Moscow' : String(input.timezone).trim();
    const plan = ['starter', 'growth', 'network', 'enterprise'].includes(input.plan) ? input.plan : 'starter';
    if (!name || name.length > 120 || !/^[a-z0-9][a-z0-9-]{1,48}$/.test(slug)) return json(res, 400, { error: 'valid_name_and_slug_required' });
    if (!ownerName || ownerName.length > 120 || !/^[^\s@]+@[^\s@]+$/.test(ownerLogin) || ownerPassword.length < 8) return json(res, 400, { error: 'valid_owner_credentials_required' });
    if (!isValidIanaTimezone(timezone)) return json(res, 400, { error: 'invalid_organization_timezone' });
    if (repositories?.pool) {
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        const org = await client.query(`INSERT INTO organizations (name,slug,plan,timezone) VALUES ($1,$2,$3,$4) RETURNING id,name,slug,plan,is_active AS "isActive",created_at AS "createdAt"`, [name, slug, plan, timezone]);
        const organization = org.rows[0];
        await client.query(`INSERT INTO organization_subscriptions (organization_id,plan,status,seats_limit,venues_limit) VALUES ($1,$2,'trialing',$3,$4)`, [organization.id, plan, saasPlans[plan].seatsLimit, saasPlans[plan].venuesLimit]);
        const venueRow = await client.query(`INSERT INTO venues (organization_id,name,city,address,format,timezone) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`, [organization.id, name, String(input.city || '').trim(), String(input.address || '').trim(), 'кальян-бар', timezone]);
        const passwordHash = await hashPassword(ownerPassword);
        const owner = await client.query(`INSERT INTO users (venue_id,organization_id,full_name,login,password_hash,pin_hash,role) VALUES ($1,$2,$3,$4,$5,NULL,'owner') RETURNING id,full_name AS name,login,role`, [venueRow.rows[0].id, organization.id, ownerName, ownerLogin, passwordHash]);
        await client.query(`INSERT INTO organization_memberships (organization_id,user_id,membership_role,status) VALUES ($1,$2,'owner','active')`, [organization.id, owner.rows[0].id]);
        await client.query('COMMIT');
        recordAudit(req, 'platform.organization_created', 'organization', organization.id, null, { ...organization, ownerLogin });
        return json(res, 201, { ...organization, status: 'trialing', venues: 1, seats: 1, city: input.city || '', owner: owner.rows[0] });
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'organization_create_failed', detail: error.code === '23505' ? 'slug_or_owner_login_already_exists' : error.message }); }
      finally { client.release(); }
    }
    if (saasOrganizations.some((item) => item.slug === slug) || provisionedAccounts.some((item) => item.username === ownerLogin)) return json(res, 409, { error: 'slug_or_owner_login_already_exists' });
    const organizationId = `org-${Date.now()}`;
    const ownerId = crypto.randomUUID();
    const venueId = crypto.randomUUID();
    const item = { id: organizationId, name, slug, plan, status: 'trialing', city: String(input.city || '').trim(), venues: 1, seats: 1, createdAt: new Date().toISOString(), isActive: true, seatsLimit: saasPlans[plan].seatsLimit, venuesLimit: saasPlans[plan].venuesLimit };
    saasOrganizations.push(item);
    provisionedAccounts.push({ id: ownerId, username: ownerLogin, password: ownerPassword, name: ownerName, role: 'owner', organizationId, venueId });
    recordAudit(req, 'platform.organization_created', 'organization', item.id, null, { ...item, ownerLogin });
    return json(res, 201, { ...item, owner: { id: ownerId, name: ownerName, login: ownerLogin, role: 'owner' } });
  }
  const platformOrgSubscription = pathname.match(/^\/api\/platform\/organizations\/([^/]+)\/subscription$/);
  if (platformOrgSubscription && req.method === 'GET') {
    if (denyUnless(req, res, 'platform')) return;
    if (repositories?.pool) {
      if (!/^[0-9a-f-]{36}$/i.test(platformOrgSubscription[1])) return json(res, 404, { error: 'organization_not_found' });
      try { const { rows } = await repositories.pool.query(`SELECT organization_id AS "organizationId",plan,status,billing_mode AS "billingMode",monthly_price_cents AS "monthlyPriceCents",seats_limit AS "seatsLimit",venues_limit AS "venuesLimit",trial_ends_at AS "trialEndsAt" FROM organization_subscriptions WHERE organization_id=$1`, [platformOrgSubscription[1]]); if (rows[0]) return json(res, 200, { ...rows[0], monthlyPrice: Number(rows[0].monthlyPriceCents || 0) / 100 }); return json(res, 404, { error: 'subscription_not_found' }); } catch (_) { return json(res, 503, { error: 'subscription_unavailable' }); }
    }
    const item = saasOrganizations.find((entry) => entry.id === platformOrgSubscription[1]); if (!item) return json(res, 404, { error: 'organization_not_found' }); const plan = saasPlans[item.plan] || saasPlans.starter; return json(res, 200, { organizationId: item.id, plan: item.plan, status: item.status, billingMode: 'test_free', monthlyPrice: 0, seatsLimit: plan.seatsLimit, venuesLimit: plan.venuesLimit, trialEndsAt: item.trialEndsAt || null });
  }
  if (platformOrgSubscription && req.method === 'PATCH') {
    if (denyUnless(req, res, 'platform')) return;
    const input = await body(req);
    const organizationId = platformOrgSubscription[1];
    const planKey = String(input.plan || '');
    const status = input.status === undefined ? undefined : (['active', 'trialing', 'past_due', 'cancelled'].includes(input.status) ? input.status : null);
    if (!saasPlans[planKey]) return json(res, 400, { error: 'invalid_plan' });
    if (status === null) return json(res, 400, { error: 'invalid_subscription_status' });
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(organizationId)) {
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        const beforeResult = await client.query(`SELECT o.id,o.plan,o.is_active AS "isActive",s.status,s.seats_limit AS "seatsLimit",s.venues_limit AS "venuesLimit"
          FROM organizations o LEFT JOIN organization_subscriptions s ON s.organization_id=o.id WHERE o.id=$1 FOR UPDATE OF o`, [organizationId]);
        if (!beforeResult.rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'organization_not_found' }); }
        const before = beforeResult.rows[0];
        const nextStatus = status || before.status || 'trialing';
        await client.query(`INSERT INTO organization_subscriptions (organization_id,plan,status,billing_mode,monthly_price_cents,seats_limit,venues_limit,updated_at)
          VALUES ($1,$2,$3,'test_free',0,$4,$5,now())
          ON CONFLICT (organization_id) DO UPDATE SET plan=EXCLUDED.plan,status=EXCLUDED.status,billing_mode='test_free',monthly_price_cents=0,seats_limit=EXCLUDED.seats_limit,venues_limit=EXCLUDED.venues_limit,updated_at=now()`,
          [organizationId, planKey, nextStatus, saasPlans[planKey].seatsLimit, saasPlans[planKey].venuesLimit]);
        await client.query('UPDATE organizations SET plan=$1,is_active=$2,updated_at=now() WHERE id=$3', [planKey, nextStatus !== 'cancelled', organizationId]);
        await client.query('COMMIT');
        const updated = { organizationId, plan: planKey, status: nextStatus, billingMode: 'test_free', monthlyPrice: 0, seatsLimit: saasPlans[planKey].seatsLimit, venuesLimit: saasPlans[planKey].venuesLimit };
        recordAudit(req, 'platform.subscription_updated', 'organization_subscription', organizationId, before, updated);
        return json(res, 200, updated);
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); return json(res, 503, { error: 'subscription_save_failed', detail: error.message }); }
      finally { client.release(); }
    }
    const item = saasOrganizations.find((entry) => entry.id === organizationId);
    if (!item) return json(res, 404, { error: 'organization_not_found' });
    const before = { ...item };
    item.plan = planKey;
    item.status = status || item.status;
    item.isActive = item.status !== 'cancelled';
    Object.assign(item, { seatsLimit: saasPlans[planKey].seatsLimit, venuesLimit: saasPlans[planKey].venuesLimit, monthlyPrice: 0 });
    recordAudit(req, 'platform.subscription_updated', 'organization_subscription', item.id, before, item);
    return json(res, 200, { organizationId: item.id, plan: item.plan, status: item.status, billingMode: 'test_free', monthlyPrice: 0, seatsLimit: item.seatsLimit, venuesLimit: item.venuesLimit });
  }
  const platformOrgPath = pathname.match(/^\/api\/platform\/organizations\/([^/]+)$/);
  const platformOwnersPath = pathname.match(/^\/api\/platform\/organizations\/([^/]+)\/owners(?:\/([^/]+))?(?:\/(reset|transfer))?$/);
  if (platformOwnersPath && ['GET','POST','PATCH','DELETE'].includes(req.method) || (platformOwnersPath && req.method === 'POST')) {
    if (denyUnless(req, res, 'platform')) return;
    const organizationId = platformOwnersPath[1]; const targetId = platformOwnersPath[2]; const action = platformOwnersPath[3];
    if (!repositories?.pool || !/^[0-9a-f-]{36}$/i.test(organizationId)) return json(res, 503, { error: 'owner_management_requires_database' });
    try {
      if (req.method === 'GET') {
        const { rows } = await repositories.pool.query(`SELECT u.id,u.full_name AS name,u.login,u.is_active AS active,m.status,m.is_primary AS "isPrimary",m.created_at AS "createdAt" FROM users u JOIN organization_memberships m ON m.user_id=u.id AND m.organization_id=u.organization_id WHERE u.organization_id=$1 AND m.membership_role='owner' AND u.deleted_at IS NULL ORDER BY m.is_primary DESC,u.full_name`, [organizationId]);
        return json(res, 200, { items: rows });
      }
      if (req.method === 'POST' && action === 'reset' && targetId) {
        const token = crypto.randomBytes(32).toString('hex'); const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
        const result = await repositories.pool.query(`UPDATE users u SET password_reset_token_hash=$1,password_reset_expires_at=now()+interval '30 minutes' FROM organization_memberships m WHERE u.id=$2 AND u.organization_id=$3 AND m.user_id=u.id AND m.organization_id=$3 AND m.membership_role='owner' RETURNING u.id,u.login`, [tokenHash,targetId,organizationId]);
        if (!result.rows[0]) return json(res, 404, { error: 'owner_not_found' });
        recordAudit(req, 'platform.owner_reset_issued', 'organization_owner', targetId, null, { organizationId, login: result.rows[0].login, expiresInMinutes: 30 });
        return json(res, 200, { userId: targetId, login: result.rows[0].login, resetToken: token, expiresInMinutes: 30 });
      }
      if (req.method === 'POST' && action === 'transfer' && targetId) {
        const client = await repositories.pool.connect(); try { await client.query('BEGIN');
          const current = await client.query(`SELECT u.id,u.full_name AS name,u.login,m.is_primary AS "isPrimary" FROM users u JOIN organization_memberships m ON m.user_id=u.id AND m.organization_id=$1 WHERE u.organization_id=$1 AND m.membership_role='owner' AND m.is_primary=true FOR UPDATE`, [organizationId]);
          const target = await client.query(`SELECT u.id,u.full_name AS name,u.login FROM users u JOIN organization_memberships m ON m.user_id=u.id AND m.organization_id=$1 WHERE u.id=$2 AND u.organization_id=$1 AND m.membership_role='owner' AND u.is_active=true FOR UPDATE`, [organizationId,targetId]);
          if (!target.rows[0]) { await client.query('ROLLBACK'); return json(res,404,{error:'owner_not_found'}); }
          await client.query('UPDATE organization_memberships SET is_primary=false WHERE organization_id=$1 AND membership_role=\'owner\'', [organizationId]);
          await client.query('UPDATE organization_memberships SET is_primary=true,status=\'active\' WHERE organization_id=$1 AND user_id=$2', [organizationId,targetId]); await client.query('COMMIT');
          recordAudit(req,'platform.owner_transferred','organization_owner',targetId,current.rows[0]||null,target.rows[0]); return json(res,200,{owner:target.rows[0]});
        } catch (error) { await client.query('ROLLBACK').catch(()=>{}); return json(res,503,{error:'owner_transfer_failed',detail:error.message}); } finally { client.release(); }
      }
      if (req.method === 'POST' && !action) {
        const input = await body(req); const name=String(input.name||'').trim(); const login=String(input.login||'').trim().toLowerCase(); const password=String(input.password||'');
        if (!name || !/^[^\s@]+@[^\s@]+$/.test(login) || password.length < 8) return json(res,400,{error:'valid_owner_credentials_required'});
        const org = await repositories.pool.query('SELECT id FROM organizations WHERE id=$1',[organizationId]); if (!org.rows[0]) return json(res,404,{error:'organization_not_found'});
        const venue = await repositories.pool.query('SELECT id FROM venues WHERE organization_id=$1 ORDER BY created_at LIMIT 1',[organizationId]); if (!venue.rows[0]) return json(res,409,{error:'organization_venue_required'});
        const hash=await hashPassword(password); const client=await repositories.pool.connect(); try { await client.query('BEGIN'); const u=await client.query(`INSERT INTO users (venue_id,organization_id,full_name,login,password_hash,pin_hash,role) VALUES ($1,$2,$3,$4,$5,NULL,'owner') RETURNING id,full_name AS name,login,is_active AS active`,[venue.rows[0].id,organizationId,name,login,hash]); await client.query(`INSERT INTO organization_memberships (organization_id,user_id,membership_role,status,is_primary) VALUES ($1,$2,'owner','active',false)`,[organizationId,u.rows[0].id]); await client.query('COMMIT'); recordAudit(req,'platform.owner_added','organization_owner',u.rows[0].id,null,{organizationId,...u.rows[0]}); return json(res,201,{...u.rows[0],isPrimary:false}); } catch(error) { await client.query('ROLLBACK').catch(()=>{}); return json(res,409,{error:error.code==='23505'?'owner_login_already_exists':'owner_create_failed'}); } finally { client.release(); }
      }
      if (!targetId) return json(res,400,{error:'owner_id_required'});
      const current = await repositories.pool.query(`SELECT u.id,u.full_name AS name,u.login,u.is_active AS active,m.is_primary AS "isPrimary" FROM users u JOIN organization_memberships m ON m.user_id=u.id AND m.organization_id=$1 WHERE u.id=$2 AND u.organization_id=$1 AND m.membership_role='owner'`,[organizationId,targetId]); if (!current.rows[0]) return json(res,404,{error:'owner_not_found'});
      if (req.method === 'DELETE') { if (current.rows[0].isPrimary) return json(res,409,{error:'transfer_primary_owner_first'}); await repositories.pool.query('UPDATE users SET deleted_at=now(),is_active=false WHERE id=$1',[targetId]); await repositories.pool.query('UPDATE organization_memberships SET status=\'suspended\' WHERE organization_id=$1 AND user_id=$2',[organizationId,targetId]); recordAudit(req,'platform.owner_removed','organization_owner',targetId,current.rows[0],null); return json(res,200,{ok:true}); }
      const input=await body(req); if (input.active === false && current.rows[0].isPrimary) return json(res,409,{error:'primary_owner_must_be_transferred_first'}); if (input.isPrimary === true && current.rows[0].active === false) return json(res,409,{error:'inactive_owner_cannot_be_primary'}); if (input.login !== undefined && !/^[^\s@]+@[^\s@]+$/.test(String(input.login).trim())) return json(res,400,{error:'valid_owner_email_required'}); if (req.method === 'PATCH' && input.isPrimary === true) { const client=await repositories.pool.connect(); try { await client.query('BEGIN'); await client.query('UPDATE organization_memberships SET is_primary=false WHERE organization_id=$1 AND membership_role=\'owner\'', [organizationId]); await client.query('UPDATE organization_memberships SET is_primary=true,status=\'active\' WHERE organization_id=$1 AND user_id=$2 AND membership_role=\'owner\'', [organizationId,targetId]); await client.query('COMMIT'); recordAudit(req,'platform.owner_transferred','organization_owner',targetId,current.rows[0],{...current.rows[0],isPrimary:true}); return json(res,200,{...current.rows[0],isPrimary:true}); } catch(error) { await client.query('ROLLBACK').catch(()=>{}); return json(res,503,{error:'owner_transfer_failed'}); } finally { client.release(); } } const fields=[]; const values=[]; if(input.name!==undefined){values.push(String(input.name).trim());fields.push(`full_name=$${values.length}`);} if(input.login!==undefined){values.push(String(input.login).trim().toLowerCase());fields.push(`login=$${values.length}`);} if(input.password){ if(String(input.password).length<8)return json(res,400,{error:'password_too_short'}); values.push(await hashPassword(input.password));fields.push(`password_hash=$${values.length}`);} if(input.active!==undefined){values.push(Boolean(input.active));fields.push(`is_active=$${values.length}`);} if(!fields.length)return json(res,200,current.rows[0]); values.push(targetId); let updated; try { updated=await repositories.pool.query(`UPDATE users SET ${fields.join(',')} WHERE id=${values.length} RETURNING id,full_name AS name,login,is_active AS active`,values); } catch(error) { if(input.login!==undefined && error.code==='23505') return json(res,409,{error:'owner_login_already_exists'}); throw error; } if(input.password || input.active === false) { await repositories.pool.query('DELETE FROM auth_sessions WHERE user_id=$1',[targetId]); for (const [sessionToken, session] of sessions) if (session.user?.id === targetId) sessions.delete(sessionToken); } recordAudit(req,'platform.owner_updated','organization_owner',targetId,current.rows[0],updated.rows[0]); return json(res,200,updated.rows[0]);
    } catch (error) { return json(res,503,{error:'owner_management_failed'}); }
  }
  if (platformOrgPath && req.method === 'PATCH') {
    if (denyUnless(req, res, 'platform')) return;
    if (repositories?.pool) return json(res, 410, { error: 'use_subscription_endpoint' });
    const input = await body(req);
    const name = input.name === undefined ? undefined : String(input.name).trim().slice(0, 120);
    const plan = input.plan === undefined ? undefined : String(input.plan);
    if (name !== undefined && !name) return json(res, 400, { error: 'organization_name_required' });
    if (plan !== undefined && !saasPlans[plan]) return json(res, 400, { error: 'invalid_plan' });
    const organizationId = platformOrgPath[1];
    if (repositories?.pool) return json(res, 410, { error: 'use_subscription_endpoint' });
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(organizationId)) {
      try {
        const beforeResult = await repositories.pool.query('SELECT id,name,plan,is_active AS "isActive" FROM organizations WHERE id=$1 LIMIT 1', [organizationId]);
        if (!beforeResult.rows[0]) return json(res, 404, { error: 'organization_not_found' });
        const before = beforeResult.rows[0];
        const fields = [];
        const values = [];
        if (name !== undefined) { values.push(name); fields.push(`name=$${values.length}`); }
        if (plan !== undefined) { values.push(plan); fields.push(`plan=$${values.length}`); }
        if (input.isActive !== undefined) { values.push(Boolean(input.isActive)); fields.push(`is_active=$${values.length}`); }
        if (!fields.length) return json(res, 200, before);
        values.push(organizationId);
        const client = await repositories.pool.connect();
        let updated;
        try {
          await client.query('BEGIN');
          const { rows } = await client.query(`UPDATE organizations SET ${fields.join(',')},updated_at=now() WHERE id=$${values.length} RETURNING id,name,plan,is_active AS "isActive"`, values);
          updated = rows[0];
          if (plan !== undefined) await client.query('UPDATE organization_subscriptions SET plan=$1,seats_limit=$2,venues_limit=$3,updated_at=now() WHERE organization_id=$4', [plan, saasPlans[plan].seatsLimit, saasPlans[plan].venuesLimit, organizationId]);
          await client.query('COMMIT');
        } catch (error) {
          await client.query('ROLLBACK').catch(() => {});
          throw error;
        } finally { client.release(); }
        recordAudit(req, 'platform.organization_updated', 'organization', organizationId, before, updated);
        return json(res, 200, updated);
      } catch (error) { return json(res, 503, { error: 'organization_save_failed', detail: error.message }); }
    }
    const item = saasOrganizations.find((entry) => entry.id === organizationId);
    if (!item) return json(res, 404, { error: 'organization_not_found' });
    const before = { ...item };
    if (name !== undefined) item.name = name;
    if (plan !== undefined) { item.plan = plan; item.seatsLimit = saasPlans[plan].seatsLimit; item.venuesLimit = saasPlans[plan].venuesLimit; }
    if (input.isActive !== undefined) item.isActive = Boolean(input.isActive);
    recordAudit(req, 'platform.organization_updated', 'organization', item.id, before, item);
    return json(res, 200, item);
  }
  if (pathname === '/api/shifts' && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['floor', 'orders', 'finance_read'])) return;
    if (isOperationalEmployee(req)) {
      if (repositories?.pool) {
        try {
          const { rows } = await repositories.pool.query('SELECT s.id,s.opened_at AS "openedAt",s.opening_cash AS "openingCash",COALESCE(u.full_name,u.login,\'Не указан\') AS "openedByName" FROM shifts s LEFT JOIN users u ON u.id=s.opened_by AND (u.venue_id=s.venue_id OR u.organization_id=(SELECT organization_id FROM venues WHERE id=s.venue_id)) WHERE s.venue_id=$1 AND s.closed_at IS NULL ORDER BY s.opened_at DESC LIMIT 1', [venueDbId]);
          const row = rows[0];
          const current = row ? { id: row.id, openedAt: row.openedAt, closedAt: null, openingCash: Number(row.openingCash || 0) } : null;
          return json(res, 200, { items: current ? [current] : [], current });
        } catch (error) { return json(res, 503, { error: 'database_unavailable', detail: error.message }); }
      }
      const shift = shifts.find((entry) => entry.venueId === venueDbId && !entry.closedAt);
      const current = shift ? { id: shift.id, openedAt: shift.openedAt, closedAt: null, openingCash: Number(shift.openingCash || 0) } : null;
      return json(res, 200, { items: current ? [current] : [], current });
    }
    const canSeeShiftOpener = hasPermission(req, 'finance_read');
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query(`SELECT s.id,s.opened_at AS "openedAt",s.closed_at AS "closedAt",s.opening_cash AS "openingCash",s.closing_cash AS "closingCash",s.expected_cash AS "expectedCash",s.cash_variance AS "cashVariance",COALESCE(u.full_name,u.login,'Не указан') AS "openedByName",s.opened_at + (COALESCE((SELECT SUM(p.amount) FROM payments p JOIN orders o ON o.id=p.order_id WHERE o.venue_id=s.venue_id AND p.shift_id=s.id AND p.method='cash' AND p.status IN ('paid','partially_paid')),0) * INTERVAL '0 second') AS "reconciliationAt" FROM shifts s LEFT JOIN users u ON u.id=s.opened_by AND (u.venue_id=s.venue_id OR u.organization_id=(SELECT organization_id FROM venues WHERE id=s.venue_id)) WHERE s.venue_id=$1 ORDER BY s.opened_at DESC LIMIT 20`, [venueDbId]); const visible = canSeeShiftOpener ? rows : rows.filter((entry) => !entry.closedAt).slice(0, 1).map((entry) => ({ id: entry.id, openedAt: entry.openedAt, closedAt: null, openingCash: entry.openingCash })); return json(res, 200, { items: visible, current: visible.find((entry) => !entry.closedAt) || null }); } catch (_) {} }
    const venueShifts = shifts.filter((entry) => entry.venueId === venueDbId); const visible = hasPermission(req, 'finance_read') ? venueShifts.slice().reverse() : venueShifts.filter((entry) => !entry.closedAt).slice(0, 1).map((entry) => ({ id: entry.id, openedAt: entry.openedAt, closedAt: null, openingCash: entry.openingCash }));
    return json(res, 200, { items: visible, current: visible.find((entry) => !entry.closedAt) || null });
  }
  if (pathname === '/api/shifts' && req.method === 'POST') {
    if (denyUnlessAny(req, res, ['floor', 'orders'])) return;
    const input = await body(req);
    if (!Object.prototype.hasOwnProperty.call(input, 'openingCash') || !validCashAmount(input.openingCash)) return json(res, 400, { error: 'opening_cash_required' });
    if (repositories?.pool) { let client; try { client = await repositories.pool.connect(); await client.query('BEGIN'); await client.query("SELECT pg_advisory_xact_lock(hashtext('territory_crm_open_shift'),hashtext($1::text))", [venueDbId]); const open = await client.query('SELECT id FROM shifts WHERE venue_id=$1 AND closed_at IS NULL LIMIT 1 FOR UPDATE', [venueDbId]); if (open.rows[0]) { await client.query('ROLLBACK'); return json(res, 409, { error: 'shift_already_open' }); } const openedBy = /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : '20000000-0000-0000-0000-000000000001'; const { rows } = await client.query('INSERT INTO shifts (venue_id,opened_by,opening_cash) VALUES ($1,$2,$3) RETURNING id,opened_at AS "openedAt",closed_at AS "closedAt",opening_cash AS "openingCash",closing_cash AS "closingCash"', [venueDbId, openedBy, Number(input.openingCash || 0)]); await client.query('INSERT INTO audit_events (venue_id,actor_id,action,entity_type,entity_id,after_data) VALUES ($1,$2,$3,$4,$5,$6)', [venueDbId, /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null, 'shift.opened', 'shift', rows[0].id, rows[0]]); await client.query('COMMIT'); return json(res, 201, rows[0]); } catch (error) { if (client) await client.query('ROLLBACK').catch(() => {}); if (error.code === '23505') return json(res, 409, { error: 'shift_already_open' }); return json(res, 409, { error: 'shift_open_failed', detail: error.message }); } finally { client?.release(); } }
    if (shifts.some((entry) => entry.venueId === venueDbId && !entry.closedAt) || memoryShiftOpenPending.has(venueDbId)) return json(res, 409, { error: 'shift_already_open' });
    memoryShiftOpenPending.add(venueDbId);
    const shift = { venueId: venueDbId, id: `shift-${Date.now()}`, openedAt: new Date().toISOString(), closedAt: null, openingCash: Number(input.openingCash), closingCash: null, openedBy: req.user?.name || 'сотрудник' }; shifts.push(shift); memoryShiftOpenPending.delete(venueDbId); recordAudit(req, 'shift.opened', 'shift', shift.id, null, shift); return json(res, 201, shift);
  }
  const shiftClose = pathname.match(/^\/api\/shifts\/([^/]+)\/close$/);
  if (shiftClose && req.method === 'POST') {
    if (denyUnlessAny(req, res, ['floor', 'orders'])) return;
    const input = await body(req);
    if (input.checklistConfirmed !== true) return json(res, 400, { error: 'shift_checklist_required', message: 'Подтвердите чек-лист закрытия смены' });
    if (!Object.prototype.hasOwnProperty.call(input, 'closingCash') || !validCashAmount(input.closingCash)) return json(res, 400, { error: 'closing_cash_required' });
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(shiftClose[1])) { let client; try { client = await repositories.pool.connect(); await client.query('BEGIN'); const { rows: shiftRows } = await client.query('SELECT id,venue_id,opening_cash AS "openingCash",opened_at AS "openedAt" FROM shifts WHERE id=$1 AND venue_id=$2 AND closed_at IS NULL FOR UPDATE', [shiftClose[1], venueDbId]); if (!shiftRows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'shift_not_found_or_closed' }); } const unresolvedLegacyCash = await client.query("SELECT COUNT(*)::int AS count, COALESCE(SUM(p.amount),0) AS amount FROM payments p JOIN orders o ON o.id=p.order_id WHERE o.venue_id=$1 AND p.shift_id IS NULL AND p.method='cash' AND p.status IN ('paid','partially_paid') AND p.created_at >= $2 AND p.created_at < now()", [venueDbId, shiftRows[0].openedAt]); if (Number(unresolvedLegacyCash.rows[0]?.count || 0) > 0) { await client.query('ROLLBACK'); return json(res, 409, { error: 'shift_cash_attribution_unresolved', count: Number(unresolvedLegacyCash.rows[0].count), amount: Number(unresolvedLegacyCash.rows[0].amount || 0) }); } const payments = await client.query("SELECT COALESCE(SUM(p.amount),0) AS amount FROM payments p JOIN orders o ON o.id=p.order_id WHERE o.venue_id=$1 AND p.shift_id=$2 AND p.method='cash' AND p.status IN ('paid','partially_paid')", [venueDbId, shiftClose[1]]); const expectedCash = Number(shiftRows[0].openingCash || 0) + Number(payments.rows[0]?.amount || 0); const { rows } = await client.query('UPDATE shifts SET closed_at=now(),closing_cash=$1::numeric,expected_cash=$2::numeric,cash_variance=$1::numeric-$2::numeric WHERE id=$3 AND venue_id=$4 AND closed_at IS NULL RETURNING id,opened_at AS "openedAt",closed_at AS "closedAt",opening_cash AS "openingCash",closing_cash AS "closingCash",expected_cash AS "expectedCash",cash_variance AS "cashVariance"', [Number(input.closingCash), expectedCash, shiftClose[1], venueDbId]); if (!rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'shift_not_found_or_closed' }); } await client.query('INSERT INTO audit_events (venue_id,actor_id,action,entity_type,entity_id,after_data) VALUES ($1,$2,$3,$4,$5,$6)', [venueDbId, /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null, 'shift.closed', 'shift', rows[0].id, rows[0]]); await client.query('COMMIT'); return json(res, 200, rows[0]); } catch (error) { if (client) await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'shift_close_failed', detail: error.message }); } finally { client?.release(); } }
    const shift = shifts.find((entry) => entry.id === shiftClose[1]); if (!shift || shift.closedAt) return json(res, 404, { error: 'shift_not_found_or_closed' });
    const cashPayments = orders.flatMap((order) => order.payments || []).filter((payment) => payment.method === 'cash' && ['paid', 'partially_paid'].includes(payment.status) && new Date(payment.createdAt || 0) >= new Date(shift.openedAt));
    const unassignedCashPayments = cashPayments.filter((payment) => !payment.shiftId);
    if (unassignedCashPayments.length) return json(res, 409, { error: 'shift_cash_attribution_unresolved', count: unassignedCashPayments.length, amount: unassignedCashPayments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0) });
    const expectedCash = Number(shift.openingCash || 0) + cashPayments.filter((payment) => payment.shiftId === shift.id).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
    shift.closedAt = new Date().toISOString(); shift.expectedCash = expectedCash; shift.closingCash = Number(input.closingCash); shift.cashVariance = shift.closingCash - expectedCash; recordAudit(req, 'shift.closed', 'shift', shift.id, null, shift); return json(res, 200, shift);
  }
  if (pathname === '/api/venue' && req.method === 'GET') {
    if (process.env.DATABASE_URL && !repositories?.pool) return json(res, 503, { error: 'venue_unavailable' });
    if (repositories?.pool) { try {
      const organizationId = requestOrganizationId(req) || null;
      if (process.env.AUTH_REQUIRED === 'true' && !organizationId) return json(res, 403, { error: 'organization_context_required' });
      const { rows } = await repositories.pool.query('SELECT id,name,city,format,phone,phone_numbers AS "phoneNumbers",address,logo_url AS "logoUrl",timezone FROM venues WHERE id=$1 AND ($2::uuid IS NULL OR organization_id=$2::uuid) AND is_active=true', [venueDbId, organizationId]);
      if (!rows[0]) return json(res, 404, { error: 'venue_not_found' });
      const { rows: vipRows } = await repositories.pool.query('SELECT t.name,t.min_order_total FROM tables t JOIN zones z ON z.id=t.zone_id WHERE z.venue_id=$1 AND t.name IN ($2,$3)', [venueDbId, 'VIP-\u043a\u043e\u043c\u043d\u0430\u0442\u0430 1', 'VIP-\u043a\u043e\u043c\u043d\u0430\u0442\u0430 2']);
      const vipRoomMinimums = { vip_room_1: 1500, vip_room_2: 2500 };
      vipRows.forEach((row) => { if (row.name.endsWith('1')) vipRoomMinimums.vip_room_1 = Number(row.min_order_total); if (row.name.endsWith('2')) vipRoomMinimums.vip_room_2 = Number(row.min_order_total); });
      return json(res, 200, { ...rows[0], vipRoomMinimums });
    } catch (_) { return json(res, 503, { error: 'venue_unavailable' }); } }
    return json(res, 200, { ...venue, id: currentVenueId });
  }
  if (pathname === '/api/venue' && (req.method === 'PATCH' || req.method === 'PUT')) {
    if (denyUnless(req, res, 'settings')) return;
    if (!canManageVenueIdentity(req)) return json(res, 403, { error: 'venue_admin_required' });
    const input = await body(req);
    if (input.name !== undefined && (!String(input.name).trim() || String(input.name).length > 120)) return json(res, 400, { error: 'venue_name_required' });
    if (input.city !== undefined && (!String(input.city).trim() || String(input.city).length > 80)) return json(res, 400, { error: 'venue_city_required' });
    if (input.address !== undefined && (!String(input.address).trim() || String(input.address).length > 240)) return json(res, 400, { error: 'venue_address_required' });
    if (input.format !== undefined && String(input.format).length > 80) return json(res, 400, { error: 'venue_format_too_long' });
    if (input.timezone !== undefined && String(input.timezone).length > 64) return json(res, 400, { error: 'venue_timezone_too_long' });
    if (input.timezone !== undefined && !isValidIanaTimezone(input.timezone)) return json(res, 400, { error: 'invalid_venue_timezone' });
    if (input.phoneNumbers !== undefined && (!Array.isArray(input.phoneNumbers) || input.phoneNumbers.length > 5 || input.phoneNumbers.some((entry) => !entry || !/^\+7[0-9 ()-]{7,24}$/.test(String(entry.number || '').trim())))) return json(res, 400, { error: 'invalid_phone_numbers' }); if (input.phoneNumbers !== undefined && input.phoneNumbers.length && input.phoneNumbers.filter((entry) => entry.primary).length !== 1) return json(res, 400, { error: 'one_primary_phone_required' }); if (input.phone !== undefined && input.phone && !/^\+7[0-9 ()-]{7,24}$/.test(String(input.phone))) return json(res, 400, { error: 'invalid_phone' });
    if (input.logoUrl !== undefined && input.logoUrl !== null && !validImageData(input.logoUrl)) return json(res, 400, { error: 'invalid_logo' });
    if (input.vipRoomMinimums !== undefined && ['vip_room_1', 'vip_room_2'].some((key) => input.vipRoomMinimums?.[key] !== undefined && (!Number.isFinite(Number(input.vipRoomMinimums[key])) || Number(input.vipRoomMinimums[key]) < 0))) return json(res, 400, { error: 'invalid_vip_minimum' });
    if (process.env.DATABASE_URL && !repositories?.pool) return json(res, 503, { error: 'venue_unavailable' });
    const selectedVenueId = repositories?.pool ? venueDbId : currentVenueId;
    if (!input.expectedVenueId) return json(res, 428, { error: 'venue_precondition_required' });
    if (String(input.expectedVenueId) !== String(selectedVenueId)) return json(res, 409, { error: 'venue_context_changed' });
    if (repositories?.pool) {
      const organizationId = requestOrganizationId(req) || null;
      if (process.env.AUTH_REQUIRED === 'true' && !organizationId) return json(res, 403, { error: 'organization_context_required' });
      let client;
      try {
        client = await repositories.pool.connect();
        await client.query('BEGIN');
        const { rows } = await client.query('SELECT id,name,city,format,phone,phone_numbers AS "phoneNumbers",address,logo_url AS "logoUrl",timezone FROM venues WHERE id=$1 AND ($2::uuid IS NULL OR organization_id=$2::uuid) AND is_active=true FOR UPDATE', [venueDbId, organizationId]);
        if (!rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'venue_not_found' }); }
        const token = requestAuthToken(req);
        if (token) {
          const activeSession = await client.query('SELECT COALESCE(s.active_venue_id,u.venue_id) AS venue_id FROM auth_sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>now() AND u.is_active=true AND ($2::uuid IS NULL OR u.organization_id=$2::uuid) FOR UPDATE OF s', [hashToken(token), organizationId]);
          if (!activeSession.rows[0]) { await client.query('ROLLBACK'); return json(res, 401, { error: 'session_required' }); }
          if (String(activeSession.rows[0].venue_id) !== String(input.expectedVenueId)) { await client.query('ROLLBACK'); return json(res, 409, { error: 'venue_context_changed' }); }
        } else if (process.env.AUTH_REQUIRED === 'true') { await client.query('ROLLBACK'); return json(res, 401, { error: 'session_required' }); }
        const before = rows[0];
        const incomingPhones = input.phoneNumbers === undefined ? before.phoneNumbers : input.phoneNumbers.map((entry) => ({ label: String(entry.label || 'Дополнительный').trim().slice(0, 32), number: String(entry.number || '').trim(), primary: Boolean(entry.primary) }));
        const next = {
          name: input.name === undefined ? before.name : String(input.name).trim(),
          city: input.city === undefined ? before.city : String(input.city).trim(),
          address: input.address === undefined ? before.address : String(input.address).trim(),
          format: input.format === undefined ? before.format : String(input.format).trim(),
          timezone: input.timezone === undefined ? before.timezone : String(input.timezone).trim(),
          phoneNumbers: incomingPhones,
          phone: input.phoneNumbers !== undefined ? incomingPhones.find((entry) => entry.primary)?.number || '' : input.phone === undefined ? before.phone : String(input.phone).trim(),
          logoUrl: input.logoUrl === undefined ? before.logoUrl : input.logoUrl,
        };
        const updated = await client.query('UPDATE venues SET name=$1,city=$2,format=$3,phone=$4,phone_numbers=$5::jsonb,address=$6,timezone=$7,logo_url=$8 WHERE id=$9 AND ($10::uuid IS NULL OR organization_id=$10::uuid) AND is_active=true RETURNING id,name,city,format,phone,phone_numbers AS "phoneNumbers",address,logo_url AS "logoUrl",timezone', [next.name, next.city, next.format, next.phone, JSON.stringify(next.phoneNumbers || []), next.address, next.timezone, next.logoUrl, venueDbId, organizationId]);
        if (!updated.rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'venue_not_found' }); }
        if (input.vipRoomMinimums !== undefined) for (const [key, room] of [['vip_room_1', 'VIP-\u043a\u043e\u043c\u043d\u0430\u0442\u0430 1'], ['vip_room_2', 'VIP-\u043a\u043e\u043c\u043d\u0430\u0442\u0430 2']]) if (input.vipRoomMinimums[key] !== undefined) await client.query('UPDATE tables t SET min_deposit=$1,min_order_total=$1 FROM zones z WHERE t.zone_id=z.id AND z.venue_id=$2 AND t.name=$3', [Math.round(Number(input.vipRoomMinimums[key])), venueDbId, room]);
        const { rows: vipRows } = await client.query('SELECT t.name,t.min_order_total FROM tables t JOIN zones z ON z.id=t.zone_id WHERE z.venue_id=$1 AND t.name IN ($2,$3)', [venueDbId, 'VIP-\u043a\u043e\u043c\u043d\u0430\u0442\u0430 1', 'VIP-\u043a\u043e\u043c\u043d\u0430\u0442\u0430 2']);
        const vipRoomMinimums = { vip_room_1: 1500, vip_room_2: 2500 };
        vipRows.forEach((row) => { if (row.name.endsWith('1')) vipRoomMinimums.vip_room_1 = Number(row.min_order_total); if (row.name.endsWith('2')) vipRoomMinimums.vip_room_2 = Number(row.min_order_total); });
        await client.query('COMMIT');
        const saved = { ...updated.rows[0], vipRoomMinimums };
        recordAudit(req, 'venue.updated', 'venue', saved.id, before, saved);
        return json(res, 200, saved);
      } catch (_) { if (client) await client.query('ROLLBACK').catch(() => {}); return json(res, 503, { error: 'venue_save_failed' }); }
      finally { client?.release(); }
    }
    const before = { ...venue };
    if (input.vipRoomMinimums !== undefined) {
      const values = input.vipRoomMinimums || {};
      for (const key of ['vip_room_1', 'vip_room_2']) if (values[key] !== undefined && (!Number.isFinite(Number(values[key])) || Number(values[key]) < 0)) return json(res, 400, { error: 'invalid_vip_minimum' });
      venue.vipRoomMinimums = { ...venue.vipRoomMinimums, ...Object.fromEntries(['vip_room_1', 'vip_room_2'].filter((key) => values[key] !== undefined).map((key) => [key, Math.round(Number(values[key]))])) };
      floor.flatMap((zone) => zone.tables).forEach((table) => { if (table.id === 'vip-room-1') table.minimumOrderTotal = venue.vipRoomMinimums.vip_room_1; if (table.id === 'vip-room-2') table.minimumOrderTotal = venue.vipRoomMinimums.vip_room_2; });
    }
    const incomingPhones = input.phoneNumbers !== undefined ? input.phoneNumbers.map((entry) => ({ label: String(entry.label || 'Дополнительный').trim().slice(0, 32), number: String(entry.number || '').trim(), primary: Boolean(entry.primary) })) : undefined; if (incomingPhones !== undefined) { venue.phoneNumbers = incomingPhones; venue.phone = incomingPhones.find((entry) => entry.primary)?.number || ''; } Object.assign(venue, Object.fromEntries(['name', 'city', 'format', 'phone', 'address', 'timezone', 'logoUrl'].filter((key) => input[key] !== undefined).map((key) => [key, key === 'logoUrl' ? input[key] : String(input[key]).trim()])));
    const selected = networkVenues.find((item) => item.id === currentVenueId);
    if (selected) Object.assign(selected, { name: venue.name, city: venue.city, address: venue.address, format: venue.format, phone: venue.phone, timezone: venue.timezone, logoUrl: venue.logoUrl, phoneNumbers: venue.phoneNumbers, vipRoomMinimums: { ...venue.vipRoomMinimums } });
    const saved = { ...venue, id: currentVenueId };
    recordAudit(req, 'venue.updated', 'venue', currentVenueId, before, saved); return json(res, 200, saved);
  }
  if (pathname.startsWith('/api/integrations/') && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['diagnostics', 'settings', 'integrations'])) return;
    const key = pathname.split('/').pop(); const item = integrations[key];
    if (!item) return json(res, 404, { error: 'integration_not_found' });
    const requirements = { telegram: ['токен бота', 'чат уведомлений'] };
    return json(res, 200, { key, enabled: Boolean(item.enabled), status: item.status || 'planned', mode: item.mode || 'test', requirements: requirements[key] || ['Реквизиты сервиса'] });
  }
  if (pathname === '/api/integrations') { if (denyUnlessAny(req, res, ['diagnostics', 'settings', 'integrations'])) return; return json(res, 200, integrations); }
  if (pathname === '/api/network/venues' && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['settings', 'diagnostics'])) return;
    if (!canManageVenueIdentity(req)) return json(res, 403, { error: 'venue_admin_required' });
    const organizationId = requestOrganizationId(req);
    if (process.env.DATABASE_URL || repositories?.pool) {
      if (!repositories?.pool) return json(res, 503, { error: 'network_unavailable' });
      if (requireOrganizationContext(req, res)) return;
      try { const { rows } = await repositories.pool.query('SELECT id,name,format,city,address,phone,timezone,is_current AS "isCurrent" FROM venues WHERE is_active=true AND organization_id=$1 ORDER BY name', [organizationId]); return json(res, 200, { items: rows.map((row) => ({ ...row, status: 'active', isCurrent: row.id === venueDbId })) }); } catch (_) { return json(res, 503, { error: 'network_unavailable' }); }
    }
    return json(res, 200, { items: networkVenues.filter((item) => item.status !== 'archived').map((item) => ({ ...item, isCurrent: item.id === currentVenueId })) });
  }
  if (pathname === '/api/network/venues' && req.method === 'POST') {
    if (denyUnless(req, res, 'settings')) return;
    if (!canManageVenueIdentity(req)) return json(res, 403, { error: 'venue_admin_required' });
    const input = await body(req); const name = String(input.name || '').trim(); const city = String(input.city || '').trim(); const address = String(input.address || '').trim();
    if (!name || name.length > 120 || !city || city.length > 80 || !address || address.length > 240) return json(res, 400, { error: 'venue_name_city_address_required' });
    const timezone = input.timezone === undefined ? resolveIanaTimezone(venue.timezone) : String(input.timezone).trim();
    if (!isValidIanaTimezone(timezone)) return json(res, 400, { error: 'invalid_venue_timezone' });
    const item = { id: `venue-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, name, format: String(input.format || 'кальян-бар').trim().slice(0, 80), city, address, phone: String(input.phone || '').trim().slice(0, 32), phoneNumbers: [], logoUrl: null, vipRoomMinimums: { vip_room_1: 1500, vip_room_2: 2500 }, timezone, status: 'active', isCurrent: false };
    const organizationId = requestOrganizationId(req);
    if (process.env.DATABASE_URL || repositories?.pool) {
      if (!repositories?.pool) return json(res, 503, { error: 'network_unavailable' });
      if (requireOrganizationContext(req, res)) return;
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        const quota = await checkOrganizationQuota(client, organizationId, 'venue');
        if (quota.error) { await client.query('ROLLBACK'); return json(res, quota.status, { error: quota.error, ...(quota.limit ? { limit: quota.limit, used: quota.used } : {}) }); }
        const { rows } = await client.query('INSERT INTO venues (organization_id,name,format,city,address,phone,timezone,is_current) VALUES ($1,$2,$3,$4,$5,$6,$7,false) RETURNING id,name,format,city,address,phone,timezone,is_current AS "isCurrent"', [organizationId, name, item.format, city, address, item.phone || null, item.timezone]);
        await client.query('COMMIT');
        const created = { ...rows[0], status: 'active', isCurrent: false }; recordAudit(req, 'venue.created', 'venue', created.id, null, created); return json(res, 201, created);
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); return json(res, 503, { error: 'venue_create_failed' }); }
      finally { client.release(); }
    }
    networkVenues.push(item); recordAudit(req, 'venue.created', 'venue', item.id, null, item); return json(res, 201, item);
  }
  const networkVenuePath = pathname.match(/^\/api\/network\/venues\/([^/]+)$/);
  if (networkVenuePath && req.method === 'PATCH') {
    if (denyUnless(req, res, 'settings')) return;
    if (!canManageVenueIdentity(req)) return json(res, 403, { error: 'venue_admin_required' });
    if (process.env.DATABASE_URL || repositories?.pool) {
      if (!repositories?.pool) return json(res, 503, { error: 'network_unavailable' });
      if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(networkVenuePath[1])) return json(res, 404, { error: 'venue_not_found' });
      if (requireOrganizationContext(req, res)) return;
      const organizationId = requestOrganizationId(req);
      const input = await body(req);
      if (['name', 'city', 'address'].some((key) => input[key] !== undefined && !String(input[key] || '').trim())) return json(res, 400, { error: 'venue_name_city_address_required' });
      if (input.timezone !== undefined && !isValidIanaTimezone(input.timezone)) return json(res, 400, { error: 'invalid_venue_timezone' });
      const fields = []; const values = [networkVenuePath[1]];
      for (const [column, key, max] of [['name', 'name', 120], ['format', 'format', 80], ['city', 'city', 80], ['address', 'address', 240], ['phone', 'phone', 32], ['timezone', 'timezone', 64]]) if (input[key] !== undefined) { fields.push(`${column}=$${values.length + 1}`); values.push(String(input[key] || '').trim().slice(0, max)); }
      if (!fields.length) return json(res, 400, { error: 'venue_name_city_address_required' });
      values.push(organizationId);
      try { const { rows } = await repositories.pool.query(`UPDATE venues SET ${fields.join(',')} WHERE id=$1 AND organization_id=$${values.length} AND is_active=true RETURNING id,name,format,city,address,phone,timezone`, values); if (!rows[0]) return json(res, 404, { error: 'venue_not_found' }); const updated = { ...rows[0], status: 'active', isCurrent: rows[0].id === venueDbId }; recordAudit(req, 'venue.updated', 'venue', updated.id, null, updated); return json(res, 200, updated); } catch (error) { return json(res, 409, { error: 'venue_update_failed', detail: error.message }); }
    }
    const item = networkVenues.find((entry) => entry.id === networkVenuePath[1]); if (!item || item.status === 'archived') return json(res, 404, { error: 'venue_not_found' });
    const input = await body(req); const before = { ...item };
    if (['name', 'city', 'address'].some((key) => input[key] !== undefined && !String(input[key] || '').trim())) return json(res, 400, { error: 'venue_name_city_address_required' });
    if (input.timezone !== undefined && !isValidIanaTimezone(input.timezone)) return json(res, 400, { error: 'invalid_venue_timezone' });
    for (const [key, max] of [['name', 120], ['city', 80], ['address', 240], ['format', 80], ['phone', 32], ['timezone', 64]]) if (input[key] !== undefined) item[key] = String(input[key] || '').trim().slice(0, max);
    if (!item.name || !item.city || !item.address) return json(res, 400, { error: 'venue_name_city_address_required' });
    if (item.id === currentVenueId) Object.assign(venue, { name: item.name, city: item.city, address: item.address, phone: item.phone, timezone: item.timezone, format: item.format });
    recordAudit(req, 'venue.updated', 'venue', item.id, before, item); return json(res, 200, { ...item, isCurrent: item.id === currentVenueId });
  }
  if (networkVenuePath && req.method === 'DELETE') {
    if (denyUnless(req, res, 'settings')) return;
    if (!canManageVenueIdentity(req)) return json(res, 403, { error: 'venue_admin_required' });
    if (process.env.DATABASE_URL || repositories?.pool) {
      if (!repositories?.pool) return json(res, 503, { error: 'network_unavailable' });
      if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(networkVenuePath[1])) return json(res, 404, { error: 'venue_not_found' });
      if (requireOrganizationContext(req, res)) return;
      if (networkVenuePath[1] === venueDbId) return json(res, 409, { error: 'current_venue_cannot_be_archived' });
      try { const { rows } = await repositories.pool.query('UPDATE venues SET is_active=false WHERE id=$1 AND organization_id=$2 AND is_active=true RETURNING id,name,format,city,address,phone,timezone', [networkVenuePath[1], requestOrganizationId(req)]); if (!rows[0]) return json(res, 404, { error: 'venue_not_found' }); const archived = { ...rows[0], status: 'archived', isCurrent: false }; recordAudit(req, 'venue.archived', 'venue', archived.id, { status: 'active' }, archived); return json(res, 200, archived); } catch (error) { return json(res, 409, { error: 'venue_archive_failed', detail: error.message }); }
    }
    const item = networkVenues.find((entry) => entry.id === networkVenuePath[1]); if (!item || item.status === 'archived') return json(res, 404, { error: 'venue_not_found' });
    if (item.id === currentVenueId) return json(res, 409, { error: 'current_venue_cannot_be_archived' });
    item.status = 'archived'; recordAudit(req, 'venue.archived', 'venue', item.id, { status: 'active' }, { status: 'archived' }); return json(res, 200, item);
  }
  const networkVenueSelect = pathname.match(/^\/api\/network\/venues\/([^/]+)\/select$/);
  if (networkVenueSelect && req.method === 'POST') {
    if (denyUnless(req, res, 'settings')) return;
    if (process.env.DATABASE_URL || repositories?.pool) {
      if (!repositories?.pool) return json(res, 503, { error: 'network_unavailable' });
      if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(networkVenueSelect[1])) return json(res, 404, { error: 'venue_not_found' });
      if (requireOrganizationContext(req, res)) return;
      const token = requestAuthToken(req);
      if (!token || !sessionRepository) return json(res, 401, { error: 'session_required' });
      try {
        const client = await repositories.pool.connect();
        try {
          await client.query('BEGIN');
          const { rows } = await client.query('SELECT id,name,format,city,address,phone,timezone FROM venues WHERE id=$1 AND organization_id=$2 AND is_active=true FOR UPDATE', [networkVenueSelect[1], requestOrganizationId(req)]);
          if (!rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'venue_not_found' }); }
          const selected = { ...rows[0], status: 'active', isCurrent: true };
          const saved = await sessionRepository.setActiveVenue(hashToken(token), selected.id, client);
          if (!saved) { await client.query('ROLLBACK'); return json(res, 401, { error: 'session_required' }); }
          await client.query('COMMIT');
          const previousVenueId = venueDbId;
          venueDbId = selected.id;
          if (req.user) req.user.venueId = selected.id;
          recordAudit(req, 'venue.selected', 'venue', selected.id, { currentVenueId: previousVenueId }, { currentVenueId: selected.id });
          return json(res, 200, selected);
        } catch (error) { await client.query('ROLLBACK').catch(() => {}); throw error; }
        finally { client.release(); }
      } catch (_) { return json(res, 503, { error: 'venue_select_failed' }); }
    }
    const item = networkVenues.find((entry) => entry.id === networkVenueSelect[1]); if (!item || item.status === 'archived') return json(res, 404, { error: 'venue_not_found' });
    const before = networkVenues.find((entry) => entry.id === currentVenueId); floorByVenueId.set(currentVenueId, floor); currentVenueId = item.id; floor = floorByVenueId.get(currentVenueId) || []; floorByVenueId.set(currentVenueId, floor); Object.assign(venue, { name: item.name, city: item.city, address: item.address, phone: item.phone, phoneNumbers: item.phoneNumbers || [], logoUrl: item.logoUrl || null, timezone: item.timezone, format: item.format, vipRoomMinimums: { ...(item.vipRoomMinimums || { vip_room_1: 1500, vip_room_2: 2500 }) } }); if (req.user) req.user.venueId = item.id;
    recordAudit(req, 'venue.selected', 'venue', item.id, { currentVenueId: before?.id || null }, { currentVenueId: item.id }); return json(res, 200, { ...item, isCurrent: true });
  }
  if (pathname === '/api/finance/categories' && req.method === 'GET') {
    if (denyUnless(req, res, 'finance')) return;
    const query = String(url.searchParams.get('q') || '').trim().toLocaleLowerCase('ru-RU');
    const includeArchived = url.searchParams.get('includeArchived') === 'true';
    if (includeArchived && denyUnless(req, res, 'finance')) return;
    if (repositories?.pool) {
      try {
        const { rows } = await repositories.pool.query(`SELECT c.id,c.name,c.kind,c.active,COUNT(e.id)::int AS "operationCount"
          FROM finance_categories c LEFT JOIN expenses e ON e.venue_id=c.venue_id AND e.category_id=c.id
          WHERE c.venue_id=$1 AND ($2::boolean OR c.active=true) AND ($3::text='' OR c.name ILIKE '%' || $3 || '%')
          GROUP BY c.id ORDER BY c.active DESC,c.kind,lower(c.name),c.id`, [venueDbId, includeArchived, query]);
        return json(res, 200, { items: rows });
      } catch (error) { return json(res, 503, { error: 'finance_categories_unavailable', detail: error.message }); }
    }
    return json(res, 200, { items: financeCategories.filter((item) => (includeArchived || item.active !== false) && (!query || item.name.toLocaleLowerCase('ru-RU').includes(query))).map((item) => ({ ...item, operationCount: manualExpenses.filter((expense) => expense.categoryId === item.id).length })) });
  }
  if (pathname === '/api/finance/categories' && req.method === 'POST') {
    if (denyUnless(req, res, 'finance')) return;
    const input = await body(req); const name = String(input.name || '').trim(); const kind = String(input.kind || 'income');
    if (!name || name.length > 80 || !['income', 'expense'].includes(kind)) return json(res, 400, { error: 'invalid_finance_category' });
    if (repositories?.pool) {
      try { const { rows } = await repositories.pool.query('INSERT INTO finance_categories (venue_id,name,kind) VALUES ($1,$2,$3) RETURNING id,name,kind,active,0::int AS "operationCount"', [venueDbId, name, kind]); recordAudit(req, 'finance_category.created', 'finance_category', rows[0].id, null, rows[0]); return json(res, 201, rows[0]); }
      catch (error) { return json(res, error.code === '23505' ? 409 : 503, { error: error.code === '23505' ? 'finance_category_exists' : 'finance_category_save_failed', detail: error.message }); }
    }
    if (financeCategories.some((item) => item.active && item.kind === kind && item.name.toLocaleLowerCase('ru-RU') === name.toLocaleLowerCase('ru-RU'))) return json(res, 409, { error: 'finance_category_exists' });
    const category = { id: `finance-category-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, name, kind, active: true };
    financeCategories.push(category); recordAudit(req, 'finance_category.created', 'finance_category', category.id, null, category); return json(res, 201, category);
  }
  const financeCategoryPath = pathname.match(/^\/api\/finance\/categories\/([^/]+)$/);
  if (financeCategoryPath && req.method === 'PATCH') {
    if (denyUnless(req, res, 'finance')) return;
    if (repositories?.pool) {
      if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(financeCategoryPath[1])) return json(res, 404, { error: 'finance_category_not_found' });
      const input = await body(req); const client = await repositories.pool.connect(); let before = null; let updated = null;
      try {
        await client.query('BEGIN');
        const current = await client.query('SELECT id,name,kind,active FROM finance_categories WHERE id=$1 AND venue_id=$2 FOR UPDATE', [financeCategoryPath[1], venueDbId]);
        if (!current.rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'finance_category_not_found' }); }
        before = current.rows[0];
        const name = input.name === undefined ? before.name : String(input.name || '').trim(); const kind = input.kind === undefined ? before.kind : String(input.kind); const active = input.active === undefined ? before.active : input.active;
        if (!name || name.length > 80 || !['income', 'expense'].includes(kind) || typeof active !== 'boolean') { await client.query('ROLLBACK'); return json(res, 400, { error: 'invalid_finance_category' }); }
        if (before.kind === 'expense' && kind !== 'expense') {
          const usage = await client.query('SELECT 1 FROM expenses WHERE venue_id=$1 AND category_id=$2 LIMIT 1', [venueDbId, before.id]);
          if (usage.rows[0]) { await client.query('ROLLBACK'); return json(res, 409, { error: 'finance_category_has_expenses' }); }
        }
        const result = await client.query('UPDATE finance_categories SET name=$1,kind=$2,active=$3,updated_at=now() WHERE id=$4 AND venue_id=$5 RETURNING id,name,kind,active', [name,kind,active,before.id,venueDbId]);
        updated = result.rows[0];
        if (name !== before.name) await client.query('UPDATE expenses SET category=$1 WHERE venue_id=$2 AND category_id=$3', [name,venueDbId,before.id]);
        await client.query('COMMIT');
        recordAudit(req, active !== before.active ? active ? 'finance_category.restored' : 'finance_category.archived' : 'finance_category.updated', 'finance_category', updated.id, before, updated);
        return json(res, 200, updated);
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); return json(res, error.code === '23505' ? 409 : 503, { error: error.code === '23505' ? 'finance_category_exists' : 'finance_category_update_failed', detail: error.message }); }
      finally { client.release(); }
    }
    const category = financeCategories.find((item) => item.id === financeCategoryPath[1]); if (!category) return json(res, 404, { error: 'finance_category_not_found' });
    const input = await body(req); const name = input.name === undefined ? category.name : String(input.name || '').trim(); const kind = input.kind === undefined ? category.kind : String(input.kind);
    const active = input.active === undefined ? category.active !== false : input.active;
    if (!name || name.length > 80 || !['income', 'expense'].includes(kind) || typeof active !== 'boolean') return json(res, 400, { error: 'invalid_finance_category' });
    const before = { ...category }; category.name = name; category.kind = kind; category.active = active; recordAudit(req, active !== before.active ? active ? 'finance_category.restored' : 'finance_category.archived' : 'finance_category.updated', 'finance_category', category.id, before, category); return json(res, 200, category);
  }
  if (financeCategoryPath && req.method === 'DELETE') {
    if (denyUnless(req, res, 'finance')) return;
    if (repositories?.pool) { const { rows } = await repositories.pool.query('UPDATE finance_categories SET active=false,updated_at=now() WHERE id=$1 AND venue_id=$2 RETURNING id,name,kind,active', [financeCategoryPath[1],venueDbId]); if (!rows[0]) return json(res, 404, { error: 'finance_category_not_found' }); recordAudit(req, 'finance_category.archived', 'finance_category', rows[0].id, { active: true }, rows[0]); return json(res, 200, rows[0]); }
    const category = financeCategories.find((item) => item.id === financeCategoryPath[1]); if (!category) return json(res, 404, { error: 'finance_category_not_found' });
    category.active = false; recordAudit(req, 'finance_category.archived', 'finance_category', category.id, { active: true }, { active: false }); return json(res, 200, category);
  }
  if (pathname === '/api/metrics') {
    if (isOperationalEmployee(req)) {
      if (!hasPermission(req, 'orders')) return json(res, 200, { employeeView: true });
      if (repositories?.pool) {
        try {
          const { rows } = await repositories.pool.query("SELECT COUNT(*)::int AS count FROM orders WHERE venue_id=$1 AND status IN ('open','in_progress','ready')", [venueDbId]);
          const openOrders = Number(rows[0]?.count || 0);
          return json(res, 200, { employeeView: true, openOrders, pendingOrders: openOrders });
        } catch (error) { return json(res, 503, { error: 'database_unavailable', detail: error.message }); }
      }
      const openOrders = orders.filter((order) => ['open', 'in_progress', 'ready'].includes(order.status)).length;
      return json(res, 200, { employeeView: true, openOrders, pendingOrders: openOrders });
    }
    if (repositories?.pool) {
      try {
        const [ordersMetric, discountsMetric, staffMetric, reservationsMetric, stockMetric] = await Promise.all([
          repositories.pool.query(`WITH item_totals AS (SELECT order_id, COALESCE(SUM(quantity * unit_price),0) AS subtotal FROM order_items GROUP BY order_id), discount_totals AS (SELECT order_id, COALESCE(SUM(CASE WHEN type='percent' THEN (SELECT COALESCE(SUM(oi.quantity * oi.unit_price),0) FROM order_items oi WHERE oi.order_id=d.order_id) * LEAST(100,GREATEST(0,value))/100 ELSE GREATEST(0,value) END),0) AS discount FROM discounts d WHERE status='approved' GROUP BY order_id), paid_totals AS (SELECT order_id, COALESCE(SUM(amount) FILTER (WHERE status IN ('paid','partially_paid')),0) AS paid FROM payments GROUP BY order_id) SELECT COUNT(*) FILTER (WHERE o.status IN ('open','in_progress','ready'))::int AS open_orders, COUNT(*) FILTER (WHERE o.status='closed')::int AS closed_orders, COALESCE(SUM(CASE WHEN o.status IN ('open','in_progress','ready') THEN GREATEST(0,GREATEST(COALESCE(o.vip_minimum,0),COALESCE(i.subtotal,0)-COALESCE(d.discount,0))-COALESCE(p.paid,0)) ELSE 0 END),0) AS pending_revenue FROM orders o LEFT JOIN item_totals i ON i.order_id=o.id LEFT JOIN discount_totals d ON d.order_id=o.id LEFT JOIN paid_totals p ON p.order_id=o.id WHERE o.venue_id=$1`, [venueDbId]),
          repositories.pool.query(`SELECT COUNT(*)::int AS count FROM discounts d JOIN orders o ON o.id=d.order_id WHERE o.venue_id=$1 AND d.status='requested'`, [venueDbId]),
          repositories.pool.query(`SELECT COUNT(*)::int AS count FROM users WHERE venue_id=$1 AND is_active=true`, [venueDbId]),
          repositories.pool.query(`SELECT COUNT(*)::int AS count FROM reservations r JOIN venues v ON v.id=r.venue_id WHERE r.venue_id=$1 AND (r.starts_at AT TIME ZONE COALESCE(NULLIF(v.timezone,''),'Asia/Yekaterinburg'))::date=(now() AT TIME ZONE COALESCE(NULLIF(v.timezone,''),'Asia/Yekaterinburg'))::date AND r.status='confirmed'`, [venueDbId]),
          repositories.pool.query(`WITH stock_balances AS (
            SELECT venue_id,ingredient_id,COALESCE(SUM(CASE WHEN direction IN ('in','transfer','adjustment') THEN quantity WHEN direction IN ('out','waste') THEN -quantity ELSE 0 END),0) AS on_hand
            FROM stock_movements WHERE venue_id=$1 GROUP BY venue_id,ingredient_id
          ) SELECT COUNT(*)::int AS count FROM ingredients i LEFT JOIN stock_balances b ON b.venue_id=i.venue_id AND b.ingredient_id=i.id
            WHERE i.venue_id=$1 AND i.is_marked=true AND i.min_stock > 0 AND COALESCE(b.on_hand,0) <= i.min_stock`, [venueDbId])
        ]);
        const orderRow = ordersMetric.rows[0] || {};
        return json(res, 200, visibleMetrics(req, { openOrders: Number(orderRow.open_orders || 0), pendingOrders: Number(orderRow.open_orders || 0), pendingRevenue: Number(orderRow.pending_revenue || 0), closedOrders: Number(orderRow.closed_orders || 0), discountRequests: Number(discountsMetric.rows[0]?.count || 0), staffActive: Number(staffMetric.rows[0]?.count || 0), reservationsToday: Number(reservationsMetric.rows[0]?.count || 0), lowStock: Number(stockMetric.rows[0]?.count || 0) }));
      } catch (error) { return json(res, 503, { error: 'database_unavailable', detail: error.message }); }
    }
    return json(res, 200, visibleMetrics(req, metrics()));
  }
  if (pathname === '/api/analytics' && req.method === 'GET') {
    if (process.env.AUTH_REQUIRED === 'true' && !hasPermission(req, 'finance_read') && !hasPermission(req, 'finance')) return json(res, 403, { error: 'forbidden', permission: 'analytics' });
    const employeeFinanceView = isOperationalEmployee(req); const requestedPeriod = employeeFinanceView ? '1' : String(url.searchParams.get('days') || '7').trim().toLowerCase(); const isAllTime = !employeeFinanceView && (requestedPeriod === 'all' || requestedPeriod === '0'); const requestedDays = Number(requestedPeriod); const analyticsDays = employeeFinanceView ? 1 : (isAllTime ? 365 : Math.min(Math.max(Number.isFinite(requestedDays) ? Math.round(requestedDays) : 7, 3), 90)); const end = new Date(); let venueTimezone = businessTimezone; let endDate = businessDateKey(end); if (repositories?.pool) { try { const { rows } = await repositories.pool.query('SELECT timezone FROM venues WHERE id=$1', [venueDbId]); venueTimezone = String(rows[0]?.timezone || businessTimezone); try { new Intl.DateTimeFormat('en-US', { timeZone: venueTimezone }).format(end); } catch (_) { venueTimezone = businessTimezone; } const localDate = await repositories.pool.query('SELECT (now() AT TIME ZONE $1)::date::text AS date', [venueTimezone]); endDate = localDate.rows[0]?.date || endDate; } catch (error) { return json(res, 503, { error: 'database_unavailable', detail: error.message }); } } let startDate; if (isAllTime && repositories?.pool) { try { const { rows } = await repositories.pool.query(`SELECT to_char(COALESCE(LEAST((SELECT MIN((closed_at AT TIME ZONE $2)::date) FROM orders WHERE venue_id=$1 AND status='closed'), (SELECT MIN(expense_date) FROM expenses WHERE venue_id=$1 AND source<>'payroll'), (SELECT MIN(period_from) FROM payroll_entries WHERE venue_id=$1 AND status IN ('approved','paid')), (SELECT MIN((o.closed_at AT TIME ZONE $2)::date) FROM order_costs c JOIN orders o ON o.id=c.order_id WHERE c.venue_id=$1)), $3::date), 'YYYY-MM-DD') AS start_date`, [venueDbId, venueTimezone, endDate]); startDate = String(rows[0]?.start_date || endDate).slice(0, 10); } catch (error) { return json(res, 503, { error: 'database_unavailable', detail: error.message }); } } else { const start = new Date(`${endDate}T00:00:00Z`); start.setUTCDate(start.getUTCDate() - (analyticsDays - 1)); startDate = start.toISOString().slice(0, 10); }
    if (employeeFinanceView && repositories?.pool) {
      try {
        const actorId = /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null;
        const { rows } = await repositories.pool.query(`SELECT COALESCE(SUM(p.amount),0) AS revenue, COUNT(DISTINCT o.id)::int AS orders FROM orders o JOIN payments p ON p.order_id=o.id WHERE o.venue_id=$1 AND o.opened_by=$2 AND o.status='closed' AND (o.closed_at AT TIME ZONE $4)::date=$3::date AND p.status IN ('paid','partially_paid')`, [venueDbId, actorId, endDate, venueTimezone]);
        const revenue = Number(rows[0]?.revenue || 0); const ordersCount = Number(rows[0]?.orders || 0); return json(res, 200, { employeeView: true, period: 'today', days: [{ date: endDate, revenue, orders: ordersCount, averageCheck: ordersCount ? revenue / ordersCount : 0 }], totalRevenue: revenue, averageCheck: ordersCount ? revenue / ordersCount : 0, staffDynamics: [], staffSales: [], topProducts: [], byStation: {}, hallLoad: { busy: 0, total: 0 } });
      } catch (error) { return json(res, 503, { error: 'database_unavailable', detail: error.message }); }
    }
    if (repositories?.pool) {
      try {
        const [daily, products, hall, staffRows, stationRows, expenseRows, payrollRows, cashOutflowRows, costRows, staffItemRows, checkRows] = await Promise.all([
          repositories.pool.query(`SELECT to_char(d::date,'YYYY-MM-DD') AS date, COALESCE(SUM(p.amount),0) AS revenue, COUNT(DISTINCT o.id)::int AS orders FROM generate_series($2::date,$3::date,'1 day') d LEFT JOIN orders o ON o.venue_id=$1 AND o.status='closed' AND (o.closed_at AT TIME ZONE $4)::date=d::date LEFT JOIN payments p ON p.order_id=o.id AND p.status IN ('paid','partially_paid') GROUP BY d::date ORDER BY d::date`, [venueDbId, startDate, endDate, venueTimezone]),
          repositories.pool.query(`SELECT COALESCE(p.name,'Позиция') AS name, SUM(oi.quantity)::numeric AS quantity FROM order_items oi JOIN orders o ON o.id=oi.order_id JOIN products p ON p.id=oi.product_id WHERE o.venue_id=$1 AND o.status='closed' AND (o.closed_at AT TIME ZONE $4)::date BETWEEN $2::date AND $3::date GROUP BY p.name ORDER BY quantity DESC LIMIT 5`, [venueDbId, startDate, endDate, venueTimezone]),
          repositories.pool.query(`SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE t.status IN ('occupied','reserved'))::int AS busy FROM tables t JOIN zones z ON z.id=t.zone_id WHERE z.venue_id=$1`, [venueDbId]),
          repositories.pool.query(`SELECT COALESCE(u.full_name,u.login,'Не указан') AS name, COALESCE(SUM(p.amount),0) AS revenue, COUNT(DISTINCT o.id)::int AS orders FROM orders o LEFT JOIN payments p ON p.order_id=o.id AND p.status IN ('paid','partially_paid') LEFT JOIN users u ON u.id=o.opened_by WHERE o.venue_id=$1 AND o.status='closed' AND (o.closed_at AT TIME ZONE $4)::date BETWEEN $2::date AND $3::date GROUP BY u.full_name,u.login ORDER BY revenue DESC`, [venueDbId, startDate, endDate, venueTimezone]),
          repositories.pool.query(`SELECT oi.order_id AS order_id, COALESCE(oi.station,'other') AS station, COALESCE(SUM(oi.quantity * oi.unit_price),0) AS gross FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.venue_id=$1 AND o.status='closed' AND (o.closed_at AT TIME ZONE $4)::date BETWEEN $2::date AND $3::date GROUP BY oi.order_id,COALESCE(oi.station,'other')`, [venueDbId, startDate, endDate, venueTimezone]),
          repositories.pool.query(`SELECT to_char(expense_date,'YYYY-MM-DD') AS date, COALESCE(SUM(amount),0) AS amount FROM expenses WHERE venue_id=$1 AND expense_date BETWEEN $2::date AND $3::date AND source NOT IN ('payroll','purchase') GROUP BY expense_date`, [venueDbId, startDate, endDate]),
          repositories.pool.query(`SELECT to_char(d::date,'YYYY-MM-DD') AS date, COALESCE(SUM(pe.amount / (pe.period_to - pe.period_from + 1)),0) AS amount FROM payroll_entries pe CROSS JOIN LATERAL generate_series(GREATEST(pe.period_from,$2::date)::timestamp,LEAST(pe.period_to,$3::date)::timestamp,INTERVAL '1 day') d WHERE pe.venue_id=$1 AND pe.status IN ('approved','paid') AND pe.period_from <= $3::date AND pe.period_to >= $2::date GROUP BY d::date`, [venueDbId, startDate, endDate]),
          repositories.pool.query(`SELECT to_char(expense_date,'YYYY-MM-DD') AS date, COALESCE(SUM(amount),0) AS amount FROM expenses e WHERE e.venue_id=$1 AND e.expense_date BETWEEN $2::date AND $3::date AND (e.source <> 'payroll' OR EXISTS (SELECT 1 FROM payroll_entries pe WHERE pe.venue_id=e.venue_id AND pe.expense_id=e.id AND pe.status='paid')) GROUP BY e.expense_date`, [venueDbId, startDate, endDate]),
          repositories.pool.query(`SELECT to_char((o.closed_at AT TIME ZONE $4)::date,'YYYY-MM-DD') AS date, COALESCE(SUM(c.cost),0) AS amount FROM order_costs c JOIN orders o ON o.id=c.order_id AND o.venue_id=c.venue_id WHERE c.venue_id=$1 AND (o.closed_at AT TIME ZONE $4)::date BETWEEN $2::date AND $3::date GROUP BY (o.closed_at AT TIME ZONE $4)::date`, [venueDbId, startDate, endDate, venueTimezone]),
          repositories.pool.query(`SELECT o.id AS order_id, COALESCE(u.full_name,u.login,'Не указан') AS staff_name, COALESCE(p.name,'Позиция') AS product_name, SUM(oi.quantity)::numeric AS quantity, COALESCE(SUM(oi.quantity * oi.unit_price),0)::numeric AS gross FROM order_items oi JOIN orders o ON o.id=oi.order_id LEFT JOIN users u ON u.id=o.opened_by LEFT JOIN products p ON p.id=oi.product_id WHERE o.venue_id=$1 AND o.status='closed' AND (o.closed_at AT TIME ZONE $4)::date BETWEEN $2::date AND $3::date GROUP BY o.id,COALESCE(u.full_name,u.login,'Не указан'),COALESCE(p.name,'Позиция') ORDER BY staff_name, gross DESC`, [venueDbId, startDate, endDate, venueTimezone]),
          repositories.pool.query(`SELECT o.id AS order_id, to_char((o.closed_at AT TIME ZONE $4)::date,'YYYY-MM-DD') AS date, COALESCE(SUM(p.amount) FILTER (WHERE p.status IN ('paid','partially_paid')),0)::numeric AS check_total FROM orders o LEFT JOIN payments p ON p.order_id=o.id WHERE o.venue_id=$1 AND o.status='closed' AND (o.closed_at AT TIME ZONE $4)::date BETWEEN $2::date AND $3::date GROUP BY o.id,o.closed_at ORDER BY o.closed_at`, [venueDbId, startDate, endDate, venueTimezone])
        ]);
        const expenseMap = Object.fromEntries(expenseRows.rows.map((row) => [String(row.date).slice(0, 10), Number(row.amount || 0)])); const payrollMap = Object.fromEntries(payrollRows.rows.map((row) => [String(row.date).slice(0, 10), Number(row.amount || 0)])); const cashOutflowMap = Object.fromEntries(cashOutflowRows.rows.map((row) => [String(row.date).slice(0, 10), Number(row.amount || 0)])); const costsByDate = Object.fromEntries(costRows.rows.map((row) => [String(row.date).slice(0, 10), Number(row.amount || 0)])); const checksByDate = new Map(); for (const row of checkRows.rows) { const key = String(row.date).slice(0, 10); checksByDate.set(key, [...(checksByDate.get(key) || []), Number(row.check_total || 0)]); } const days = daily.rows.map((row) => { const date = String(row.date).slice(0, 10); const revenue = Number(row.revenue || 0); const expenses = (expenseMap[date] || 0) + (payrollMap[date] || 0); const cashOutflow = cashOutflowMap[date] || 0; const costOfGoods = costsByDate[date] || 0; const orders = Number(row.orders || 0); return { date, revenue, expenses, payroll: payrollMap[date] || 0, cashOutflow, costOfGoods, netProfit: revenue - expenses - costOfGoods, orders, averageCheck: orders ? revenue / orders : 0, medianCheck: medianOf(checksByDate.get(date) || []), tables: 0 }; }); const totalRevenue = days.reduce((sum, row) => sum + row.revenue, 0); const totalExpenses = days.reduce((sum, row) => sum + row.expenses, 0); const totalPayroll = days.reduce((sum, row) => sum + row.payroll, 0); const totalCashOutflow = days.reduce((sum, row) => sum + row.cashOutflow, 0); const totalCostOfGoods = days.reduce((sum, row) => sum + row.costOfGoods, 0); const totalOrders = days.reduce((sum, row) => sum + row.orders, 0); const hallRow = hall.rows[0] || {};
        const checkAmountsByOrder = new Map(checkRows.rows.map((row) => [String(row.order_id), Number(row.check_total || 0)])); const staffSalesMap = new Map(); const staffItemsByOrder = new Map(); for (const row of staffItemRows.rows) { const orderId = String(row.order_id); const rows = staffItemsByOrder.get(orderId) || []; rows.push(row); staffItemsByOrder.set(orderId, rows); } for (const [orderId, rows] of staffItemsByOrder) { const staffName = String(rows[0]?.staff_name || 'Не указан'); const entry = staffSalesMap.get(staffName) || { name: staffName, items: [], revenue: 0, orders: 0 }; const allocations = allocateMoneyByGross(rows, checkAmountsByOrder.get(orderId) || 0, (row) => row.product_name, (row) => Number(row.gross || 0)); for (const row of rows) { const name = String(row.product_name || 'Позиция'); const item = entry.items.find((existing) => existing.name === name); const revenue = allocations.get(name) || 0; if (item) { item.quantity += Number(row.quantity || 0); item.revenue += revenue; } else entry.items.push({ name, quantity: Number(row.quantity || 0), revenue }); } staffSalesMap.set(staffName, entry); } for (const row of staffRows.rows) { const name = String(row.name || 'Не указан'); const entry = staffSalesMap.get(name) || { name, items: [], revenue: 0, orders: 0 }; entry.revenue = Number(row.revenue || 0); entry.orders = Number(row.orders || 0); staffSalesMap.set(name, entry); } const stationTotals = new Map(); const stationsByOrder = new Map(); for (const row of stationRows.rows) { const orderId = String(row.order_id); const rows = stationsByOrder.get(orderId) || []; rows.push(row); stationsByOrder.set(orderId, rows); } for (const [orderId, rows] of stationsByOrder) { const allocations = allocateMoneyByGross(rows, checkAmountsByOrder.get(orderId) || 0, (row) => row.station, (row) => Number(row.gross || 0)); for (const row of rows) { const station = String(row.station || 'other'); const entry = stationTotals.get(station) || { revenue: 0, orders: 0 }; entry.revenue += allocations.get(station) || 0; entry.orders += 1; stationTotals.set(station, entry); } } const byStation = Object.fromEntries([...stationTotals].map(([station, row]) => [station, { ...row, averageCheck: row.orders ? row.revenue / row.orders : 0 }])); const fullAnalytics = { days, totalRevenue, totalExpenses, totalPayroll, totalCashOutflow, totalCostOfGoods, netProfit: totalRevenue - totalExpenses - totalCostOfGoods, averageCheck: totalOrders ? totalRevenue / totalOrders : 0, topProducts: products.rows.map((row) => ({ name: row.name, quantity: Number(row.quantity || 0) })), staffDynamics: staffRows.rows.map((row) => ({ name: row.name, revenue: Number(row.revenue || 0), orders: Number(row.orders || 0) })), staffSales: [...staffSalesMap.values()].sort((a, b) => b.revenue - a.revenue), medianCheck: medianOf(checkRows.rows.map((row) => row.check_total)), avgTablesPerDay: 0, byStation, hallLoad: { busy: Number(hallRow.busy || 0), total: Number(hallRow.total || 0) } }; if (employeeFinanceView) return json(res, 200, { employeeView: true, period: 'today', days: days.map((day) => ({ date: day.date, revenue: day.revenue, orders: day.orders, averageCheck: day.orders ? day.revenue / day.orders : 0 })), totalRevenue, averageCheck: fullAnalytics.averageCheck, staffDynamics: [], staffSales: [], topProducts: [], byStation: {}, hallLoad: { busy: 0, total: 0 } }); return json(res, 200, fullAnalytics);
      } catch (error) {
        return json(res, 503, { error: 'database_unavailable', detail: error.message });
      }
    }
    const employeeOrders = employeeFinanceView ? orders.filter((order) => String(order.openedBy || order.openedById || '') === String(req.user?.id || '')) : orders;
    const paidOrderAmount = (order) => (order.payments || []).filter((payment) => ['paid', 'partially_paid'].includes(payment.status)).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
    const revenueForOrder = (order) => { const paid = paidOrderAmount(order); if (paid > 0) return paid; if (order.finalTotal !== undefined && order.finalTotal !== null) return Number(order.finalTotal); return orderNetTotal(order); };
    const dayKey = (value) => businessDateKey(value);
    const dayDates = recentBusinessDates(analyticsDays);
    const days = dayDates.map((date) => {
      const closed = employeeOrders.filter((order) => order.status === 'closed' && dayKey(order.closedAt || order.createdAt) === date && (!employeeFinanceView || paidOrderAmount(order) > 0));
      const checks = closed.map((order) => employeeFinanceView ? paidOrderAmount(order) : revenueForOrder(order)).sort((a, b) => a - b);
      const revenue = checks.reduce((sum, value) => sum + value, 0);
      const costOfGoods = closed.reduce((sum, order) => sum + Number(order.costOfGoods || 0), 0);
      const medianCheck = checks.length ? (checks.length % 2 ? checks[(checks.length - 1) / 2] : (checks[checks.length / 2 - 1] + checks[checks.length / 2]) / 2) : 0;
      const expenses = manualExpenses.filter((expense) => expense.date === date && !['purchase', 'payroll'].includes(expense.source)).reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
      return { date, revenue, expenses, payroll: 0, costOfGoods, netProfit: revenue - expenses - costOfGoods, orders: closed.length, averageCheck: closed.length ? revenue / closed.length : 0, medianCheck, tables: new Set(closed.map((order) => order.tableId).filter(Boolean)).size };
    });
    const counts = new Map();
    employeeOrders.filter((order) => order.status === 'closed' && dayDates.includes(dayKey(order.closedAt || order.createdAt))).flatMap((order) => order.items || []).forEach((item) => { const name = item.name || item.productName || item.productId || 'Позиция'; counts.set(name, (counts.get(name) || 0) + Number(item.quantity || 0)); });
    const totalRevenue = days.reduce((sum, row) => sum + row.revenue, 0);
    const totalExpenses = days.reduce((sum, row) => sum + row.expenses, 0);
    const totalCostOfGoods = days.reduce((sum, row) => sum + row.costOfGoods, 0);
    const totalOrders = days.reduce((sum, row) => sum + row.orders, 0);
    const staffMap = new Map(); const staffSalesMap = new Map(); const stationMap = new Map();
employeeOrders.filter((order) => order.status === 'closed' && dayDates.includes(dayKey(order.closedAt || order.createdAt))).forEach((order) => {
  const orderRevenue = employeeFinanceView ? paidOrderAmount(order) : revenueForOrder(order);
  const name = order.createdByName || order.waiterName || 'Не указан'; const row = staffMap.get(name) || { name, revenue: 0, orders: 0 }; row.revenue += orderRevenue; row.orders += 1; staffMap.set(name, row);
  const sales = staffSalesMap.get(name) || { name, items: [], revenue: 0, orders: 0 }; sales.revenue = row.revenue; sales.orders = row.orders;
  const itemsByName = new Map(); for (const item of order.items || []) { const itemName = item.name || item.productName || item.productId || 'Позиция'; const line = itemsByName.get(itemName) || { name: itemName, quantity: 0, gross: 0 }; line.quantity += Number(item.quantity || 0); line.gross += Number(item.unitPrice || item.price || 0) * Number(item.quantity || 0); itemsByName.set(itemName, line); }
  const productLines = [...itemsByName.values()]; const productRevenue = allocateMoneyByGross(productLines, orderRevenue, (item) => item.name, (item) => item.gross);
  for (const item of productLines) { const existing = sales.items.find((entry) => entry.name === item.name); const itemRevenue = productRevenue.get(item.name) || 0; if (existing) { existing.quantity += item.quantity; existing.revenue += itemRevenue; } else sales.items.push({ name: item.name, quantity: item.quantity, revenue: itemRevenue }); }
  staffSalesMap.set(name, sales);
  const itemsByStation = new Map(); for (const item of order.items || []) { const station = item.station || 'other'; itemsByStation.set(station, (itemsByStation.get(station) || 0) + Number(item.unitPrice || item.price || 0) * Number(item.quantity || 0)); }
  const stationLines = [...itemsByStation].map(([station, gross]) => ({ station, gross })); const stationRevenue = allocateMoneyByGross(stationLines, orderRevenue, (item) => item.station, (item) => item.gross);
  for (const [station, amount] of stationRevenue) { const entry = stationMap.get(station) || { revenue: 0, orders: 0 }; entry.revenue += amount; if (stationLines.some((item) => item.station === station)) entry.orders += 1; stationMap.set(station, entry); }
});
const byStation = Object.fromEntries([...stationMap].map(([station, entry]) => [station, { ...entry, averageCheck: entry.orders ? entry.revenue / entry.orders : 0 }])); const tables = floor.flatMap((zone) => zone.tables || []);
    const periodChecks = employeeOrders.filter((order) => order.status === 'closed' && dayDates.includes(dayKey(order.closedAt || order.createdAt)) && (!employeeFinanceView || paidOrderAmount(order) > 0)).map((order) => employeeFinanceView ? paidOrderAmount(order) : revenueForOrder(order));
    const fullAnalytics = { days, totalRevenue, totalExpenses, totalCostOfGoods, netProfit: totalRevenue - totalExpenses - totalCostOfGoods, averageCheck: totalOrders ? totalRevenue / totalOrders : 0, topProducts: [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, quantity]) => ({ name, quantity })), staffDynamics: [...staffMap.values()].sort((a, b) => b.revenue - a.revenue), staffSales: [...staffSalesMap.values()].sort((a, b) => b.revenue - a.revenue), medianCheck: medianOf(periodChecks), avgTablesPerDay: days.length ? days.reduce((sum, row) => sum + row.tables, 0) / days.length : 0, byStation, hallLoad: { busy: tables.filter((table) => ['occupied', 'reserved'].includes(table.status)).length, total: tables.length } };
    return json(res, 200, employeeFinanceView ? { employeeView: true, period: 'today', days: days.map((day) => ({ date: day.date, revenue: day.revenue, orders: day.orders, averageCheck: day.averageCheck })), totalRevenue, averageCheck: fullAnalytics.averageCheck, staffDynamics: [], staffSales: [], topProducts: [], byStation: {}, hallLoad: { busy: 0, total: 0 } } : fullAnalytics);
  }
  if (pathname === '/api/audit' && req.method === 'GET') {
    if (process.env.AUTH_REQUIRED === 'true' && !hasPermission(req, 'diagnostics') && !hasPermission(req, 'settings')) return json(res, 403, { error: 'forbidden', permission: 'diagnostics' });
    const filters = { action: String(url.searchParams.get('action') || '').trim().slice(0, 120), entityType: String(url.searchParams.get('entityType') || '').trim().slice(0, 80), from: String(url.searchParams.get('from') || '').trim(), to: String(url.searchParams.get('to') || '').trim(), limit: url.searchParams.get('limit') };
    if (filters.from && !/^\d{4}-\d{2}-\d{2}$/.test(filters.from)) filters.from = '';
    if (filters.to && !/^\d{4}-\d{2}-\d{2}$/.test(filters.to)) filters.to = '';
    if (repositories?.audit) { try { return json(res, 200, { items: await repositories.audit.list(venueDbId, filters), filters }); } catch (_) { return json(res, 503, { error: 'audit_unavailable' }); } }
    if (process.env.DATABASE_URL) return json(res, 503, { error: 'audit_unavailable' });
    let items = auditEvents.slice().reverse();
    items = items.filter((item) => String(item.venueId || defaultVenueDbId) === String(venueDbId));
    if (filters.action) items = items.filter((item) => item.action === filters.action);
    if (filters.entityType) items = items.filter((item) => item.entityType === filters.entityType);
    if (filters.from) items = items.filter((item) => String(item.createdAt).slice(0, 10) >= filters.from);
    if (filters.to) items = items.filter((item) => String(item.createdAt).slice(0, 10) <= filters.to);
    items = items.slice(0, Math.min(Math.max(Number(filters.limit) || 100, 1), 300));
    return json(res, 200, { items, total: items.length, filters });
  }
  const floorTablePath = pathname.match(/^\/api\/floor\/tables\/([^/]+)$/);
  if ((pathname === '/api/floor' || pathname.startsWith('/api/floor/')) && process.env.DATABASE_URL && !repositories?.pool) return json(res, 503, { error: 'floor_unavailable' });
  if (pathname === '/api/floor/zones' && req.method === 'POST') {
    if (denyUnless(req, res, 'settings')) return;
    const input = await body(req); const name = String(input.name || '').trim();
    if (!name || name.length > 80) return json(res, 400, { error: 'invalid_zone_name' });
    const sortOrder = Number.isInteger(Number(input.sortOrder)) ? Number(input.sortOrder) : floor.length;
    return runFloorMutation(req, res, input.expectedVenueId, repositories?.pool ? venueDbId : currentVenueId, async (client) => {
      const nextSortOrder = client && input.sortOrder === undefined ? Number((await client.query('SELECT COALESCE(MAX(sort_order),-1)+1 AS next_order FROM zones WHERE venue_id=$1', [venueDbId])).rows[0].next_order) : sortOrder;
      const zone = client
        ? { ...(await client.query('INSERT INTO zones (venue_id,name,sort_order) VALUES ($1,$2,$3) RETURNING id,name,sort_order', [venueDbId, name, nextSortOrder])).rows[0], tables: [] }
        : { id: `zone-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, name, sortOrder: nextSortOrder, tables: [] };
      if (!client) floor.push(zone);
      return { status: 201, body: zone, audit: { action: 'floor_zone.created', entityType: 'zone', entityId: zone.id, before: null, after: zone } };
    });
  }
  const floorZonePath = pathname.match(/^\/api\/floor\/zones\/([^/]+)$/);
  if (floorZonePath && ['PATCH', 'DELETE'].includes(req.method)) {
    if (denyUnless(req, res, 'settings')) return;
    const zoneId = decodeURIComponent(floorZonePath[1]);
    if (repositories?.pool && !/^[0-9a-f-]{36}$/i.test(zoneId)) return json(res, 404, { error: 'zone_not_found' });
    const input = await body(req);
    const name = String(input.name || '').trim();
    if (req.method === 'PATCH' && (!name || name.length > 80)) return json(res, 400, { error: 'invalid_zone_name' });
    return runFloorMutation(req, res, input.expectedVenueId, repositories?.pool ? venueDbId : currentVenueId, async (client) => {
      if (client) {
        if (req.method === 'PATCH') {
          const { rows } = await client.query('UPDATE zones SET name=$1,sort_order=COALESCE($2,sort_order) WHERE id=$3 AND venue_id=$4 RETURNING id,name,sort_order', [name, input.sortOrder === undefined ? null : Number(input.sortOrder), zoneId, venueDbId]);
          if (!rows[0]) return { status: 404, body: { error: 'zone_not_found' } };
          return { status: 200, body: rows[0], audit: { action: 'floor_zone.updated', entityType: 'zone', entityId: zoneId, before: null, after: rows[0] } };
        }
        const count = await client.query('SELECT COUNT(*)::int AS count FROM tables t JOIN zones z ON z.id=t.zone_id WHERE z.id=$1 AND z.venue_id=$2', [zoneId, venueDbId]);
        if (Number(count.rows[0]?.count || 0)) return { status: 409, body: { error: 'zone_not_empty' } };
        const { rows } = await client.query('DELETE FROM zones WHERE id=$1 AND venue_id=$2 RETURNING id,name,sort_order', [zoneId, venueDbId]);
        if (!rows[0]) return { status: 404, body: { error: 'zone_not_found' } };
        return { status: 200, body: rows[0], audit: { action: 'floor_zone.deleted', entityType: 'zone', entityId: zoneId, before: rows[0], after: null } };
      }
      const zone = floor.find((entry) => entry.id === zoneId);
      if (!zone) return { status: 404, body: { error: 'zone_not_found' } };
      const before = { ...zone };
      if (req.method === 'PATCH') {
        zone.name = name;
        if (input.sortOrder !== undefined && Number.isInteger(Number(input.sortOrder))) zone.sortOrder = Number(input.sortOrder);
        return { status: 200, body: zone, audit: { action: 'floor_zone.updated', entityType: 'zone', entityId: zone.id, before, after: zone } };
      }
      if (zone.tables.length) return { status: 409, body: { error: 'zone_not_empty' } };
      floor.splice(floor.indexOf(zone), 1);
      return { status: 200, body: zone, audit: { action: 'floor_zone.deleted', entityType: 'zone', entityId: zone.id, before, after: null } };
    });
  }
  if (pathname === '/api/floor/tables' && req.method === 'POST') {
    if (denyUnless(req, res, 'settings')) return;
    const input = await body(req); const zoneId = String(input.zoneId || '').trim(); const name = String(input.name || '').trim(); const capacity = Number(input.capacity || 2); const minCapacity = Number(input.minCapacity ?? capacity); const maxCapacity = Number(input.maxCapacity ?? capacity); const minimumOrderTotal = Number(input.minimumOrderTotal || 0);
    if (!zoneId || !name || name.length > 80) return json(res, 400, { error: 'invalid_table_name' });
    if (!Number.isInteger(capacity) || capacity < 1 || capacity > 100 || !Number.isInteger(minCapacity) || !Number.isInteger(maxCapacity) || minCapacity < 1 || maxCapacity < minCapacity || maxCapacity > 100) return json(res, 400, { error: 'invalid_table_capacity' });
    if (!Number.isFinite(minimumOrderTotal) || minimumOrderTotal < 0) return json(res, 400, { error: 'invalid_vip_minimum' });
    if (repositories?.pool && !/^[0-9a-f-]{36}$/i.test(zoneId)) return json(res, 404, { error: 'zone_not_found' });
    return runFloorMutation(req, res, input.expectedVenueId, repositories?.pool ? venueDbId : currentVenueId, async (client) => {
      if (client) {
        const { rows } = await client.query('INSERT INTO tables (zone_id,name,capacity,min_capacity,max_capacity,min_deposit,min_order_total) SELECT id,$2,$3,$4,$5,$6,$6 FROM zones WHERE id=$1 AND venue_id=$7 RETURNING id,name,status,capacity,min_capacity,max_capacity,min_order_total,layout', [zoneId, name, capacity, minCapacity, maxCapacity, minimumOrderTotal, venueDbId]);
        if (!rows[0]) return { status: 404, body: { error: 'zone_not_found' } };
        const table = { ...rows[0], minimumOrderTotal: Number(rows[0].min_order_total), minCapacity: Number(rows[0].min_capacity || rows[0].capacity), maxCapacity: Number(rows[0].max_capacity || rows[0].capacity), layout: rows[0].layout || {} };
        return { status: 201, body: table, audit: { action: 'floor_table.created', entityType: 'table', entityId: table.id, before: null, after: table } };
      }
      const zone = floor.find((entry) => entry.id === zoneId);
      if (!zone) return { status: 404, body: { error: 'zone_not_found' } };
      const table = { id: `table-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, name, status: 'free', capacity, minCapacity, maxCapacity, minimumOrderTotal, layout: {} };
      zone.tables.push(table);
      return { status: 201, body: table, audit: { action: 'floor_table.created', entityType: 'table', entityId: table.id, before: null, after: table } };
    });
  }
  if (floorTablePath && req.method === 'PATCH') {
    if (denyUnless(req, res, 'settings')) return;
    const input = await body(req);
    const tableId = decodeURIComponent(floorTablePath[1]);
    if (repositories?.pool && !/^[0-9a-f-]{36}$/i.test(tableId)) return json(res, 404, { error: 'table_not_found' });
    const layout = input.layout && typeof input.layout === 'object' && !Array.isArray(input.layout) ? input.layout : {};
    for (const key of ['x', 'y', 'width', 'height', 'rotation']) if (layout[key] !== undefined && (!Number.isFinite(Number(layout[key])) || Number(layout[key]) < 0 || Number(layout[key]) > 5000)) return json(res, 400, { error: 'invalid_table_layout' });
    if (layout.unit !== undefined && !['px', 'grid'].includes(String(layout.unit))) return json(res, 400, { error: 'invalid_table_layout_unit' });
    if (layout.shape !== undefined && !['rectangle', 'square', 'circle', 'oval', 'freeform'].includes(String(layout.shape))) return json(res, 400, { error: 'invalid_table_shape' });
    if (layout.width !== undefined && Number(layout.width) < 40 || layout.height !== undefined && Number(layout.height) < 40) return json(res, 400, { error: 'table_layout_too_small' });
    const changes = {};
    if (input.name !== undefined) {
      const name = String(input.name).trim();
      if (!name || name.length > 80) return json(res, 400, { error: 'invalid_table_name' });
      changes.name = name;
    }
    if (input.capacity !== undefined || input.minCapacity !== undefined || input.maxCapacity !== undefined) {
      const capacity = Number(input.capacity ?? input.maxCapacity ?? input.minCapacity);
      const minCapacity = Number(input.minCapacity ?? capacity);
      const maxCapacity = Number(input.maxCapacity ?? capacity);
      if (![capacity, minCapacity, maxCapacity].every(Number.isInteger) || capacity < 1 || capacity > 100 || minCapacity < 1 || maxCapacity < minCapacity || maxCapacity > 100) return json(res, 400, { error: 'invalid_table_capacity' });
      Object.assign(changes, { capacity, minCapacity, maxCapacity });
    }
    if (input.minimumOrderTotal !== undefined) {
      const minimum = Number(input.minimumOrderTotal);
      if (!Number.isFinite(minimum) || minimum < 0) return json(res, 400, { error: 'invalid_vip_minimum' });
      changes.minimumOrderTotal = minimum;
    }
    if (input.status !== undefined) {
      if (!['free', 'blocked'].includes(String(input.status))) return json(res, 400, { error: 'invalid_table_status' });
      changes.status = String(input.status);
    }
    if (Object.keys(layout).length) changes.layout = layout;
    if (!Object.keys(changes).length) return json(res, 400, { error: 'table_changes_required' });
    return runFloorMutation(req, res, input.expectedVenueId, repositories?.pool ? venueDbId : currentVenueId, async (client) => {
      if (client) {
        const fields = [];
        const values = [];
        const set = (column, value) => { values.push(value); fields.push(`${column}=$${values.length}`); };
        if (changes.name !== undefined) set('name', changes.name);
        if (changes.capacity !== undefined) { set('capacity', changes.capacity); set('min_capacity', changes.minCapacity); set('max_capacity', changes.maxCapacity); }
        if (changes.minimumOrderTotal !== undefined) { set('min_deposit', changes.minimumOrderTotal); set('min_order_total', changes.minimumOrderTotal); }
        if (changes.status !== undefined) set('status', changes.status);
        if (changes.layout !== undefined) { values.push(JSON.stringify(changes.layout)); fields.push(`layout=COALESCE(t.layout,'{}'::jsonb) || $${values.length}::jsonb`); }
        values.push(tableId, venueDbId);
        const { rows } = await client.query(`UPDATE tables t SET ${fields.join(',')} FROM zones z WHERE t.id=$${values.length - 1} AND t.zone_id=z.id AND z.venue_id=$${values.length} RETURNING t.id,t.name,t.status,t.capacity,t.min_capacity,t.max_capacity,t.min_order_total,t.layout`, values);
        if (!rows[0]) return { status: 404, body: { error: 'table_not_found' } };
        const table = { ...rows[0], minimumOrderTotal: Number(rows[0].min_order_total), minCapacity: Number(rows[0].min_capacity || rows[0].capacity), maxCapacity: Number(rows[0].max_capacity || rows[0].capacity), layout: rows[0].layout || {} };
        return { status: 200, body: table, audit: { action: 'floor_table.updated', entityType: 'table', entityId: tableId, before: null, after: table } };
      }
      const table = floor.flatMap((zone) => zone.tables).find((entry) => entry.id === tableId);
      if (!table) return { status: 404, body: { error: 'table_not_found' } };
      const before = { ...table, layout: { ...(table.layout || {}) } };
      Object.assign(table, changes);
      if (changes.layout !== undefined) table.layout = { ...before.layout, ...changes.layout };
      return { status: 200, body: table, audit: { action: 'floor_table.updated', entityType: 'table', entityId: tableId, before, after: table } };
    });
  }
  if (floorTablePath && req.method === 'DELETE') {
    if (denyUnless(req, res, 'settings')) return;
    const input = await body(req);
    const tableId = decodeURIComponent(floorTablePath[1]);
    if (repositories?.pool && !/^[0-9a-f-]{36}$/i.test(tableId)) return json(res, 404, { error: 'table_not_found' });
    return runFloorMutation(req, res, input.expectedVenueId, repositories?.pool ? venueDbId : currentVenueId, async (client) => {
      if (client) {
        const active = await client.query("SELECT 1 FROM orders WHERE table_id=$1 AND venue_id=$2 AND status IN ('open','in_progress','ready') LIMIT 1", [tableId, venueDbId]);
        if (active.rows[0]) return { status: 409, body: { error: 'table_in_use' } };
        const { rows } = await client.query('DELETE FROM tables WHERE id=$1 AND zone_id IN (SELECT id FROM zones WHERE venue_id=$2) RETURNING id,name,zone_id', [tableId, venueDbId]);
        if (!rows[0]) return { status: 404, body: { error: 'table_not_found' } };
        return { status: 200, body: rows[0], audit: { action: 'floor_table.deleted', entityType: 'table', entityId: tableId, before: rows[0], after: null } };
      }
      const zone = floor.find((entry) => entry.tables.some((table) => table.id === tableId));
      const table = zone?.tables.find((entry) => entry.id === tableId);
      if (!table) return { status: 404, body: { error: 'table_not_found' } };
      if (orders.some((order) => order.tableId === tableId && ['open', 'in_progress', 'ready'].includes(order.status))) return { status: 409, body: { error: 'table_in_use' } };
      zone.tables.splice(zone.tables.indexOf(table), 1);
      return { status: 200, body: table, audit: { action: 'floor_table.deleted', entityType: 'table', entityId: tableId, before: table, after: null } };
    });
  }
  if (pathname === '/api/floor') {
    if (denyUnless(req, res, 'floor')) return;
    if (repositories?.pool) {
      if (requireOrganizationContext(req, res)) return;
      try {
        const organizationId = requestOrganizationId(req) || null;
        const selected = await repositories.pool.query('SELECT id FROM venues WHERE id=$1 AND ($2::uuid IS NULL OR organization_id=$2::uuid) AND is_active=true', [venueDbId, organizationId]);
        if (!selected.rows[0]) return json(res, 404, { error: 'venue_not_found' });
      } catch (_) { return json(res, 503, { error: 'floor_unavailable' }); }
    }
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query(`SELECT z.id AS zone_id,z.name AS zone_name,z.sort_order,t.id,t.name,CASE WHEN t.status='blocked'::table_status THEN 'blocked' WHEN EXISTS (SELECT 1 FROM orders o WHERE o.table_id=t.id AND o.venue_id=$1 AND o.status IN ('open','in_progress','ready')) THEN 'occupied' WHEN EXISTS (SELECT 1 FROM reservations r JOIN venues v ON v.id=r.venue_id WHERE r.table_id=t.id AND r.venue_id=$1 AND r.status='confirmed' AND (r.starts_at AT TIME ZONE COALESCE(NULLIF(v.timezone,''),'Asia/Yekaterinburg'))::date=(now() AT TIME ZONE COALESCE(NULLIF(v.timezone,''),'Asia/Yekaterinburg'))::date) THEN 'reserved' ELSE CASE WHEN t.status='reserved'::table_status THEN 'free'::table_status ELSE t.status END END AS status,t.capacity,t.min_capacity,t.max_capacity,t.min_order_total,t.layout FROM zones z LEFT JOIN tables t ON t.zone_id=z.id WHERE z.venue_id=$1 ORDER BY z.sort_order,CASE WHEN regexp_replace(t.name, '\\D', '', 'g') ~ '^[0-9]{1,9}$' THEN regexp_replace(t.name, '\\D', '', 'g')::int END NULLS LAST,t.name`, [venueDbId]); const zones = []; for (const row of rows) { let zone = zones.find((entry) => entry.id === row.zone_id); if (!zone) { zone = { id: row.zone_id, name: row.zone_name, tables: [] }; zones.push(zone); } if (row.id) zone.tables.push({ id: row.id, name: row.name, status: row.status, capacity: row.capacity, minCapacity: Number(row.min_capacity || row.capacity), maxCapacity: Number(row.max_capacity || row.capacity), minimumOrderTotal: Number(row.min_order_total), layout: row.layout || {} }); } return json(res, 200, { venueId: venueDbId, zones }); } catch (_) { return json(res, 503, { error: 'floor_unavailable' }); } }
    const derivedFloor = floor.map((zone) => ({ ...zone, tables: zone.tables.map((table) => { const reservation = reservations.find((entry) => entry.tableId === table.id && entry.status === 'confirmed' && entry.date === today()); const occupied = orders.some((order) => order.tableId === table.id && ['open', 'in_progress', 'ready'].includes(order.status)); return { ...table, status: table.status === 'blocked' ? 'blocked' : (occupied ? 'occupied' : reservation ? 'reserved' : table.status === 'reserved' ? 'free' : table.status), reservation: reservation ? { id: reservation.id, guestName: reservation.guestName, date: reservation.date, time: reservation.time, createdByName: reservation.createdByName || 'Сотрудник', createdByRole: reservation.createdByRole || 'Сотрудник' } : null }; }) }));
    return json(res, 200, { venueId: currentVenueId, zones: derivedFloor });
  }
  const tobaccoCatalogPath = pathname.match(/^\/api\/tobacco-catalog\/([^/]+)$/);
  const tobaccoCatalogActor = /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null;
  const tobaccoCatalogOrganizationId = requestOrganizationId(req) || (repositories?.pool ? '' : saasAccount.id);
  const tobaccoCatalogVenueId = req.user?.venueId || venueDbId || venue.id;
  const normalizeTobaccoCatalogInput = (raw, current = {}) => {
    const take = (key, max, nullable = false) => {
      const value = raw[key] === undefined ? current[key] : raw[key];
      if (value === null || value === undefined || String(value).trim() === '') return nullable ? null : '';
      const text = String(value).trim();
      if (text.length > max) throw new Error('invalid_tobacco_catalog_item');
      return text;
    };
    const brand = take('brand',120); const flavor = take('flavor',160);
    const productLine = take('productLine',120,true); const productType = raw.productType === undefined ? (current.productType || 'tobacco') : String(raw.productType);
    const packageRaw = raw.packageGrams === undefined ? current.packageGrams : raw.packageGrams;
    const packageGrams = packageRaw === '' || packageRaw === null || packageRaw === undefined ? null : Number(packageRaw);
    const aliasesRaw = raw.aliases === undefined ? current.aliases : raw.aliases;
    const aliases = Array.isArray(aliasesRaw) ? aliasesRaw : typeof aliasesRaw === 'string' ? aliasesRaw.split(',') : [];
    const normalizedAliases = [...new Set(aliases.map((value) => String(value).trim()).filter(Boolean))];
    if (!brand || !flavor || !['tobacco','tobacco_free'].includes(productType) || (packageGrams !== null && (!Number.isFinite(packageGrams) || packageGrams <= 0 || packageGrams > 100000)) || normalizedAliases.length > 20 || normalizedAliases.some((value) => value.length > 80)) throw new Error('invalid_tobacco_catalog_item');
    const active = raw.active === undefined ? (current.active === undefined ? true : current.active) : raw.active;
    if (typeof active !== 'boolean') throw new Error('invalid_tobacco_catalog_item');
    return { brand, productLine, flavor, productType, packageGrams, strength: take('strength',80,true), country: take('country',80,true), leafType: take('leafType',100,true), barcode: take('barcode',64,true), aliases: normalizedAliases, description: take('description',1200), active };
  };
  if (pathname === '/api/tobacco-catalog' && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['inventory_read','inventory'])) return;
    if (requireOrganizationContext(req, res)) return;
    const status = ['active','archived','all'].includes(url.searchParams.get('status')) ? url.searchParams.get('status') : 'active';
    const scope = ['organization','venue'].includes(url.searchParams.get('scope')) ? url.searchParams.get('scope') : '';
    const query = String(url.searchParams.get('q') || '').trim().slice(0,120);
    if (repositories?.tobaccoCatalog) {
      try { return json(res,200,{ items: await repositories.tobaccoCatalog.list(tobaccoCatalogOrganizationId,tobaccoCatalogVenueId,{status,scope,query}) }); }
      catch (error) { return json(res,503,{error:'tobacco_catalog_unavailable',detail:error.message}); }
    }
    if (process.env.AUTH_REQUIRED === 'true') return json(res,503,{error:'tobacco_catalog_unavailable'});
    const normalizedQuery = query.toLocaleLowerCase('ru-RU');
    const items = tobaccoCatalogItems.filter((item) => item.organizationId === tobaccoCatalogOrganizationId && (item.scope === 'organization' || item.venueId === tobaccoCatalogVenueId) && (status === 'all' || (status === 'archived' ? !item.active : item.active)) && (!scope || item.scope === scope) && (!normalizedQuery || [item.brand,item.productLine,item.flavor,item.barcode,...item.aliases].join(' ').toLocaleLowerCase('ru-RU').includes(normalizedQuery))).sort((a,b) => `${a.brand} ${a.productLine || ''} ${a.flavor}`.localeCompare(`${b.brand} ${b.productLine || ''} ${b.flavor}`,'ru'));
    return json(res,200,{items});
  }
  if (pathname === '/api/tobacco-catalog' && req.method === 'POST') {
    if (denyUnless(req,res,'inventory')) return;
    if (requireOrganizationContext(req,res)) return;
    if (repositories?.pool && (!/^[0-9a-f-]{36}$/i.test(tobaccoCatalogVenueId) || !/^[0-9a-f-]{36}$/i.test(tobaccoCatalogOrganizationId))) return json(res,403,{error:'organization_context_required'});
    let input; try { input = await body(req); } catch (_) { return json(res,400,{error:'invalid_tobacco_catalog_item'}); }
    const scope = input.scope === 'organization' ? 'organization' : input.scope === 'venue' ? 'venue' : '';
    if (!scope) return json(res,400,{error:'invalid_tobacco_catalog_scope'});
    if (scope === 'organization' && !canManageVenueIdentity(req)) return json(res,403,{error:'tobacco_catalog_network_admin_required'});
    let item; try { item = normalizeTobaccoCatalogInput(input); } catch (_) { return json(res,400,{error:'invalid_tobacco_catalog_item'}); }
    if (repositories?.tobaccoCatalog) {
      try { const created = await repositories.tobaccoCatalog.create({ ...item,scope,organizationId:tobaccoCatalogOrganizationId,venueId:tobaccoCatalogVenueId,actorId:tobaccoCatalogActor }); recordAudit(req,'tobacco_catalog.created','tobacco_catalog_item',created.id,null,created); return json(res,201,created); }
      catch (error) { if (error.code === '23505') return json(res,409,{error:'tobacco_catalog_duplicate'}); if (error.message === 'tobacco_catalog_venue_not_found') return json(res,404,{error:error.message}); return json(res,503,{error:'tobacco_catalog_create_failed',detail:error.message}); }
    }
    if (process.env.AUTH_REQUIRED === 'true') return json(res,503,{error:'tobacco_catalog_unavailable'});
    const duplicate = tobaccoCatalogItems.some((entry) => entry.active && entry.scope === scope && entry.organizationId === tobaccoCatalogOrganizationId && (scope === 'organization' || entry.venueId === tobaccoCatalogVenueId) && entry.brand.toLocaleLowerCase('ru-RU') === item.brand.toLocaleLowerCase('ru-RU') && (entry.productLine || '').toLocaleLowerCase('ru-RU') === (item.productLine || '').toLocaleLowerCase('ru-RU') && entry.flavor.toLocaleLowerCase('ru-RU') === item.flavor.toLocaleLowerCase('ru-RU') && entry.productType === item.productType && Number(entry.packageGrams || 0) === Number(item.packageGrams || 0));
    if (duplicate) return json(res,409,{error:'tobacco_catalog_duplicate'});
    const created = {id:`tobacco-${Date.now()}-${Math.random().toString(16).slice(2,8)}`,organizationId:tobaccoCatalogOrganizationId,scope,venueId:scope === 'venue' ? tobaccoCatalogVenueId : null,...item,createdBy:tobaccoCatalogActor,updatedBy:tobaccoCatalogActor,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()}; tobaccoCatalogItems.push(created); recordAudit(req,'tobacco_catalog.created','tobacco_catalog_item',created.id,null,created); return json(res,201,created);
  }
  if (tobaccoCatalogPath && (req.method === 'GET' || req.method === 'PATCH')) {
    if (req.method === 'PATCH' && denyUnless(req,res,'inventory')) return;
    if (req.method === 'GET' && denyUnlessAny(req,res,['inventory_read','inventory'])) return;
    if (requireOrganizationContext(req,res)) return;
    const id = decodeURIComponent(tobaccoCatalogPath[1]);
    if (repositories?.tobaccoCatalog) {
      if (req.method === 'GET') { try { const item=await repositories.tobaccoCatalog.get(tobaccoCatalogOrganizationId,tobaccoCatalogVenueId,id); return item ? json(res,200,item) : json(res,404,{error:'tobacco_catalog_item_not_found'}); } catch (error) { return json(res,503,{error:'tobacco_catalog_unavailable',detail:error.message}); } }
      let raw; try { raw = await body(req); } catch (_) { return json(res,400,{error:'invalid_tobacco_catalog_item'}); }
      let current; try { current = await repositories.tobaccoCatalog.get(tobaccoCatalogOrganizationId,tobaccoCatalogVenueId,id); } catch (error) { return json(res,503,{error:'tobacco_catalog_unavailable',detail:error.message}); }
      if (!current) return json(res,404,{error:'tobacco_catalog_item_not_found'});
      if (current.scope === 'organization' && !canManageVenueIdentity(req)) return json(res,403,{error:'tobacco_catalog_network_admin_required'});
      let updated; try { updated = normalizeTobaccoCatalogInput(raw,current); } catch (_) { return json(res,400,{error:'invalid_tobacco_catalog_item'}); }
      try { const saved=await repositories.tobaccoCatalog.update(tobaccoCatalogOrganizationId,tobaccoCatalogVenueId,id,updated,tobaccoCatalogActor); if (!saved) return json(res,404,{error:'tobacco_catalog_item_not_found'}); recordAudit(req,updated.active ? 'tobacco_catalog.updated':'tobacco_catalog.archived','tobacco_catalog_item',id,current,saved); return json(res,200,saved); }
      catch (error) { return json(res,error.code === '23505' ? 409 : 503,{error:error.code === '23505' ? 'tobacco_catalog_duplicate':'tobacco_catalog_update_failed',detail:error.message}); }
    }
    if (process.env.AUTH_REQUIRED === 'true') return json(res,503,{error:'tobacco_catalog_unavailable'});
    const current=tobaccoCatalogItems.find((entry)=>entry.id===id&&entry.organizationId===tobaccoCatalogOrganizationId&&(entry.scope==='organization'||entry.venueId===tobaccoCatalogVenueId)); if (!current) return json(res,404,{error:'tobacco_catalog_item_not_found'});
    if (req.method === 'GET') return json(res,200,current);
    if (current.scope === 'organization' && !canManageVenueIdentity(req)) return json(res,403,{error:'tobacco_catalog_network_admin_required'});
    let raw; try { raw=await body(req); } catch (_) { return json(res,400,{error:'invalid_tobacco_catalog_item'}); }
    let updated; try { updated=normalizeTobaccoCatalogInput(raw,current); } catch (_) { return json(res,400,{error:'invalid_tobacco_catalog_item'}); }
    const duplicate=tobaccoCatalogItems.some((entry)=>entry.id!==id&&entry.active&&updated.active&&entry.scope===current.scope&&entry.organizationId===current.organizationId&&(current.scope==='organization'||entry.venueId===current.venueId)&&entry.brand.toLocaleLowerCase('ru-RU')===updated.brand.toLocaleLowerCase('ru-RU')&&(entry.productLine||'').toLocaleLowerCase('ru-RU')===(updated.productLine||'').toLocaleLowerCase('ru-RU')&&entry.flavor.toLocaleLowerCase('ru-RU')===updated.flavor.toLocaleLowerCase('ru-RU')&&entry.productType===updated.productType&&Number(entry.packageGrams||0)===Number(updated.packageGrams||0)); if (duplicate) return json(res,409,{error:'tobacco_catalog_duplicate'});
    Object.assign(current,updated,{updatedBy:tobaccoCatalogActor,updatedAt:new Date().toISOString()}); recordAudit(req,updated.active?'tobacco_catalog.updated':'tobacco_catalog.archived','tobacco_catalog_item',id,null,current); return json(res,200,current);
  }
  if (pathname === '/api/inventory/departments' && req.method === 'GET') {
    if (denyUnless(req, res, 'inventory_read')) return;
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query('SELECT code AS id,code,name,description,color,sort_order AS "sortOrder",is_active AS active FROM inventory_departments WHERE venue_id=$1 AND is_active=true ORDER BY sort_order,name', [venueDbId]); return json(res, 200, { items: rows }); } catch (_) {} }
    return json(res, 200, { items: [{ id: 'kitchen', code: 'kitchen', name: 'Кухня', description: 'Продукты, заготовки и блюда', color: 'coral', sortOrder: 10, active: true }, { id: 'bar', code: 'bar', name: 'Бар', description: 'Напитки, сиропы и чай', color: 'amber', sortOrder: 20, active: true }, { id: 'hookah', code: 'hookah', name: 'Кальяны', description: 'Табак, уголь и расходники', color: 'violet', sortOrder: 30, active: true }, { id: 'inventory', code: 'inventory', name: 'Хозяйственный склад', description: 'Расходники и инвентарь', color: 'green', sortOrder: 40, active: true }] });
  }
  if (pathname === '/api/inventory/departments' && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req); const name = String(input.name || '').trim(); const code = String(input.code || name).trim().toLocaleLowerCase('ru-RU').replace(/[^a-zа-яё0-9]+/gi, '-').replace(/^-|-$/g, '').slice(0, 48);
    if (!name || name.length > 80 || !code) return json(res, 400, { error: 'invalid_inventory_department' });
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query('INSERT INTO inventory_departments (venue_id,code,name,description,color,sort_order) VALUES ($1,$2,$3,$4,$5,$6) RETURNING code AS id,code,name,description,color,sort_order AS "sortOrder",is_active AS active', [venueDbId, code, name, String(input.description || '').trim().slice(0, 300), ['coral','amber','violet','green'].includes(input.color) ? input.color : 'coral', Number.isInteger(Number(input.sortOrder)) ? Number(input.sortOrder) : 50]); recordAudit(req, 'inventory.department_created', 'inventory_department', rows[0].id, null, rows[0]); return json(res, 201, rows[0]); } catch (error) { return json(res, 409, { error: error.code === '23505' ? 'inventory_department_exists' : 'inventory_department_create_failed' }); } }
    return json(res, 201, { id: code, code, name, description: String(input.description || '').trim().slice(0, 300), color: input.color || 'coral', sortOrder: 50, active: true });
  }
  const inventoryDepartmentPath = pathname.match(/^\/api\/inventory\/departments\/([^/]+)$/);
  if (inventoryDepartmentPath && req.method === 'PATCH') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req); const code = decodeURIComponent(inventoryDepartmentPath[1]); const name = String(input.name || '').trim(); if (!name || name.length > 80) return json(res, 400, { error: 'invalid_inventory_department' });
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query('UPDATE inventory_departments SET name=$1,description=$2,color=$3,sort_order=$4 WHERE venue_id=$5 AND code=$6 AND is_active=true RETURNING code AS id,code,name,description,color,sort_order AS "sortOrder",is_active AS active', [name, String(input.description || '').trim().slice(0, 300), ['coral','amber','violet','green'].includes(input.color) ? input.color : 'coral', Number.isInteger(Number(input.sortOrder)) ? Number(input.sortOrder) : 50, venueDbId, code]); if (!rows[0]) return json(res, 404, { error: 'inventory_department_not_found' }); recordAudit(req, 'inventory.department_updated', 'inventory_department', code, null, rows[0]); return json(res, 200, rows[0]); } catch (error) { return json(res, 409, { error: 'inventory_department_update_failed' }); } }
    return json(res, 200, { id: code, code, name, active: true });
  }
  if (inventoryDepartmentPath && req.method === 'DELETE') {
    if (denyUnless(req, res, 'inventory')) return;
    const code = decodeURIComponent(inventoryDepartmentPath[1]); if (repositories?.pool) { let client; try { client = await repositories.pool.connect(); await client.query('BEGIN'); const department = await client.query('SELECT 1 FROM inventory_departments WHERE venue_id=$1 AND code=$2 AND is_active=true FOR UPDATE', [venueDbId, code]); if (!department.rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'inventory_department_not_found' }); } const used = await client.query('SELECT EXISTS(SELECT 1 FROM product_categories WHERE venue_id=$1 AND department=$2 AND is_active=true) OR EXISTS(SELECT 1 FROM inventory_subdepartments WHERE venue_id=$1 AND department_code=$2 AND is_active=true) OR EXISTS(SELECT 1 FROM ingredients WHERE venue_id=$1 AND department=$2 AND is_marked=true) AS used', [venueDbId, code]); if (used.rows[0]?.used) { await client.query('ROLLBACK'); return json(res, 409, { error: 'inventory_department_in_use' }); } const { rows } = await client.query('UPDATE inventory_departments SET is_active=false WHERE venue_id=$1 AND code=$2 AND is_active=true RETURNING code AS id,code,name,is_active AS active', [venueDbId, code]); if (!rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'inventory_department_not_found' }); } await client.query('COMMIT'); recordAudit(req, 'inventory.department_archived', 'inventory_department', code, { active: true }, rows[0]); return json(res, 200, rows[0]); } catch (error) { await client?.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'inventory_department_archive_failed' }); } finally { client?.release(); } }
    return json(res, 200, { id: code, code, active: false });
  }
  if (pathname === '/api/product-categories' && req.method === 'GET') {
    if (denyUnless(req, res, 'inventory_read')) return;
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query('SELECT c.id,c.name,c.department,c.subdepartment_id AS "subdepartmentId",s.name AS "subdepartmentName",c.is_active AS active FROM product_categories c LEFT JOIN inventory_subdepartments s ON s.id=c.subdepartment_id AND s.venue_id=c.venue_id WHERE c.venue_id=$1 AND c.is_active=true ORDER BY c.department,s.name NULLS FIRST,c.name', [venueDbId]); return json(res, 200, { items: rows }); } catch (error) { return json(res, 503, { error: 'product_categories_unavailable', detail: error.message }); } }
    return json(res, 200, { items: productCategories.filter((item) => item.active).map((item) => ({ ...item, subdepartmentName: inventorySubdepartments.find((entry) => entry.id === item.subdepartmentId)?.name || null })) });
  }
  if (pathname === '/api/product-categories' && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req); const name = String(input.name || '').trim();
    if (!name || name.length > 80) return json(res, 400, { error: 'invalid_product_category' });
    const department = String(input.department || 'inventory').trim();
    if (!department || department.length > 48) return json(res, 400, { error: 'invalid_product_category_department' });
    const subdepartmentId = String(input.subdepartmentId || '').trim() || null;
    if (repositories?.pool && subdepartmentId && !/^[0-9a-f-]{36}$/i.test(subdepartmentId)) return json(res, 400, { error: 'invalid_product_category_subdepartment' });
    if (repositories?.pool) { let client; let checkingParent = true; try { client = await repositories.pool.connect(); await client.query('BEGIN'); const departmentResult = await client.query('SELECT 1 FROM inventory_departments WHERE venue_id=$1 AND code=$2 AND is_active=true FOR UPDATE', [venueDbId, department]); checkingParent = false; if (!departmentResult.rows[0]) { await client.query('ROLLBACK'); return json(res, 400, { error: 'inventory_department_not_found' }); } let subdepartmentName = null; if (subdepartmentId) { const subdepartment = await client.query('SELECT id,name FROM inventory_subdepartments WHERE venue_id=$1 AND department_code=$2 AND id=$3 AND is_active=true FOR UPDATE', [venueDbId, department, subdepartmentId]); if (!subdepartment.rows[0]) { await client.query('ROLLBACK'); return json(res, 400, { error: 'inventory_subdepartment_not_found' }); } subdepartmentName = subdepartment.rows[0].name; } const { rows } = await client.query('INSERT INTO product_categories (venue_id,name,department,subdepartment_id) VALUES ($1,$2,$3,$4) RETURNING id,name,department,subdepartment_id AS "subdepartmentId",is_active AS active', [venueDbId, name, department, subdepartmentId]); await client.query('COMMIT'); const category = { ...rows[0], subdepartmentName }; recordAudit(req, 'product_category.created', 'product_category', category.id, null, category); return json(res, 201, category); } catch (error) { await client?.query('ROLLBACK').catch(() => {}); if (checkingParent) return json(res, 503, { error: 'inventory_hierarchy_unavailable' }); return json(res, 409, { error: error.code === '23505' ? 'product_category_exists' : 'product_category_create_failed', detail: error.message }); } finally { client?.release(); } }
    if (!['kitchen','bar','hookah','inventory'].includes(department)) return json(res, 400, { error: 'inventory_department_not_found' });
    if (productCategories.some((item) => item.active && item.name.toLocaleLowerCase('ru-RU') === name.toLocaleLowerCase('ru-RU'))) return json(res, 409, { error: 'product_category_exists' });
    const subdepartment = subdepartmentId && inventorySubdepartments.find((item) => item.id === subdepartmentId && item.departmentCode === department && item.active !== false);
    if (subdepartmentId && !subdepartment) return json(res, 400, { error: 'inventory_subdepartment_not_found' });
    const category = { id: `product-category-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, name, department, subdepartmentId, subdepartmentName: subdepartment?.name || null, active: true };
    productCategories.push(category); recordAudit(req, 'product_category.created', 'product_category', category.id, null, category); return json(res, 201, category);
  }
  const productCategoryPath = pathname.match(/^\/api\/product-categories\/([^/]+)$/);
  if (productCategoryPath && req.method === 'PATCH') {
    if (denyUnless(req, res, 'inventory')) return;
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(productCategoryPath[1])) {
      const input = await body(req); const name = String(input.name || '').trim(); const department = String(input.department || 'inventory').trim(); const subdepartmentId = String(input.subdepartmentId || '').trim() || null;
      if (!name || name.length > 80) return json(res, 400, { error: 'invalid_product_category' });
      if (!department || department.length > 48) return json(res, 400, { error: 'invalid_product_category_department' });
      if (subdepartmentId && !/^[0-9a-f-]{36}$/i.test(subdepartmentId)) return json(res, 400, { error: 'invalid_product_category_subdepartment' });
      let client;
      let updated;
      let before;
      let checkingParent = true;
      try {
        client = await repositories.pool.connect();
        await client.query('BEGIN');
        const departmentResult = await client.query('SELECT 1 FROM inventory_departments WHERE venue_id=$1 AND code=$2 AND is_active=true FOR UPDATE', [venueDbId, department]);
        checkingParent = false;
        if (!departmentResult.rows[0]) { await client.query('ROLLBACK'); return json(res, 400, { error: 'inventory_department_not_found' }); }
        let subdepartmentName = null;
        if (subdepartmentId) { const subdepartment = await client.query('SELECT id,name FROM inventory_subdepartments WHERE venue_id=$1 AND department_code=$2 AND id=$3 AND is_active=true FOR UPDATE', [venueDbId, department, subdepartmentId]); if (!subdepartment.rows[0]) { await client.query('ROLLBACK'); return json(res, 400, { error: 'inventory_subdepartment_not_found' }); } subdepartmentName = subdepartment.rows[0].name; }
        const current = await client.query('SELECT id,name,department,subdepartment_id AS "subdepartmentId" FROM product_categories WHERE id=$1 AND venue_id=$2 AND is_active=true FOR UPDATE', [productCategoryPath[1], venueDbId]);
        before = current.rows[0];
        if (!before) { await client.query('ROLLBACK'); return json(res, 404, { error: 'product_category_not_found' }); }
        const result = await client.query('UPDATE product_categories SET name=$1,department=$2,subdepartment_id=$3 WHERE id=$4 AND venue_id=$5 AND is_active=true RETURNING id,name,department,subdepartment_id AS "subdepartmentId",is_active AS active', [name, department, subdepartmentId, productCategoryPath[1], venueDbId]);
        updated = result.rows[0];
        if (!updated) { await client.query('ROLLBACK'); return json(res, 404, { error: 'product_category_not_found' }); }
        if (before.name !== name || before.department !== department || String(before.subdepartmentId || '') !== String(subdepartmentId || '')) {
          await client.query(`UPDATE ingredients SET category=$1,department=$2,subdepartment=CASE WHEN $6::uuid IS NOT NULL THEN $7 WHEN $2<>$5 THEN '' ELSE subdepartment END WHERE venue_id=$3 AND category=$4 AND department=$5 AND is_marked=true`, [name, department, venueDbId, before.name, before.department, subdepartmentId, subdepartmentName]);
        }
        await client.query('COMMIT');
        updated.subdepartmentName = subdepartmentName;
      } catch (error) {
        if (client) await client.query('ROLLBACK').catch(() => {});
        if (checkingParent) return json(res, 503, { error: 'inventory_hierarchy_unavailable' });
        return json(res, 409, { error: error.code === '23505' ? 'product_category_exists' : 'product_category_update_failed', detail: error.message });
      } finally { client?.release(); }
      recordAudit(req, 'product_category.updated', 'product_category', updated.id, before, updated);
      return json(res, 200, updated);
    }
    const category = productCategories.find((item) => item.id === productCategoryPath[1]); if (!category) return json(res, 404, { error: 'product_category_not_found' });
    const input = await body(req); const name = String(input.name || '').trim();
    if (!name || name.length > 80) return json(res, 400, { error: 'invalid_product_category' });
    if (productCategories.some((item) => item.active && item.id !== category.id && item.name.toLocaleLowerCase('ru-RU') === name.toLocaleLowerCase('ru-RU'))) return json(res, 409, { error: 'product_category_exists' });
    const department = String(input.department || category.department || 'inventory').trim(); if (!['kitchen','bar','hookah','inventory'].includes(department)) return json(res, 400, { error: 'inventory_department_not_found' }); const subdepartmentId = String(input.subdepartmentId || '').trim() || null; const subdepartment = subdepartmentId && inventorySubdepartments.find((item) => item.id === subdepartmentId && item.departmentCode === department && item.active); if (subdepartmentId && !subdepartment) return json(res, 400, { error: 'inventory_subdepartment_not_found' }); const before = { ...category }; Object.assign(category, { name, department, subdepartmentId, subdepartmentName: subdepartment?.name || null }); recordAudit(req, 'product_category.updated', 'product_category', category.id, before, category); return json(res, 200, category);
  }
  if (productCategoryPath && req.method === 'DELETE') {
    if (denyUnless(req, res, 'inventory')) return;
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(productCategoryPath[1])) { try { const { rows } = await repositories.pool.query('UPDATE product_categories SET is_active=false WHERE id=$1 AND venue_id=$2 AND is_active=true RETURNING id,name,department,is_active AS active', [productCategoryPath[1], venueDbId]); if (!rows[0]) return json(res, 404, { error: 'product_category_not_found' }); recordAudit(req, 'product_category.deactivated', 'product_category', rows[0].id, { active: true }, rows[0]); return json(res, 200, rows[0]); } catch (error) { return json(res, 409, { error: 'product_category_delete_failed', detail: error.message }); } }
    const category = productCategories.find((item) => item.id === productCategoryPath[1]); if (!category) return json(res, 404, { error: 'product_category_not_found' });
    const before = { ...category }; category.active = false; recordAudit(req, 'product_category.deactivated', 'product_category', category.id, before, category); return json(res, 200, category);
  }
  if (pathname === '/api/products' && req.method === 'GET') {
    if (process.env.AUTH_REQUIRED === 'true' && !hasPermission(req, 'floor') && !hasPermission(req, 'inventory_read') && !hasPermission(req, 'inventory')) return json(res, 403, { error: 'forbidden', permission: 'floor' });
    if (repositories?.products) {
      try { return json(res, 200, { items: await repositories.products.list(venueDbId) }); }
      catch (_) { if (process.env.DATABASE_URL) return json(res, 503, { error: 'products_unavailable' }); }
    }
    if (process.env.DATABASE_URL) return json(res, 503, { error: 'products_unavailable' });
    return json(res, 200, { items: products });
  }
  if (pathname === '/api/recipes' && req.method === 'GET') {
    if (denyUnless(req, res, 'inventory_read')) return;
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query('SELECT id,product_id AS "productId",name,ingredients,technology,serve,yield_quantity AS "yieldQuantity",yield_unit AS "yieldUnit",portion_count AS "portionCount",recipe_type AS "recipeType",active,created_at AS "createdAt",updated_at AS "updatedAt" FROM inventory_recipe_cards WHERE venue_id=$1 AND active=true ORDER BY name', [venueDbId]); return json(res, 200, { items: rows.map(normalizeRecipeCard) }); } catch (error) { return json(res, 503, { error: 'recipes_unavailable', detail: error.message }); } }
    return json(res, 200, { items: recipes.map((recipe) => ({ ...recipe, yieldQuantity: recipe.yieldQuantity || 1, yieldUnit: recipe.yieldUnit || 'порция', portionCount: recipe.portionCount || 1 })) });
  }
  if (pathname === '/api/recipes' && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req); const name = String(input.name || '').trim();
    let ingredients;
    try { ingredients = await normalizeRecipeIngredients(input.ingredients, venueDbId); } catch (error) { return json(res, 400, { error: error.code || 'invalid_recipe_ingredients', ingredient: error.ingredient, sourceUnit: error.sourceUnit, targetUnit: error.targetUnit }); }
    if (!ingredients) return json(res, 503, { error: 'recipe_ingredients_unavailable' });
    let output; try { output = normalizeRecipeOutput(input); } catch (error) { return json(res, 400, { error: error.code || 'invalid_recipe_output', targetUnit: error.targetUnit }); }
    const technology = String(input.technology || '').trim(); const serve = String(input.serve || '').trim(); const recipeType = ['sale','premix'].includes(String(input.recipeType || 'sale')) ? String(input.recipeType || 'sale') : 'sale';
    const requestedProductId = input.productId === undefined || input.productId === null ? null : String(input.productId).trim() || null;
    if (!name || name.length > 120 || technology.length > 4000 || serve.length > 1000) return json(res, 400, { error: 'invalid_recipe' });
    if (recipeType === 'premix' && requestedProductId) return json(res, 400, { error: 'premix_product_binding_not_allowed' });
    if (requestedProductId && repositories?.pool && !/^[0-9a-f-]{36}$/i.test(requestedProductId)) return json(res, 400, { error: 'recipe_product_invalid' });
    if (requestedProductId && !repositories?.pool && !products.some((item) => item.id === requestedProductId)) return json(res, 400, { error: 'recipe_product_not_found' });
    if (requestedProductId && !repositories?.pool && recipeType === 'sale') {
      const targetProduct = products.find((item) => item.id === requestedProductId);
      if (targetProduct?.inventoryMode === 'non_stock') return json(res, 409, { error: 'non_stock_product_has_recipe' });
      if (recipes.some((item) => item.active !== false && item.recipeType !== 'premix' && String(item.productId || '') === requestedProductId)) return json(res, 409, { error: 'product_recipe_ambiguous' });
    }
    if (requestedProductId && repositories?.pool) { const product = await repositories.pool.query('SELECT id FROM products WHERE id=$1 AND venue_id=$2', [requestedProductId, venueDbId]); if (!product.rows[0]) return json(res, 400, { error: 'recipe_product_not_found' }); }

    if (repositories?.pool) {
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        if (requestedProductId && recipeType === 'sale') {
          const product = await client.query('SELECT id,inventory_mode AS "inventoryMode" FROM products WHERE id=$1 AND venue_id=$2 AND is_active=true FOR UPDATE', [requestedProductId, venueDbId]);
          if (!product.rows[0]) { await client.query('ROLLBACK'); return json(res, 400, { error: 'recipe_product_not_found' }); }
          if (product.rows[0].inventoryMode === 'non_stock') { await client.query('ROLLBACK'); return json(res, 409, { error: 'non_stock_product_has_recipe' }); }
          const duplicate = await client.query("SELECT 1 FROM inventory_recipe_cards WHERE venue_id=$1 AND product_id=$2 AND active=true AND recipe_type='sale' LIMIT 1", [venueDbId, requestedProductId]);
          if (duplicate.rowCount) { await client.query('ROLLBACK'); return json(res, 409, { error: 'product_recipe_ambiguous' }); }
        } else if (requestedProductId) {
          const product = await client.query('SELECT id FROM products WHERE id=$1 AND venue_id=$2 AND is_active=true FOR UPDATE', [requestedProductId, venueDbId]);
          if (!product.rows[0]) { await client.query('ROLLBACK'); return json(res, 400, { error: 'recipe_product_not_found' }); }
        }
        const { rows } = await client.query('INSERT INTO inventory_recipe_cards (venue_id,product_id,name,ingredients,technology,serve,yield_quantity,yield_unit,portion_count,recipe_type) VALUES ($1,$2,$3,$4::jsonb,$5,$6,$7,$8,$9,$10) RETURNING id,product_id AS "productId",name,ingredients,technology,serve,yield_quantity AS "yieldQuantity",yield_unit AS "yieldUnit",portion_count AS "portionCount",recipe_type AS "recipeType",active,created_at AS "createdAt",updated_at AS "updatedAt"', [venueDbId, requestedProductId, name, JSON.stringify(ingredients), technology || null, serve || null, output.yieldQuantity, output.yieldUnit, output.portionCount, recipeType]);
        await client.query('COMMIT');
        const recipe = normalizeRecipeCard(rows[0]);
        recordAudit(req, 'recipe.created', 'recipe', recipe.id, null, recipe);
        return json(res, 201, recipe);
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'recipe_save_failed', detail: error.message }); }
      finally { client.release(); }
    }
    const recipe = { id: 'recipe-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7), productId: requestedProductId, name, ingredients, technology, serve, recipeType, ...output }; recipes.push(recipe); recordAudit(req, 'recipe.created', 'recipe', recipe.id, null, recipe); return json(res, 201, recipe);
  }
  const recipeProfile = pathname.match(/^\/api\/recipes\/([^/]+)$/);
  if (recipeProfile && req.method === 'PATCH') {
    if (denyUnless(req, res, 'inventory')) return;

    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(recipeProfile[1])) {
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        const input = await body(req);
        const existingResult = await client.query('SELECT product_id AS "productId",recipe_type AS "recipeType",yield_quantity AS "yieldQuantity",yield_unit AS "yieldUnit",portion_count AS "portionCount" FROM inventory_recipe_cards WHERE id=$1 AND venue_id=$2 AND active=true FOR UPDATE', [recipeProfile[1], venueDbId]);
        const existing = existingResult.rows[0];
        if (!existing) { await client.query('ROLLBACK'); return json(res, 404, { error: 'recipe_not_found' }); }
        const nextType = input.recipeType === undefined ? existing.recipeType : (['sale','premix'].includes(String(input.recipeType)) ? String(input.recipeType) : null);
        if (!nextType) { await client.query('ROLLBACK'); return json(res, 400, { error: 'invalid_recipe_type' }); }
        const nextProductId = input.productId === undefined ? existing.productId : (input.productId === null ? null : String(input.productId).trim() || null);
        if (nextType === 'premix' && nextProductId) { await client.query('ROLLBACK'); return json(res, 400, { error: 'premix_product_binding_not_allowed' }); }
        if (nextProductId && !/^[0-9a-f-]{36}$/i.test(nextProductId)) { await client.query('ROLLBACK'); return json(res, 400, { error: 'recipe_product_invalid' }); }
        if (nextProductId && nextType === 'sale') {
          const product = await client.query('SELECT id,inventory_mode AS "inventoryMode" FROM products WHERE id=$1 AND venue_id=$2 AND is_active=true FOR UPDATE', [nextProductId, venueDbId]);
          if (!product.rows[0]) { await client.query('ROLLBACK'); return json(res, 400, { error: 'recipe_product_not_found' }); }
          if (product.rows[0].inventoryMode === 'non_stock') { await client.query('ROLLBACK'); return json(res, 409, { error: 'non_stock_product_has_recipe' }); }
          const duplicate = await client.query("SELECT 1 FROM inventory_recipe_cards WHERE venue_id=$1 AND product_id=$2 AND active=true AND recipe_type='sale' AND id<>$3 LIMIT 1", [venueDbId, nextProductId, recipeProfile[1]]);
          if (duplicate.rowCount) { await client.query('ROLLBACK'); return json(res, 409, { error: 'product_recipe_ambiguous' }); }
        } else if (nextProductId) {
          const product = await client.query('SELECT id FROM products WHERE id=$1 AND venue_id=$2 AND is_active=true FOR UPDATE', [nextProductId, venueDbId]);
          if (!product.rows[0]) { await client.query('ROLLBACK'); return json(res, 400, { error: 'recipe_product_not_found' }); }
        }
        if (input.ingredients !== undefined) {
          if (!Array.isArray(input.ingredients) || !input.ingredients.length) { await client.query('ROLLBACK'); return json(res, 400, { error: 'invalid_recipe' }); }
          try { input.ingredients = await normalizeRecipeIngredients(input.ingredients, venueDbId); }
          catch (error) { await client.query('ROLLBACK'); return json(res, 400, { error: error.code || 'invalid_recipe_ingredients', ingredient: error.ingredient, sourceUnit: error.sourceUnit, targetUnit: error.targetUnit }); }
          if (!input.ingredients) { await client.query('ROLLBACK'); return json(res, 503, { error: 'recipe_ingredients_unavailable' }); }
        }
        let output = null;
        if (input.yieldQuantity !== undefined || input.yieldUnit !== undefined || input.portionCount !== undefined || input.yield !== undefined || input.portions !== undefined) {
          try { output = normalizeRecipeOutput(input, existing); }
          catch (error) { await client.query('ROLLBACK'); return json(res, 400, { error: error.code || 'invalid_recipe_output', targetUnit: error.targetUnit }); }
        }
        const fields = []; const values = [recipeProfile[1], venueDbId];
        if (input.productId !== undefined) { values.push(nextProductId); fields.push(`product_id=$${values.length}`); }
        if (input.name !== undefined) { const name = String(input.name || '').trim(); if (!name || name.length > 120) { await client.query('ROLLBACK'); return json(res, 400, { error: 'invalid_recipe' }); } values.push(name); fields.push(`name=$${values.length}`); }
        if (input.ingredients !== undefined) { values.push(JSON.stringify(input.ingredients.slice(0, 50))); fields.push(`ingredients=$${values.length}::jsonb`); }
        if (input.technology !== undefined) { const technology = String(input.technology || '').trim(); if (technology.length > 4000) { await client.query('ROLLBACK'); return json(res, 400, { error: 'invalid_recipe' }); } values.push(technology || null); fields.push(`technology=$${values.length}`); }
        if (input.serve !== undefined) { const serve = String(input.serve || '').trim(); if (serve.length > 1000) { await client.query('ROLLBACK'); return json(res, 400, { error: 'invalid_recipe' }); } values.push(serve || null); fields.push(`serve=$${values.length}`); }
        if (output) { values.push(output.yieldQuantity, output.yieldUnit, output.portionCount); fields.push(`yield_quantity=$${values.length - 2}`, `yield_unit=$${values.length - 1}`, `portion_count=$${values.length}`); }
        if (input.recipeType !== undefined) { values.push(nextType); fields.push(`recipe_type=$${values.length}`); }
        if (!fields.length) { await client.query('ROLLBACK'); return json(res, 400, { error: 'invalid_recipe' }); }
        fields.push('updated_at=now()');
        const { rows } = await client.query(`UPDATE inventory_recipe_cards SET ${fields.join(',')} WHERE id=$1 AND venue_id=$2 AND active=true RETURNING id,product_id AS "productId",name,ingredients,technology,serve,yield_quantity AS "yieldQuantity",yield_unit AS "yieldUnit",portion_count AS "portionCount",recipe_type AS "recipeType",active,created_at AS "createdAt",updated_at AS "updatedAt"`, values);
        if (!rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'recipe_not_found' }); }
        await client.query('COMMIT');
        const updated = normalizeRecipeCard(rows[0]); recordAudit(req, 'recipe.updated', 'recipe', updated.id, null, updated); return json(res, 200, updated);
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'recipe_save_failed', detail: error.message }); }
      finally { client.release(); }
    }
    const storedRecipe = recipes.find((item) => item.id === recipeProfile[1]); const recipe = storedRecipe && { ...storedRecipe }; if (!recipe) return json(res, 404, { error: 'recipe_not_found' });
    const input = await body(req); const before = { ...recipe };
    if (input.productId !== undefined) { const productId = input.productId === null ? null : String(input.productId).trim() || null; if (productId && repositories?.pool && !/^[0-9a-f-]{36}$/i.test(productId)) return json(res, 400, { error: 'recipe_product_invalid' }); if (productId && !repositories?.pool && !products.some((item) => item.id === productId)) return json(res, 400, { error: 'recipe_product_not_found' }); recipe.productId = productId; }
    if (input.name !== undefined) { const name = String(input.name || '').trim(); if (!name || name.length > 120) return json(res, 400, { error: 'invalid_recipe' }); recipe.name = name; }
    if (input.ingredients !== undefined) { if (!Array.isArray(input.ingredients)) return json(res, 400, { error: 'invalid_recipe' }); try { recipe.ingredients = await normalizeRecipeIngredients(input.ingredients, venueDbId); } catch (error) { return json(res, 400, { error: error.code || 'invalid_recipe_ingredients', ingredient: error.ingredient, sourceUnit: error.sourceUnit, targetUnit: error.targetUnit }); } if (!recipe.ingredients) return json(res, 503, { error: 'recipe_ingredients_unavailable' }); }
    if (input.technology !== undefined) { recipe.technology = String(input.technology || '').trim(); if (recipe.technology.length > 4000) return json(res, 400, { error: 'invalid_recipe' }); }
    if (input.serve !== undefined) { recipe.serve = String(input.serve || '').trim(); if (recipe.serve.length > 1000) return json(res, 400, { error: 'invalid_recipe' }); } if (input.recipeType !== undefined) { if (!['sale','premix'].includes(String(input.recipeType))) return json(res, 400, { error: 'invalid_recipe_type' }); recipe.recipeType = String(input.recipeType); }
    if (recipe.recipeType === 'premix' && recipe.productId) return json(res, 400, { error: 'premix_product_binding_not_allowed' });
    if (input.yieldQuantity !== undefined || input.yieldUnit !== undefined || input.portionCount !== undefined || input.yield !== undefined || input.portions !== undefined) { try { Object.assign(recipe, normalizeRecipeOutput(input, { yieldQuantity: recipe.yieldQuantity || 1, yieldUnit: recipe.yieldUnit || 'порция', portionCount: recipe.portionCount || 1 })); } catch (error) { return json(res, 400, { error: error.code || 'invalid_recipe_output', targetUnit: error.targetUnit }); } }
    if (recipe.productId && recipe.recipeType !== 'premix') { const targetProduct = products.find((item) => item.id === recipe.productId); if (!targetProduct) return json(res, 400, { error: 'recipe_product_not_found' }); if (targetProduct.inventoryMode === 'non_stock') return json(res, 409, { error: 'non_stock_product_has_recipe' }); if (recipes.some((item) => item.id !== recipe.id && item.active !== false && item.recipeType !== 'premix' && String(item.productId || '') === String(recipe.productId))) return json(res, 409, { error: 'product_recipe_ambiguous' }); }
    Object.assign(storedRecipe, recipe); recordAudit(req, 'recipe.updated', 'recipe', recipe.id, before, recipe); return json(res, 200, recipe);
  }
  if (recipeProfile && req.method === 'DELETE') {
    if (denyUnless(req, res, 'inventory')) return;
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(recipeProfile[1])) { try { const { rows } = await repositories.pool.query('UPDATE inventory_recipe_cards SET active=false,updated_at=now() WHERE id=$1 AND venue_id=$2 AND active=true RETURNING id,name,active', [recipeProfile[1], venueDbId]); if (!rows[0]) return json(res, 404, { error: 'recipe_not_found' }); recordAudit(req, 'recipe.archived', 'recipe', rows[0].id, { active: true }, rows[0]); return json(res, 200, rows[0]); } catch (error) { return json(res, 409, { error: 'recipe_delete_failed', detail: error.message }); } }
    const index = recipes.findIndex((item) => item.id === recipeProfile[1]); if (index < 0) return json(res, 404, { error: 'recipe_not_found' });
    const recipe = recipes.splice(index, 1)[0]; recordAudit(req, 'recipe.deleted', 'recipe', recipe.id, recipe, null); return json(res, 200, recipe);
  }
  if (pathname === '/api/products' && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req); const name = String(input.name || '').trim(); const category = String(input.category || input.station || '').trim(); const price = Number(input.price); const inventoryMode = String(input.inventoryMode || 'tracked');
    const aliases = Array.isArray(input.aliases) ? input.aliases.map(String).map((item) => item.trim()).filter(Boolean).slice(0, 30) : [];
    if (!name || name.length > 120 || !category || category.length > 80 || !Number.isFinite(price) || price < 0 || price > 10000000 || !['tracked','non_stock'].includes(inventoryMode)) return json(res, 400, { error: 'invalid_product' });
    if (input.imageUrl && (!/^data:image\/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/.test(String(input.imageUrl)) || String(input.imageUrl).length > 1500000)) return json(res, 400, { error: 'invalid_image' });
    if (repositories?.products) { try { const product = await repositories.products.create({ venueId: venueDbId, name, category, price, aliases, imageUrl: input.imageUrl, inventoryMode }); recordAudit(req, 'product.created', 'product', product.id, null, product); return json(res, 201, product); } catch (error) { return json(res, 409, { error: 'product_create_failed', detail: error.message }); } }
    const product = { id: `product-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, name, category, station: category, price, aliases, imageUrl: input.imageUrl || null, inventoryMode };
    products.push(product); recordAudit(req, 'product.created', 'product', product.id, null, product); return json(res, 201, product);
  }
  const productProfile = pathname.match(/^\/api\/products\/([^/]+)$/);
  if (productProfile && req.method === 'PATCH') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req); const name = input.name === undefined ? undefined : String(input.name || '').trim(); const category = input.category === undefined && input.station === undefined ? undefined : String(input.category ?? input.station ?? '').trim(); const price = input.price === undefined ? undefined : Number(input.price); const inventoryMode = input.inventoryMode === undefined ? undefined : String(input.inventoryMode);
    const aliases = input.aliases === undefined ? undefined : (Array.isArray(input.aliases) ? input.aliases.map(String).map((item) => item.trim()).filter(Boolean).slice(0, 30) : null);
    if (name !== undefined && (!name || name.length > 120) || category !== undefined && (!category || category.length > 80) || price !== undefined && (!Number.isFinite(price) || price < 0 || price > 10000000) || aliases === null || inventoryMode !== undefined && !['tracked','non_stock','needs_review'].includes(inventoryMode)) return json(res, 400, { error: 'invalid_product' });
    if (input.imageUrl !== undefined && input.imageUrl && (!/^data:image\/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/.test(String(input.imageUrl)) || String(input.imageUrl).length > 1500000)) return json(res, 400, { error: 'invalid_image' });
    if (repositories?.products) {
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        const { rows } = await client.query('SELECT id,name,category,sale_price AS price,search_aliases AS aliases,image_url AS "imageUrl",inventory_mode AS "inventoryMode" FROM products WHERE id=$1 AND venue_id=$2 AND is_active=true FOR UPDATE', [productProfile[1], venueDbId]);
        const before = rows[0] && { ...rows[0], price: Number(rows[0].price), aliases: rows[0].aliases || [] };
        if (!before) { await client.query('ROLLBACK'); return json(res, 404, { error: 'product_not_found' }); }
        if (inventoryMode === 'non_stock') {
          const recipe = await client.query(`SELECT 1 FROM inventory_recipe_cards c WHERE c.venue_id=$1 AND c.active=true AND c.recipe_type='sale' AND (c.product_id=$2 OR (c.product_id IS NULL AND lower(btrim(c.name))=lower(btrim($3)))) UNION ALL SELECT 1 FROM recipes r JOIN recipe_items ri ON ri.product_id=r.product_id JOIN ingredients i ON i.id=ri.ingredient_id AND i.venue_id=$1 WHERE r.product_id=$2 AND ri.quantity>0 LIMIT 1`, [venueDbId, productProfile[1], name || before.name]);
          if (recipe.rowCount) { await client.query('ROLLBACK'); return json(res, 409, { error: 'non_stock_product_has_recipe' }); }
          const openOrder = await client.query("SELECT 1 FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.venue_id=$1 AND oi.product_id=$2 AND o.status IN ('open','in_progress','ready') LIMIT 1", [venueDbId, productProfile[1]]);
          if (openOrder.rowCount) { await client.query('ROLLBACK'); return json(res, 409, { error: 'product_has_open_orders' }); }
        }
        const product = await repositories.products.update(venueDbId, productProfile[1], { name, category, price, aliases, imageUrl: input.imageUrl, inventoryMode }, client);
        await client.query('COMMIT');
        recordAudit(req, 'product.updated', 'product', product.id, before, product);
        return json(res, 200, product);
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'product_update_failed', detail: error.message }); }
      finally { client.release(); }
    }
    const product = products.find((entry) => entry.id === productProfile[1]); if (!product) return json(res, 404, { error: 'product_not_found' }); if (inventoryMode === 'non_stock') { const nextName = name || product.name; if (recipes.some((recipe) => recipe.active !== false && recipe.recipeType !== 'premix' && (recipe.productId === product.id || (!recipe.productId && String(recipe.name || '').toLocaleLowerCase('ru-RU') === String(nextName).toLocaleLowerCase('ru-RU'))))) return json(res, 409, { error: 'non_stock_product_has_recipe' }); if (orders.some((order) => ['open','in_progress','ready'].includes(order.status) && (order.items || []).some((item) => item.productId === product.id))) return json(res, 409, { error: 'product_has_open_orders' }); } const before = { ...product }; if (name !== undefined) product.name = name; if (category !== undefined) { product.category = category; product.station = category; } if (price !== undefined) product.price = price; if (aliases !== undefined) product.aliases = aliases; if (inventoryMode !== undefined) product.inventoryMode = inventoryMode; if (input.imageUrl !== undefined) product.imageUrl = input.imageUrl || null; recordAudit(req, 'product.updated', 'product', product.id, before, product); return json(res, 200, product);
  }
  if (productProfile && req.method === 'DELETE') {
    if (denyUnless(req, res, 'inventory')) return;
    if (repositories?.products) { try { const product = await repositories.products.deactivate(venueDbId, productProfile[1]); if (!product) return json(res, 404, { error: 'product_not_found' }); recordAudit(req, 'product.deactivated', 'product', product.id, { active: true }, { active: false }); return json(res, 200, { ...product, active: false }); } catch (error) { return json(res, 409, { error: 'product_delete_failed', detail: error.message }); } }
    const index = products.findIndex((entry) => entry.id === productProfile[1]); if (index < 0) return json(res, 404, { error: 'product_not_found' }); const [product] = products.splice(index, 1); recordAudit(req, 'product.deactivated', 'product', product.id, { active: true }, { active: false }); return json(res, 200, { ...product, active: false });
  }
  if (pathname === '/api/discount-groups' && req.method === 'GET') {
    if (process.env.AUTH_REQUIRED === 'true' && !hasPermission(req, 'staff') && !hasPermission(req, 'staff_view') && !hasPermission(req, 'staff_manage') && !hasPermission(req, 'finance') && !hasPermission(req, 'orders') && !hasPermission(req, 'loyalty')) return json(res, 403, { error: 'forbidden', permission: 'loyalty' });
    const includeArchived = url.searchParams.get('includeArchived') === 'true';
    if (includeArchived && process.env.AUTH_REQUIRED === 'true' && !hasPermission(req, 'staff_manage') && !hasPermission(req, 'finance') && !hasPermission(req, 'loyalty')) return json(res, 403, { error: 'forbidden', permission: 'loyalty' });
    if (repositories?.pool) {
      try {
        const { rows } = await repositories.pool.query(`SELECT id,name,discount_percent AS "discountPercent",bonus_percent AS "bonusPercent",deposit_min AS "depositMin",active FROM guest_discount_groups WHERE venue_id=$1 AND ($2::boolean OR active=true) ORDER BY active DESC,lower(name),id`, [venueDbId, includeArchived]);
        return json(res, 200, { items: rows.map((row) => ({ ...row, discountPercent: Number(row.discountPercent), bonusPercent: Number(row.bonusPercent), depositMin: Number(row.depositMin) })) });
      } catch (error) { return json(res, 503, { error: 'discount_groups_unavailable', detail: error.message }); }
    }
    return json(res, 200, { items: discountGroups.filter((group) => group.venueId === currentVenueId && (includeArchived || group.active !== false)) });
  }
  if (pathname === '/api/discount-groups' && req.method === 'POST') {
    if (denyUnlessAny(req, res, ['staff_manage', 'finance', 'loyalty'])) return;
    const input = await body(req); const name = String(input.name || '').trim(); const discountPercent = Number(input.discountPercent ?? 0); const bonusPercent = Number(input.bonusPercent ?? 0); const depositMin = Number(input.depositMin ?? 0);
    if (!name || name.length > 80 || ![discountPercent, bonusPercent, depositMin].every(Number.isFinite) || discountPercent < 0 || discountPercent > 100 || bonusPercent < 0 || bonusPercent > 100 || depositMin < 0 || depositMin > 9999999999.99 || Math.abs(depositMin * 100 - Math.round(depositMin * 100)) > 1e-6) return json(res, 400, { error: 'invalid_discount_group' });
    if (repositories?.pool) {
      try { const { rows } = await repositories.pool.query(`INSERT INTO guest_discount_groups (venue_id,name,discount_percent,bonus_percent,deposit_min) VALUES ($1,$2,$3,$4,$5) RETURNING id,name,discount_percent AS "discountPercent",bonus_percent AS "bonusPercent",deposit_min AS "depositMin",active`, [venueDbId, name, discountPercent, bonusPercent, depositMin]); const group = { ...rows[0], discountPercent: Number(rows[0].discountPercent), bonusPercent: Number(rows[0].bonusPercent), depositMin: Number(rows[0].depositMin) }; recordAudit(req, 'discount_group.created', 'discount_group', group.id, null, group); return json(res, 201, group); }
      catch (error) { return json(res, error.code === '23505' ? 409 : 503, { error: error.code === '23505' ? 'discount_group_name_exists' : 'discount_group_save_failed', detail: error.message }); }
    }
    if (discountGroups.some((group) => group.venueId === currentVenueId && group.name.toLocaleLowerCase('ru-RU') === name.toLocaleLowerCase('ru-RU'))) return json(res, 409, { error: 'discount_group_name_exists' });
    const group = { id: `discount-group-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`, venueId: currentVenueId, name, discountPercent, bonusPercent, depositMin, active: true };
    discountGroups.push(group); recordAudit(req, 'discount_group.created', 'discount_group', group.id, null, group); return json(res, 201, group);
  }
  const discountGroupProfile = pathname.match(/^\/api\/discount-groups\/([^/]+)$/);
  if (discountGroupProfile && req.method === 'PATCH') {
    if (denyUnlessAny(req, res, ['staff_manage', 'finance', 'loyalty'])) return;
    const input = await body(req);
    const name = input.name === undefined ? undefined : String(input.name || '').trim();
    const discountPercent = input.discountPercent === undefined ? undefined : Number(input.discountPercent);
    const bonusPercent = input.bonusPercent === undefined ? undefined : Number(input.bonusPercent);
    const depositMin = input.depositMin === undefined ? undefined : Number(input.depositMin);
    const active = input.active === undefined ? undefined : input.active;
    if (active !== undefined && typeof active !== 'boolean') return json(res, 400, { error: 'invalid_discount_group' });
    if (name !== undefined && (!name || name.length > 80) || [discountPercent, bonusPercent, depositMin].some((value) => value !== undefined && !Number.isFinite(value)) || discountPercent !== undefined && (discountPercent < 0 || discountPercent > 100) || bonusPercent !== undefined && (bonusPercent < 0 || bonusPercent > 100) || depositMin !== undefined && (depositMin < 0 || depositMin > 9999999999.99 || Math.abs(depositMin * 100 - Math.round(depositMin * 100)) > 1e-6)) return json(res, 400, { error: 'invalid_discount_group' });
    if (repositories?.pool) {
      if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(discountGroupProfile[1])) return json(res, 404, { error: 'discount_group_not_found' });
      const fields = []; const values = [discountGroupProfile[1], venueDbId];
      if (name !== undefined) { values.push(name); fields.push(`name=$${values.length}`); }
      if (discountPercent !== undefined) { values.push(discountPercent); fields.push(`discount_percent=$${values.length}`); }
      if (bonusPercent !== undefined) { values.push(bonusPercent); fields.push(`bonus_percent=$${values.length}`); }
      if (depositMin !== undefined) { values.push(depositMin); fields.push(`deposit_min=$${values.length}`); }
      if (active !== undefined) { values.push(active); fields.push(`active=$${values.length}`); }
      if (!fields.length) return json(res, 400, { error: 'invalid_discount_group' });
      fields.push('updated_at=now()');
      try { const { rows } = await repositories.pool.query(`UPDATE guest_discount_groups SET ${fields.join(',')} WHERE id=$1 AND venue_id=$2 RETURNING id,name,discount_percent AS "discountPercent",bonus_percent AS "bonusPercent",deposit_min AS "depositMin",active`, values); if (!rows[0]) return json(res, 404, { error: 'discount_group_not_found' }); const group = { ...rows[0], discountPercent: Number(rows[0].discountPercent), bonusPercent: Number(rows[0].bonusPercent), depositMin: Number(rows[0].depositMin) }; recordAudit(req, active === undefined ? 'discount_group.updated' : active ? 'discount_group.restored' : 'discount_group.archived', 'discount_group', group.id, null, group); return json(res, 200, group); }
      catch (error) { return json(res, error.code === '23505' ? 409 : 503, { error: error.code === '23505' ? 'discount_group_name_exists' : 'discount_group_save_failed', detail: error.message }); }
    }
    const group = discountGroups.find((entry) => entry.id === discountGroupProfile[1] && entry.venueId === currentVenueId); if (!group) return json(res, 404, { error: 'discount_group_not_found' });
    if (name !== undefined && discountGroups.some((entry) => entry.venueId === currentVenueId && entry.id !== group.id && entry.name.toLocaleLowerCase('ru-RU') === name.toLocaleLowerCase('ru-RU'))) return json(res, 409, { error: 'discount_group_name_exists' });
    const before = { ...group };
    if (name !== undefined) group.name = name; if (discountPercent !== undefined) group.discountPercent = discountPercent; if (bonusPercent !== undefined) group.bonusPercent = bonusPercent; if (depositMin !== undefined) group.depositMin = depositMin; if (active !== undefined) group.active = active;
    recordAudit(req, active === undefined ? 'discount_group.updated' : active ? 'discount_group.restored' : 'discount_group.archived', 'discount_group', group.id, before, group); return json(res, 200, group);
  }
  if (pathname === '/api/clients' && req.method === 'GET') {
    if (process.env.AUTH_REQUIRED === 'true' && !hasPermission(req, 'staff') && !hasPermission(req, 'staff_view') && !hasPermission(req, 'orders')) return json(res, 403, { error: 'forbidden', permission: 'clients' });
    const query = String(url.searchParams.get('q') || '').trim().toLowerCase();
    const requestedGuestDays = Number(url.searchParams.get('days') || 30);
    const guestDays = Number.isFinite(requestedGuestDays) ? Math.min(365, Math.max(1, Math.round(requestedGuestDays))) : 30;
    const guestPeriodFrom = new Date(Date.now() - guestDays * 86400000).toISOString();
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query(`SELECT g.id,g.full_name AS name,g.nickname,g.phone,g.email,g.avatar_url AS "avatarUrl",g.guest_status AS "guestStatus",g.archived_at AS "archivedAt",g.phone_numbers AS "phoneNumbers",g.telegram,g.tobacco_preferences AS "tobaccoPreferences",g.bowl_preferences AS "bowlPreferences",g.bar_preferences AS "barPreferences",g.allergies,g.loyalty_points AS "loyaltyPoints",g.discount_group_id AS "discountGroupId",g.deposit_balance AS "depositBalance",dg.name AS "discountGroupName",dg.discount_percent AS "discountPercent",g.notes,COUNT(DISTINCT o.id)::int AS visits,COALESCE(SUM(p.amount),0)::numeric AS "totalSpent",MAX(o.closed_at) AS "lastVisitAt" FROM guests g LEFT JOIN guest_discount_groups dg ON dg.id=g.discount_group_id AND dg.venue_id=g.venue_id LEFT JOIN orders o ON o.guest_id=g.id AND o.status='closed' AND o.closed_at >= $3::timestamptz LEFT JOIN payments p ON p.order_id=o.id AND p.status IN ('paid','partially_paid') WHERE g.venue_id=$1 AND g.archived_at IS NULL AND ($2='' OR LOWER(CONCAT_WS(' ',g.full_name,g.nickname,g.phone,g.telegram,g.phone_numbers::text,ARRAY_TO_STRING(COALESCE(g.tobacco_preferences,'{}'),' '),ARRAY_TO_STRING(COALESCE(g.bowl_preferences,'{}'),' '),ARRAY_TO_STRING(COALESCE(g.bar_preferences,'{}'),' '),g.allergies,g.notes)) LIKE '%'||LOWER($2)||'%') GROUP BY g.id,dg.name,dg.discount_percent ORDER BY COALESCE(MAX(o.closed_at),g.created_at) DESC`, [venueDbId, query, guestPeriodFrom]); return json(res, 200, { items: rows.map((row) => ({ ...row, phoneNumbers: row.phoneNumbers || (row.phone ? [{ label: 'Основной', number: row.phone, primary: true }] : []), tobaccoPreferences: row.tobaccoPreferences || [], bowlPreferences: row.bowlPreferences || [], barPreferences: row.barPreferences || [], loyaltyPoints: Number(row.loyaltyPoints || 0), bonusBalance: Number(row.loyaltyPoints || 0), depositBalance: Number(row.depositBalance || 0), discountPercent: Number(row.discountPercent || 0), visits: Number(row.visits || 0), totalSpent: Number(row.totalSpent || 0) })), periodDays: guestDays, periodFrom: guestPeriodFrom }); } catch (error) { return json(res, 503, { error: 'clients_unavailable', detail: error.message }); } }
    const items = clients.filter((client) => !query || `${client.name} ${client.nickname || ''} ${client.telegram} ${(client.phoneNumbers || []).map((phone) => phone.number).join(' ')} ${client.tobaccoPreferences.join(' ')} ${client.barPreferences.join(' ')}`.toLowerCase().includes(query));
    return json(res, 200, { items, periodDays: guestDays, periodFrom: guestPeriodFrom });
  }
  const clientArchive = pathname.match(/^\/api\/clients\/([^/]+)\/archive$/);
  if (clientArchive && req.method === 'POST') { if (denyUnlessAny(req, res, ['staff_manage', 'orders'])) return; const id = clientArchive[1]; const memory = clients.find((entry) => entry.id === id); if (memory) { memory.archivedAt = new Date().toISOString(); recordAudit(req, 'client.archived', 'client', id, { archivedAt: null }, { archivedAt: memory.archivedAt }); return json(res, 200, memory); } if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(id)) { try { const { rows } = await repositories.pool.query('UPDATE guests SET archived_at=now() WHERE id=$1 AND venue_id=$2 AND archived_at IS NULL RETURNING id,full_name AS name,archived_at AS "archivedAt"', [id, venueDbId]); if (!rows[0]) return json(res, 404, { error: 'client_not_found' }); recordAudit(req, 'client.archived', 'client', id, { archivedAt: null }, rows[0]); return json(res, 200, rows[0]); } catch (error) { return json(res, 409, { error: 'client_archive_failed', detail: error.message }); } } return json(res, 404, { error: 'client_not_found' }); }
  const clientDelete = pathname.match(/^\/api\/clients\/([^/]+)$/);
  if (clientDelete && req.method === 'DELETE') { if (denyUnless(req, res, 'staff_manage')) return; if (req.user?.role !== 'owner') return json(res, 403, { error: 'client_delete_owner_required' }); const id = clientDelete[1]; const index = clients.findIndex((entry) => entry.id === id); if (index >= 0) { const [removed] = clients.splice(index, 1); recordAudit(req, 'client.deleted', 'client', id, removed, null); return json(res, 200, { id, deleted: true }); } if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(id)) { try { const { rows } = await repositories.pool.query('DELETE FROM guests WHERE id=$1 AND venue_id=$2 RETURNING id', [id, venueDbId]); if (!rows[0]) return json(res, 404, { error: 'client_not_found' }); recordAudit(req, 'client.deleted', 'client', id, { id }, null); return json(res, 200, { id, deleted: true }); } catch (error) { return json(res, 409, { error: 'client_delete_failed', detail: error.message }); } } return json(res, 404, { error: 'client_not_found' }); }
  if (pathname === '/api/clients' && req.method === 'POST') {
    if (denyUnlessAny(req, res, ['staff_manage', 'orders'])) return;
    const input = await body(req);
    const protectedGuestFields = ['discountGroupId', 'bonusBalance', 'loyaltyPoints', 'depositBalance'];
    if (process.env.AUTH_REQUIRED === 'true' && protectedGuestFields.some((field) => Object.hasOwn(input, field)
      && !hasPermission(req, 'finance') && !hasPermission(req, 'staff_manage') && !hasPermission(req, 'loyalty'))) {
      return json(res, 403, { error: 'forbidden', permission: 'loyalty' });
    }
    const name = String(input.name || '').trim();
    if (!name || name.length > 120) return json(res, 400, { error: 'client_name_required' });
    if (input.phoneNumbers !== undefined && (!Array.isArray(input.phoneNumbers) || input.phoneNumbers.length > 5 || input.phoneNumbers.some((entry) => !entry || !/^\+7[0-9 ()-]{7,24}$/.test(String(entry.number || '').trim())))) return json(res, 400, { error: 'invalid_phone_numbers' });
    const phoneNumbers = normalizePhoneNumbers(input.phoneNumbers);
    if (phoneNumbers.length && phoneNumbers.filter((phone) => phone.primary).length !== 1) return json(res, 400, { error: 'one_primary_phone_required' });
    if (input.telegram && !/^(@[A-Za-z0-9_]{5,32}|https:\/\/t\.me\/[A-Za-z0-9_]{5,32}\/?$)/.test(String(input.telegram).trim())) return json(res, 400, { error: 'invalid_telegram' });
    const avatarUrl = input.avatarUrl === undefined ? null : String(input.avatarUrl || '');
    const guestStatus = String(input.guestStatus || 'new');
    if (!['new', 'regular', 'vip', 'blocked'].includes(guestStatus)) return json(res, 400, { error: 'invalid_guest_status' });
    if (avatarUrl && (!/^data:image\/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/.test(avatarUrl) || avatarUrl.length > 700000)) return json(res, 400, { error: 'invalid_avatar' });
    const discountGroupId = input.discountGroupId ? String(input.discountGroupId) : null;
    if (discountGroupId && !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(discountGroupId)) return json(res, 400, { error: 'discount_group_not_found' });
    const loyaltyPoints = Number(input.bonusBalance ?? input.loyaltyPoints ?? 0);
    const depositBalance = Number(input.depositBalance ?? 0);
    if (!Number.isInteger(loyaltyPoints) || loyaltyPoints < 0 || loyaltyPoints > 1000000000 || !Number.isFinite(depositBalance) || depositBalance < 0 || depositBalance > 1000000000) return json(res, 400, { error: 'invalid_guest_balance' });
    const client = { id: `client-${Date.now()}`, name, nickname: String(input.nickname || '').trim().slice(0, 80), avatarUrl, guestStatus, phoneNumbers, telegram: String(input.telegram || '').trim(), tobaccoPreferences: Array.isArray(input.tobaccoPreferences) ? input.tobaccoPreferences.map(String).map((item) => item.trim()).filter(Boolean).slice(0, 30) : [], bowlPreferences: Array.isArray(input.bowlPreferences) ? input.bowlPreferences.map(String).map((item) => item.trim()).filter(Boolean).slice(0, 20) : [], barPreferences: Array.isArray(input.barPreferences) ? input.barPreferences.map(String).map((item) => item.trim()).filter(Boolean).slice(0, 30) : [], allergies: String(input.allergies || '').trim().slice(0, 500), notes: String(input.notes || '').trim().slice(0, 2000), loyaltyPoints, bonusBalance: loyaltyPoints, depositBalance, discountGroupId, visits: 0, totalSpent: 0, lastVisitAt: null };
    if (repositories?.pool) {
      try {
        if (discountGroupId) { const group = await repositories.pool.query('SELECT id FROM guest_discount_groups WHERE id=$1 AND venue_id=$2 AND active=true', [discountGroupId, venueDbId]); if (!group.rows[0]) return json(res, 400, { error: 'discount_group_not_found' }); }
        const primary = phoneNumbers.find((phone) => phone.primary)?.number || null;
        const { rows } = await repositories.pool.query(`INSERT INTO guests (venue_id,phone,full_name,avatar_url,guest_status,phone_numbers,telegram,tobacco_preferences,bowl_preferences,bar_preferences,allergies,notes,loyalty_points,discount_group_id,deposit_balance,nickname) VALUES ($1,$2,$3,$4,$5,$6::jsonb,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16) RETURNING id,full_name AS name,nickname,phone,avatar_url AS "avatarUrl",guest_status AS "guestStatus",phone_numbers AS "phoneNumbers",telegram,tobacco_preferences AS "tobaccoPreferences",bowl_preferences AS "bowlPreferences",bar_preferences AS "barPreferences",allergies,notes,loyalty_points AS "loyaltyPoints",discount_group_id AS "discountGroupId",deposit_balance AS "depositBalance"`, [venueDbId, primary, name, client.avatarUrl || null, client.guestStatus, JSON.stringify(phoneNumbers), client.telegram || null, client.tobaccoPreferences, client.bowlPreferences, client.barPreferences, client.allergies || null, client.notes || null, loyaltyPoints, discountGroupId, depositBalance, client.nickname]);
        if (rows[0]) { const persistedClient = { ...client, ...rows[0], bonusBalance: Number(rows[0].loyaltyPoints || 0), depositBalance: Number(rows[0].depositBalance || 0) }; await recordAudit(req, 'client.created', 'client', persistedClient.id, null, persistedClient); return json(res, 201, persistedClient); }
      } catch (error) { return json(res, 503, { error: 'client_create_failed', detail: error.message }); }
    }
    if (discountGroupId && !discountGroups.some((group) => group.id === discountGroupId && group.venueId === currentVenueId && group.active !== false)) return json(res, 400, { error: 'discount_group_not_found' });
    clients.push(client); recordAudit(req, 'client.created', 'client', client.id, null, client); return json(res, 201, client);
  }
  const clientProfile = pathname.match(/^\/api\/clients\/([^/]+)$/);
  if (clientProfile && req.method === 'PATCH') {
    if (denyUnlessAny(req, res, ['staff_manage', 'orders'])) return;
    let client = clients.find((entry) => entry.id === clientProfile[1]);
    if (!client && repositories?.pool && /^[0-9a-f-]{36}$/i.test(clientProfile[1])) {
      try {
        const { rows } = await repositories.pool.query(`SELECT id,full_name AS name,nickname,phone,avatar_url AS "avatarUrl",guest_status AS "guestStatus",phone_numbers AS "phoneNumbers",telegram,tobacco_preferences AS "tobaccoPreferences",bowl_preferences AS "bowlPreferences",bar_preferences AS "barPreferences",allergies,notes,loyalty_points AS "loyaltyPoints",discount_group_id AS "discountGroupId",deposit_balance AS "depositBalance" FROM guests WHERE id=$1 AND venue_id=$2`, [clientProfile[1], venueDbId]);
        if (rows[0]) client = { ...rows[0], phoneNumbers: rows[0].phoneNumbers || (rows[0].phone ? [{ label: 'Основной', number: rows[0].phone, primary: true }] : []), tobaccoPreferences: rows[0].tobaccoPreferences || [], bowlPreferences: rows[0].bowlPreferences || [], barPreferences: rows[0].barPreferences || [], loyaltyPoints: Number(rows[0].loyaltyPoints || 0), bonusBalance: Number(rows[0].loyaltyPoints || 0), depositBalance: Number(rows[0].depositBalance || 0) };
      } catch (_) {}
    }
    if (!client) return json(res, 404, { error: 'client_not_found' });
    const input = await body(req);
    const protectedGuestFields = ['discountGroupId', 'bonusBalance', 'loyaltyPoints', 'depositBalance'];
    if (process.env.AUTH_REQUIRED === 'true' && protectedGuestFields.some((field) => Object.hasOwn(input, field)
      && !hasPermission(req, 'finance') && !hasPermission(req, 'staff_manage') && !hasPermission(req, 'loyalty'))) {
      return json(res, 403, { error: 'forbidden', permission: 'loyalty' });
    }
    const before = JSON.parse(JSON.stringify(client));
    if (input.nickname !== undefined) client.nickname = String(input.nickname || '').trim().slice(0, 80);
    if (input.name !== undefined) { const name = String(input.name || '').trim(); if (!name || name.length > 120) return json(res, 400, { error: 'client_name_required' }); client.name = name; }
    if (input.phoneNumbers !== undefined) { if (!Array.isArray(input.phoneNumbers) || input.phoneNumbers.length > 5 || input.phoneNumbers.some((entry) => !entry || !/^\+7[0-9 ()-]{7,24}$/.test(String(entry.number || '').trim()))) return json(res, 400, { error: 'invalid_phone_numbers' }); const phoneNumbers = normalizePhoneNumbers(input.phoneNumbers); if (phoneNumbers.length && phoneNumbers.filter((phone) => phone.primary).length !== 1) return json(res, 400, { error: 'one_primary_phone_required' }); client.phoneNumbers = phoneNumbers; }
    if (input.avatarUrl !== undefined) { const avatarUrl = String(input.avatarUrl || ''); if (avatarUrl && (!/^data:image\/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/.test(avatarUrl) || avatarUrl.length > 700000)) return json(res, 400, { error: 'invalid_avatar' }); client.avatarUrl = avatarUrl || null; }
    if (input.guestStatus !== undefined) { const guestStatus = String(input.guestStatus || 'new'); if (!['new', 'regular', 'vip', 'blocked'].includes(guestStatus)) return json(res, 400, { error: 'invalid_guest_status' }); client.guestStatus = guestStatus; }
    if (input.telegram !== undefined) { const telegram = String(input.telegram || '').trim(); if (telegram && !/^(@[A-Za-z0-9_]{5,32}|https:\/\/t\.me\/[A-Za-z0-9_]{5,32}\/?$)/.test(telegram)) return json(res, 400, { error: 'invalid_telegram' }); client.telegram = telegram; }
    for (const key of ['tobaccoPreferences', 'bowlPreferences', 'barPreferences']) if (input[key] !== undefined) client[key] = Array.isArray(input[key]) ? input[key].map(String).map((item) => item.trim()).filter(Boolean).slice(0, 30) : [];
    if (input.allergies !== undefined) client.allergies = String(input.allergies || '').trim().slice(0, 500);
    if (input.notes !== undefined) client.notes = String(input.notes || '').trim().slice(0, 2000);
    if (input.discountGroupId !== undefined) {
      const nextGroupId = input.discountGroupId ? String(input.discountGroupId) : null;
      if (nextGroupId && !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(nextGroupId)) return json(res, 400, { error: 'discount_group_not_found' });
      if (nextGroupId && repositories?.pool) { try { const group = await repositories.pool.query('SELECT id FROM guest_discount_groups WHERE id=$1 AND venue_id=$2 AND active=true', [nextGroupId, venueDbId]); if (!group.rows[0]) return json(res, 400, { error: 'discount_group_not_found' }); } catch (error) { return json(res, 503, { error: 'discount_groups_unavailable', detail: error.message }); } }
      if (nextGroupId && !repositories?.pool && !discountGroups.some((group) => group.id === nextGroupId && group.venueId === currentVenueId && group.active !== false)) return json(res, 400, { error: 'discount_group_not_found' });
      client.discountGroupId = nextGroupId;
    }
    if (input.bonusBalance !== undefined || input.loyaltyPoints !== undefined) { const points = Number(input.bonusBalance ?? input.loyaltyPoints); if (!Number.isInteger(points) || points < 0 || points > 1000000000) return json(res, 400, { error: 'invalid_guest_balance' }); client.bonusBalance = client.loyaltyPoints = points; }
    if (input.depositBalance !== undefined) { const deposit = Number(input.depositBalance); if (!Number.isFinite(deposit) || deposit < 0 || deposit > 1000000000) return json(res, 400, { error: 'invalid_guest_balance' }); client.depositBalance = deposit; }
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(client.id)) { try { const primary = client.phoneNumbers.find((phone) => phone.primary)?.number || null; const { rows } = await repositories.pool.query(`UPDATE guests SET phone=$1,full_name=$2,avatar_url=$3,guest_status=$4,phone_numbers=$5::jsonb,telegram=$6,tobacco_preferences=$7,bowl_preferences=$8,bar_preferences=$9,allergies=$10,notes=$11,discount_group_id=$12,loyalty_points=$13,deposit_balance=$14,nickname=$17 WHERE id=$15 AND venue_id=$16 RETURNING id,full_name AS name,nickname,phone,avatar_url AS "avatarUrl",guest_status AS "guestStatus",phone_numbers AS "phoneNumbers",telegram,tobacco_preferences AS "tobaccoPreferences",bowl_preferences AS "bowlPreferences",bar_preferences AS "barPreferences",allergies,notes,loyalty_points AS "loyaltyPoints",discount_group_id AS "discountGroupId",deposit_balance AS "depositBalance"`, [primary, client.name, client.avatarUrl || null, client.guestStatus, JSON.stringify(client.phoneNumbers), client.telegram || null, client.tobaccoPreferences, client.bowlPreferences, client.barPreferences, client.allergies || null, client.notes || null, client.discountGroupId || null, Number(client.loyaltyPoints || 0), Number(client.depositBalance || 0), client.id, venueDbId, client.nickname || '']); if (rows[0]) { const persistedClient = { ...client, ...rows[0], bonusBalance: Number(rows[0].loyaltyPoints || 0), depositBalance: Number(rows[0].depositBalance || 0) }; await recordAudit(req, 'client.updated', 'client', persistedClient.id, before, persistedClient); return json(res, 200, persistedClient); } } catch (error) { Object.assign(client, before); return json(res, 503, { error: 'client_update_failed', detail: error.message }); } }
    recordAudit(req, 'client.updated', 'client', client.id, before, client); return json(res, 200, client);
  }
  const clientHistory = pathname.match(/^\/api\/clients\/([^/]+)\/history$/);
  if (clientHistory && req.method === 'GET') {
    if (process.env.AUTH_REQUIRED === 'true' && !hasPermission(req, 'staff') && !hasPermission(req, 'staff_view') && !hasPermission(req, 'orders')) return json(res, 403, { error: 'forbidden', permission: 'clients' });
    const clientId = clientHistory[1];
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(clientId)) {
      try {
        const [orderRows, reservationRows] = await Promise.all([
          repositories.pool.query(`SELECT o.id,o.table_id AS "tableId",o.status,o.created_at AS "createdAt",o.closed_at AS "closedAt",o.vip_minimum AS "minimumOrderTotal",COALESCE(SUM(p.amount) FILTER (WHERE p.status IN ('paid','partially_paid')),0)::numeric AS total FROM orders o LEFT JOIN payments p ON p.order_id=o.id WHERE o.venue_id=$1 AND o.guest_id=$2 GROUP BY o.id ORDER BY o.created_at DESC LIMIT 50`, [venueDbId, clientId]),
          repositories.pool.query(`SELECT r.id,r.table_id AS "tableId",r.starts_at AS "startsAt",to_char(r.starts_at AT TIME ZONE COALESCE(NULLIF(v.timezone,''),'Asia/Yekaterinburg'),'YYYY-MM-DD') AS date,to_char(r.starts_at AT TIME ZONE COALESCE(NULLIF(v.timezone,''),'Asia/Yekaterinburg'),'HH24:MI') AS time,r.status,r.deposit_paid AS deposit,r.deposit_required AS "depositRequired",r.guests_count AS guests,r.notes FROM reservations r JOIN venues v ON v.id=r.venue_id WHERE r.venue_id=$1 AND r.guest_id=$2 ORDER BY r.starts_at DESC LIMIT 50`, [venueDbId, clientId])
        ]);
        return json(res, 200, { orders: orderRows.rows.map((row) => ({ ...row, total: Number(row.total || 0), minimumOrderTotal: Number(row.minimumOrderTotal || 0) })), reservations: reservationRows.rows.map((row) => ({ ...row, deposit: Number(row.deposit || 0), depositRequired: Number(row.depositRequired || 0), guests: Number(row.guests || 0) })) });
      } catch (error) { return json(res, 503, { error: 'client_history_unavailable', detail: error.message }); }
    }
    const client = clients.find((entry) => entry.id === clientId);
    if (!client) return json(res, 404, { error: 'client_not_found' });
    const phones = new Set((client.phoneNumbers || []).map((phone) => phone.number));
    const historyOrders = orders.filter((order) => order.clientId === clientId || order.guestName === client.name || phones.has(order.guestPhone)).map((order) => ({ id: order.id, tableId: order.tableId, status: order.status, createdAt: order.createdAt, closedAt: order.closedAt || null, total: order.finalTotal ?? (order.items || []).reduce((sum, item) => sum + Number(item.unitPrice || 0) * Number(item.quantity || 0), 0), minimumOrderTotal: Number(order.minimumOrderTotal || 0) }));
    const historyReservations = reservations.filter((reservation) => reservation.clientId === clientId || reservation.guestName === client.name || phones.has(reservation.phone)).map((reservation) => ({ id: reservation.id, tableId: reservation.tableId, date: reservation.date, time: reservation.time, status: reservation.status, guests: reservation.guests, deposit: Number(reservation.deposit || 0), notes: reservation.notes || '' }));
    return json(res, 200, { orders: historyOrders.sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || ''))).slice(0, 50), reservations: historyReservations.sort((a, b) => `${b.date} ${b.time}`.localeCompare(`${a.date} ${a.time}`)).slice(0, 50) });
  }
  const clientLoyalty = pathname.match(/^\/api\/clients\/([^/]+)\/loyalty$/);
  if (clientLoyalty && req.method === 'POST') {
    if (process.env.AUTH_REQUIRED === 'true' && !hasPermission(req, 'finance') && !hasPermission(req, 'staff_manage') && !hasPermission(req, 'loyalty')) return json(res, 403, { error: 'forbidden', permission: 'loyalty' });
    const input = await body(req); const delta = Number(input.delta); const reason = String(input.reason || '').trim();
    if (!Number.isInteger(delta) || delta === 0 || Math.abs(delta) > 100000 || !reason || reason.length > 500) return json(res, 400, { error: 'invalid_loyalty_adjustment' });
    if (repositories?.pool && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(clientLoyalty[1])) {
      try {
        const { rows } = await repositories.pool.query(`WITH current_guest AS (
          SELECT id,loyalty_points FROM guests WHERE id=$2 AND venue_id=$3 FOR UPDATE
        ), updated_guest AS (
          UPDATE guests g SET loyalty_points=GREATEST(0,current_guest.loyalty_points::bigint+$1)::int
          FROM current_guest
          WHERE g.id=current_guest.id AND current_guest.loyalty_points::bigint+$1 <= 2147483647
          RETURNING g.id,g.loyalty_points AS "loyaltyPoints",current_guest.loyalty_points AS "previousPoints"
        ) SELECT * FROM updated_guest`, [delta, clientLoyalty[1], venueDbId]);
        if (!rows[0]) {
          const exists = await repositories.pool.query('SELECT 1 FROM guests WHERE id=$1 AND venue_id=$2', [clientLoyalty[1], venueDbId]);
          return exists.rows[0] ? json(res, 409, { error: 'loyalty_balance_limit' }) : json(res, 404, { error: 'client_not_found' });
        }
        const client = { id: rows[0].id, loyaltyPoints: Number(rows[0].loyaltyPoints) };
        const before = Number(rows[0].previousPoints);
        recordAudit(req, 'client.loyalty_adjusted', 'client', client.id, { loyaltyPoints: before }, { loyaltyPoints: client.loyaltyPoints, delta, reason });
        return json(res, 200, { id: client.id, loyaltyPoints: client.loyaltyPoints, bonusBalance: client.loyaltyPoints, delta, reason });
      } catch (error) { return json(res, 503, { error: 'loyalty_save_failed', detail: error.message }); }
    }
    let client = clients.find((entry) => entry.id === clientLoyalty[1]);
    if (!client) return json(res, 404, { error: 'client_not_found' });
    const before = Number(client.loyaltyPoints || 0); client.loyaltyPoints = client.bonusBalance = Math.max(0, before + delta);
    recordAudit(req, 'client.loyalty_adjusted', 'client', client.id, { loyaltyPoints: before }, { loyaltyPoints: client.loyaltyPoints, delta, reason }); return json(res, 200, { id: client.id, loyaltyPoints: client.loyaltyPoints, bonusBalance: client.bonusBalance, delta, reason });
  }
  const productImage = pathname.match(/^\/api\/products\/([^/]+)\/image$/);
  if (productImage && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req); const imageData = String(input.imageData || '');
    if (!/^data:image\/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/.test(imageData) || imageData.length > 1_500_000) return json(res, 400, { error: 'invalid_image', message: 'Поддерживаются PNG, JPG и WebP до 1.5 МБ' });
    if (repositories?.inventory) { const product = await repositories.inventory.setProductImage(venueDbId, productImage[1], imageData); if (!product) return json(res, 404, { error: 'product_not_found' }); recordAudit(req, 'product.image_updated', 'product', product.id, null, { id: product.id, name: product.name, imageUrl: '[image]' }); return json(res, 200, product); }
    const product = products.find((entry) => entry.id === productImage[1]); if (!product) return json(res, 404, { error: 'product_not_found' }); product.imageUrl = imageData; recordAudit(req, 'product.image_updated', 'product', product.id, null, { id: product.id, name: product.name, imageUrl: '[image]' }); return json(res, 200, product);
  }
  if (pathname === '/api/session') {
    const persistedSession = await sessionFromRequest(req);
    const user = req.user || persistedSession?.user || { name: 'Демо сотрудник', role: 'bartender' };
    return json(res, 200, { user, permissions: effectivePermissions(user), permissionScopes: normalizePermissionScopes(user.permissionScopes) });
  }
  const customStaffRolePath = pathname.match(/^\/api\/staff\/roles(?:\/([^/]+))?(?:\/(archive))?$/);
  if (customStaffRolePath) {
    if (process.env.AUTH_REQUIRED === 'true' && req.user?.role !== 'owner') return json(res, 403, { error: 'custom_roles_owner_required' });
    if (req.user && req.user.role !== 'owner') return json(res, 403, { error: 'custom_roles_owner_required' });
    if (!repositories?.pool) return json(res, 503, { error: 'custom_roles_requires_database' });
    const organizationId = requestOrganizationId(req);
    if (!/^[0-9a-f-]{36}$/i.test(organizationId) || !/^[0-9a-f-]{36}$/i.test(venueDbId)) return json(res, 403, { error: 'organization_context_required' });
    const roleId = customStaffRolePath[1] || null;
    const archived = customStaffRolePath[2] === 'archive';
    const roleIdIsUuid = roleId && /^[0-9a-f-]{36}$/i.test(roleId);
    if (roleId && !roleIdIsUuid) return json(res, 400, { error: 'custom_role_id_invalid' });
    try {
      if (req.method === 'GET' && !roleId) {
        const includeArchived = url.searchParams.get('status') === 'all' || url.searchParams.get('status') === 'archived';
        const activeClause = includeArchived ? '' : ' AND r.is_active=true';
        const { rows } = await repositories.pool.query(`SELECT r.id,r.name,r.description,r.permission_scopes AS "permissionScopes",r.is_active AS active,r.created_at AS "createdAt",r.updated_at AS "updatedAt",COUNT(u.id)::int AS "assignedCount"
          FROM custom_staff_roles r LEFT JOIN users u ON u.custom_role_id=r.id AND u.venue_id=r.venue_id AND u.deleted_at IS NULL
          WHERE r.organization_id=$1 AND r.venue_id=$2${activeClause} GROUP BY r.id ORDER BY r.is_active DESC,lower(r.name),r.id`, [organizationId, venueDbId]);
        return json(res, 200, { items: rows.map((row) => ({ ...row, permissionScopes: normalizePermissionScopes(row.permissionScopes || []) })) });
      }
      if (req.method === 'POST' && !roleId) {
        if (archived) return json(res, 404, { error: 'custom_role_not_found' });
        const input = await body(req);
        const name = String(input.name || '').trim();
        const description = String(input.description || '').trim();
        const scopes = normalizePermissionScopes(input.permissionScopes);
        if (!name || name.length > 80 || description.length > 300 || !Array.isArray(input.permissionScopes) || scopes.length !== new Set(input.permissionScopes).size) return json(res, 400, { error: 'custom_role_invalid' });
        const venueCheck = await repositories.pool.query('SELECT id FROM venues WHERE id=$1 AND organization_id=$2 AND is_active=true', [venueDbId, organizationId]);
        if (!venueCheck.rows[0]) return json(res, 403, { error: 'venue_not_in_organization' });
        const { rows } = await repositories.pool.query(`INSERT INTO custom_staff_roles (organization_id,venue_id,name,description,permission_scopes,created_by,updated_by) VALUES ($1,$2,$3,$4,$5::jsonb,$6,$6) RETURNING id,name,description,permission_scopes AS "permissionScopes",is_active AS active,created_at AS "createdAt",updated_at AS "updatedAt"`, [organizationId, venueDbId, name, description, JSON.stringify(scopes), req.user?.id || null]);
        const created = { ...rows[0], permissionScopes: normalizePermissionScopes(rows[0].permissionScopes || []), assignedCount: 0 };
        recordAudit(req, 'staff.custom_role_created', 'custom_staff_role', created.id, null, created);
        return json(res, 201, created);
      }
      if (!roleId) return json(res, 405, { error: 'method_not_allowed' });
      if (archived && req.method !== 'POST') return json(res, 405, { error: 'method_not_allowed' });
      if (!archived && req.method !== 'PATCH') return json(res, 405, { error: 'method_not_allowed' });
      const currentResult = await repositories.pool.query(`SELECT id,name,description,permission_scopes AS "permissionScopes",is_active AS active FROM custom_staff_roles WHERE id=$1 AND organization_id=$2 AND venue_id=$3`, [roleId, organizationId, venueDbId]);
      const current = currentResult.rows[0];
      if (!current) return json(res, 404, { error: 'custom_role_not_found' });
      if (archived) {
        if (!current.active) return json(res, 200, { ...current, archivedAt: null });
        const assigned = await repositories.pool.query('SELECT COUNT(*)::int AS count FROM users WHERE custom_role_id=$1 AND venue_id=$2 AND deleted_at IS NULL', [roleId, venueDbId]);
        if (Number(assigned.rows[0]?.count || 0) > 0) return json(res, 409, { error: 'custom_role_in_use', assignedCount: Number(assigned.rows[0].count) });
        const { rows } = await repositories.pool.query('UPDATE custom_staff_roles SET is_active=false,updated_by=$1,updated_at=now() WHERE id=$2 AND organization_id=$3 AND venue_id=$4 RETURNING id,name,description,permission_scopes AS "permissionScopes",is_active AS active,updated_at AS "updatedAt"', [req.user?.id || null, roleId, organizationId, venueDbId]);
        recordAudit(req, 'staff.custom_role_archived', 'custom_staff_role', roleId, current, rows[0]);
        return json(res, 200, { ...rows[0], permissionScopes: normalizePermissionScopes(rows[0].permissionScopes || []) });
      }
      const input = await body(req);
      const name = input.name === undefined ? current.name : String(input.name || '').trim();
      const description = input.description === undefined ? current.description : String(input.description || '').trim();
      const scopes = input.permissionScopes === undefined ? normalizePermissionScopes(current.permissionScopes || []) : normalizePermissionScopes(input.permissionScopes);
      if (!name || name.length > 80 || description.length > 300 || (input.permissionScopes !== undefined && (!Array.isArray(input.permissionScopes) || scopes.length !== new Set(input.permissionScopes).size))) return json(res, 400, { error: 'custom_role_invalid' });
      const { rows } = await repositories.pool.query('UPDATE custom_staff_roles SET name=$1,description=$2,permission_scopes=$3::jsonb,updated_by=$4,updated_at=now() WHERE id=$5 AND organization_id=$6 AND venue_id=$7 AND is_active=true RETURNING id,name,description,permission_scopes AS "permissionScopes",is_active AS active,updated_at AS "updatedAt"', [name, description, JSON.stringify(scopes), req.user?.id || null, roleId, organizationId, venueDbId]);
      recordAudit(req, 'staff.custom_role_updated', 'custom_staff_role', roleId, current, rows[0]);
      return json(res, 200, { ...rows[0], permissionScopes: normalizePermissionScopes(rows[0].permissionScopes || []) });
    } catch (error) {
      if (error.code === '23505') return json(res, 409, { error: 'custom_role_name_exists' });
      return json(res, 503, { error: 'custom_role_save_failed', detail: error.message });
    }
  }
  if (pathname === '/api/staff' && req.method === 'GET') {
    if (process.env.AUTH_REQUIRED === 'true' && !hasPermission(req, 'staff') && !hasPermission(req, 'settings') && !hasPermission(req, 'staff_view')) return json(res, 403, { error: 'forbidden', permission: 'staff' });
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query(`SELECT id,full_name AS name,login,contact_email AS email,role,is_active AS active,avatar_url AS "avatarUrl",photo_url AS "photoUrl",birth_date::text AS "birthDate",telegram_url AS telegram,phone_numbers AS "phoneNumbers",permission_scopes AS "permissionScopes",custom_role_id AS "customRoleId",employment_started_at::text AS "employmentStartedAt",work_notes AS "workNotes",pin_updated_at AS "pinUpdatedAt" FROM users WHERE venue_id=$1 AND deleted_at IS NULL ORDER BY full_name`, [venueDbId]); return json(res, 200, { items: rows.map((row) => { row.pinConfigured = Boolean(row.pinUpdatedAt); if (!row.pinConfigured) delete row.pinUpdatedAt; if (!canSeeStaffPhoto(req)) delete row.photoUrl; return row; }) }); } catch (_) { try { const { rows } = await repositories.pool.query(`SELECT id,full_name AS name,login,contact_email AS email,role,is_active AS active,avatar_url AS "avatarUrl",photo_url AS "photoUrl",birth_date::text AS "birthDate",telegram_url AS telegram,phone_numbers AS "phoneNumbers" FROM users WHERE venue_id=$1 AND deleted_at IS NULL ORDER BY full_name`, [venueDbId]); return json(res, 200, { items: rows.map((row) => { if (!canSeeStaffPhoto(req)) delete row.photoUrl; return { ...row, pinConfigured: false, permissionScopes: [], employmentStartedAt: null, workNotes: '' }; }) }); } catch (_) { try { const { rows } = await repositories.pool.query(`SELECT id,full_name AS name,login,contact_email AS email,role,is_active AS active,avatar_url AS "avatarUrl" FROM users WHERE venue_id=$1 AND deleted_at IS NULL ORDER BY full_name`, [venueDbId]); return json(res, 200, { items: rows.map((row) => ({ ...row, pinConfigured: false, telegram: null, phoneNumbers: [], permissionScopes: [], employmentStartedAt: null, workNotes: '' })) }); } catch (_) {} } } }
    return json(res, 200, { items: staff.filter((person) => !person.deletedAt).map(({ passwordHash, ...person }) => { person.pinConfigured = Boolean(person.pinCode || person.pinHash || person.pinConfigured); if (!canSeeSensitiveStaff(req)) { delete person.passportData; delete person.pinCode; } if (!canSeeStaffPhoto(req)) delete person.photoUrl; if (!person.pinConfigured) delete person.pinUpdatedAt; return person; }) });
  }
  if (pathname === '/api/staff' && req.method === 'POST') {
    if (denyUnless(req, res, 'staff_manage')) return;
    const input = await body(req);
    if (!input.name || !rolePermissions[input.role] || input.role === 'owner') return json(res, 400, { error: 'name_and_valid_role_required' });
    const nonCrmRole = ['cleaner','security','technician','other_staff'].includes(input.role);
    if (!nonCrmRole && !input.password) return json(res, 400, { error: 'password_required' });
    if (!nonCrmRole && input.password !== undefined && (String(input.password).length < 4 || String(input.password).length > 11)) return json(res, 400, { error: 'password_length_invalid' });
        if (!canCreateStaffRole(req, input.role)) return json(res, 403, { error: 'staff_role_assignment_required' });
    const requestedScopes = normalizePermissionScopes(input.permissionScopes);
    if (input.permissionScopes !== undefined && (!Array.isArray(input.permissionScopes) || requestedScopes.length !== new Set(input.permissionScopes).size)) return json(res, 400, { error: 'invalid_permission_scopes' });
    if (input.permissionScopes !== undefined && process.env.AUTH_REQUIRED === 'true' && req.user?.role !== 'owner') return json(res, 403, { error: 'permission_scopes_owner_required' });
    const assignedScopes = input.permissionScopes === undefined ? [] : requestedScopes;
    if (!validBirthDate(input.birthDate)) return json(res, 400, { error: 'birth_date_required' });
    if (!validEmploymentDate(input.employmentStartedAt)) return json(res, 400, { error: 'invalid_employment_date' });
    if (input.workNotes !== undefined && String(input.workNotes).length > 4000) return json(res, 400, { error: 'work_notes_too_long' });
    if (input.telegram && !/^(@[A-Za-z0-9_]{5,32}|https:\/\/t\.me\/[A-Za-z0-9_]{5,32}\/?$)/.test(String(input.telegram).trim())) return json(res, 400, { error: 'invalid_telegram' });
    if (input.phoneNumbers !== undefined && (!Array.isArray(input.phoneNumbers) || input.phoneNumbers.length > 5 || input.phoneNumbers.some((entry) => !entry || !/^\+7[0-9 ()-]{7,24}$/.test(String(entry.number || '').trim())))) return json(res, 400, { error: 'invalid_phone_numbers' });
    if (input.photoUrl !== undefined && !canSeeStaffPhoto(req)) return json(res, 403, { error: 'staff_photo_permission_required' });
    if (input.photoUrl && !validImageData(input.photoUrl)) return json(res, 400, { error: 'invalid_staff_photo' });
    if (!nonCrmRole && input.login !== undefined && !/^[A-Za-zА-Яа-яЁё0-9_-]{3,32}$/.test(String(input.login).trim())) return json(res, 400, { error: 'invalid_staff_login' });
    if (!nonCrmRole && input.login !== undefined && ['admin', 'owner', 'staff', String(process.env.SAAS_OWNER_EMAIL || '').trim().toLowerCase()].includes(String(input.login).trim().toLowerCase())) return json(res, 409, { error: 'reserved_staff_login' });
    if (input.email !== undefined && (input.email === null || typeof input.email !== 'string' || String(input.email).trim().length > 254 || (String(input.email).trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(input.email).trim())))) return json(res, 400, { error: 'invalid_staff_email' });
    const contactNumbers = normalizePhoneNumbers(input.phoneNumbers);
    if (contactNumbers.length && contactNumbers.filter((entry) => entry.primary).length !== 1) return json(res, 400, { error: 'one_primary_phone_required' });
    const createdPassport = input.passportData !== undefined ? staffPassportCipher.encrypt(input.passportData) : null;
    if (input.passportData !== undefined && !canSeeSensitiveStaff(req)) return json(res, 403, { error: 'sensitive_staff_permission_required' });
    if (input.passportData !== undefined && !createdPassport) return json(res, 503, { error: 'staff_passport_key_required' });
    if (repositories?.pool) {
      const organizationId = requestOrganizationId(req);
      if (!/^[0-9a-f-]{36}$/i.test(organizationId)) return json(res, 403, { error: 'organization_context_required' });
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        const quota = await checkOrganizationQuota(client, organizationId, 'seat');
        if (quota.error) { await client.query('ROLLBACK'); return json(res, quota.status, { error: quota.error, ...(quota.limit ? { limit: quota.limit, used: quota.used } : {}) }); }
        const venueCheck = await client.query('SELECT id FROM venues WHERE id=$1 AND organization_id=$2 AND is_active=true FOR UPDATE', [venueDbId, organizationId]);
        if (!venueCheck.rows[0]) { await client.query('ROLLBACK'); return json(res, 403, { error: 'venue_not_in_organization' }); }
        const login = nonCrmRole ? `staff_${Date.now()}` : (input.login || `user_${Date.now()}`);
        const passwordHash = nonCrmRole ? null : await hashPassword(input.password);
        const insert = async (legacySchema = false) => client.query(legacySchema
          ? `INSERT INTO users (venue_id,organization_id,full_name,login,password_hash,pin_hash,role,avatar_url,photo_url,birth_date,telegram_url,phone_numbers,employment_started_at,work_notes,passport_data_encrypted,passport_data_iv,passport_data_tag) VALUES ($1,$2,$3,$4,$5,NULL,$6,$7,$8,$9::date,$10,$11::jsonb,$12,$13,$14,$15,$16) RETURNING id,full_name AS name,login,role,is_active AS active,avatar_url AS "avatarUrl",photo_url AS "photoUrl",birth_date::text AS "birthDate",telegram_url AS telegram,phone_numbers AS "phoneNumbers",employment_started_at::text AS "employmentStartedAt",work_notes AS "workNotes"`
          : `INSERT INTO users (venue_id,organization_id,full_name,login,password_hash,pin_hash,role,permission_scopes,avatar_url,photo_url,birth_date,telegram_url,phone_numbers,employment_started_at,work_notes,passport_data_encrypted,passport_data_iv,passport_data_tag) VALUES ($1,$2,$3,$4,$5,NULL,$6,$7::jsonb,$8,$9,$10::date,$11,$12::jsonb,$13,$14,$15,$16,$17) RETURNING id,full_name AS name,login,role,permission_scopes AS "permissionScopes",is_active AS active,avatar_url AS "avatarUrl",photo_url AS "photoUrl",birth_date::text AS "birthDate",telegram_url AS telegram,phone_numbers AS "phoneNumbers",employment_started_at::text AS "employmentStartedAt",work_notes AS "workNotes"`,
          legacySchema
            ? [venueDbId, organizationId, input.name, login, passwordHash, input.role, input.avatarUrl || null, input.photoUrl || null, input.birthDate, input.telegram || null, JSON.stringify(contactNumbers), input.employmentStartedAt || null, String(input.workNotes || '').slice(0, 4000), createdPassport?.data || null, createdPassport?.iv || null, createdPassport?.tag || null]
            : [venueDbId, organizationId, input.name, login, passwordHash, input.role, JSON.stringify(assignedScopes), input.avatarUrl || null, input.photoUrl || null, input.birthDate, input.telegram || null, JSON.stringify(contactNumbers), input.employmentStartedAt || null, String(input.workNotes || '').slice(0, 4000), createdPassport?.data || null, createdPassport?.iv || null, createdPassport?.tag || null]);
        let rows;
        try { ({ rows } = await insert()); }
        catch (error) { if (error.code !== '42703' && error.code !== '42704') throw error; ({ rows } = await insert(true)); }
        const membershipRole = input.role === 'admin' ? 'admin' : 'member';
        await client.query(`INSERT INTO organization_memberships (organization_id,user_id,membership_role,status) VALUES ($1,$2,$3,'active') ON CONFLICT (organization_id,user_id) DO UPDATE SET membership_role=EXCLUDED.membership_role,status='active'`, [organizationId, rows[0].id, membershipRole]);
        if (input.email !== undefined) {
          const email = String(input.email).trim().replace(/@([^@]+)$/, (_, domain) => `@${domain.toLowerCase()}`);
          await client.query('UPDATE users SET contact_email=$1 WHERE id=$2 AND venue_id=$3', [email, rows[0].id, venueDbId]);
          rows[0].email = email;
        }
        await client.query('COMMIT');
        const result = { ...rows[0], permissionScopes: rows[0].permissionScopes || assignedScopes, employmentStartedAt: input.employmentStartedAt || null, workNotes: String(input.workNotes || '').slice(0, 4000) };
        if (!canSeeStaffPhoto(req)) delete result.photoUrl;
        recordAudit(req, 'staff.created', 'staff', rows[0].id, null, result); return json(res, 201, result);
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: error.code === '23505' ? 'login_already_exists' : 'staff_create_failed', detail: error.message }); }
      finally { client.release(); }
    }
    const person = { id: `u-${Date.now()}`, name: input.name, login: nonCrmRole ? `staff_${Date.now()}` : (input.login || `user_${Date.now()}`), passwordHash: nonCrmRole ? null : await hashPassword(input.password), role: input.role, active: true, avatarUrl: input.avatarUrl || null, photoUrl: input.photoUrl || null, birthDate: input.birthDate, telegram: input.telegram || null, phoneNumbers: contactNumbers, permissionScopes: assignedScopes, employmentStartedAt: input.employmentStartedAt || null, workNotes: String(input.workNotes || '').slice(0, 4000), passportData: input.passportData || null, pinCode: null, pinConfigured: false, pinUpdatedAt: null };
    staff.push(person);
    const { passwordHash, ...publicPerson } = person;
    recordAudit(req, 'staff.created', 'staff', person.id, null, publicPerson);
    return json(res, 201, publicPerson);
  }
  const staffStatus = pathname.match(/^\/api\/staff\/([^/]+)\/status$/);
  if (staffStatus && req.method === 'PATCH') {
    if (denyUnless(req, res, 'staff_manage')) return;
    const input = await body(req); if (typeof input.active !== 'boolean') return json(res, 400, { error: 'active_boolean_required' });
    if (String(req.user?.id || '') === staffStatus[1] && !input.active) return json(res, 409, { error: 'self_deactivation_forbidden' });
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(staffStatus[1])) {
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        const current = await client.query(`SELECT id,organization_id AS "organizationId",is_active AS active FROM users WHERE id=$1 AND venue_id=$2 AND role <> 'owner' AND deleted_at IS NULL`, [staffStatus[1], venueDbId]);
        if (!current.rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'staff_not_found_or_archived_or_owner' }); }
        const person = current.rows[0];
        if (input.active && !person.active) {
          const quota = await checkOrganizationQuota(client, person.organizationId || requestOrganizationId(req), 'seat');
          if (quota.error) { await client.query('ROLLBACK'); return json(res, quota.status, { error: quota.error, ...(quota.limit ? { limit: quota.limit, used: quota.used } : {}) }); }
        }
        const locked = await client.query(`SELECT id FROM users WHERE id=$1 AND venue_id=$2 AND role <> 'owner' AND deleted_at IS NULL FOR UPDATE`, [staffStatus[1], venueDbId]);
        if (!locked.rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'staff_not_found_or_archived_or_owner' }); }
        const { rows } = await client.query(`UPDATE users SET is_active=$1 WHERE id=$2 AND venue_id=$3 RETURNING id,full_name AS name,role,is_active AS active,avatar_url AS "avatarUrl"`, [input.active, staffStatus[1], venueDbId]);
        await client.query('COMMIT'); recordAudit(req, input.active ? 'staff.activated' : 'staff.deactivated', 'staff', rows[0].id, { active: !input.active }, rows[0]); return json(res, 200, rows[0]);
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'staff_status_update_failed', detail: error.message }); }
      finally { client.release(); }
    }
    const person = staff.find((entry) => entry.id === staffStatus[1]); if (!person || person.role === 'owner' || person.deletedAt) return json(res, 404, { error: 'staff_not_found_or_archived_or_owner' }); if (!canManageStaffTarget(req, person.role)) return json(res, 403, { error: 'staff_management_required' }); const before = { active: person.active }; person.active = input.active; recordAudit(req, input.active ? 'staff.activated' : 'staff.deactivated', 'staff', person.id, before, { active: person.active }); return json(res, 200, person);
  }
  const staffDelete = pathname.match(/^\/api\/staff\/([^/]+)$/);
  if (staffDelete && req.method === 'DELETE') {
    if (denyUnless(req, res, 'staff_manage')) return;
    if (String(req.user?.id || '') === staffDelete[1]) return json(res, 409, { error: 'self_deactivation_forbidden' });
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(staffDelete[1])) { try { const { rows } = await repositories.pool.query(`UPDATE users SET is_active=false WHERE id=$1 AND venue_id=$2 AND role <> 'owner' AND is_active=true RETURNING id,full_name AS name,role,is_active AS active,avatar_url AS "avatarUrl"`, [staffDelete[1], venueDbId]); if (!rows[0]) return json(res, 404, { error: 'staff_not_found_or_owner' }); recordAudit(req, 'staff.deactivated', 'staff', rows[0].id, { active: true }, { active: false }); return json(res, 200, rows[0]); } catch (error) { return json(res, 409, { error: 'staff_delete_failed', detail: error.message }); } }
    const person = staff.find((entry) => entry.id === staffDelete[1]);
    if (!person) return json(res, 404, { error: 'staff_not_found' });
    if (person.role === 'owner') return json(res, 409, { error: 'owner_cannot_be_deleted' });
    if (!person.active) return json(res, 409, { error: 'staff_already_inactive' });
    person.active = false; recordAudit(req, 'staff.deactivated', 'staff', person.id, { active: true }, { active: false });
    return json(res, 200, person);
  }
  const staffArchive = pathname.match(/^\/api\/staff\/([^/]+)\/archive$/);
  if (staffArchive && req.method === 'POST') {
    if (denyUnless(req, res, 'staff_manage')) return;
    if (process.env.AUTH_REQUIRED === 'true' && req.user?.role !== 'owner') return json(res, 403, { error: 'staff_archive_owner_required' });
    if (String(req.user?.id || '') === staffArchive[1]) return json(res, 409, { error: 'self_archive_forbidden' });
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(staffArchive[1])) {
      try {
        const { rows } = await repositories.pool.query(`UPDATE users SET is_active=false,deleted_at=now() WHERE id=$1 AND venue_id=$2 AND role <> 'owner' AND is_active=false AND deleted_at IS NULL RETURNING id,full_name AS name,role,is_active AS active,deleted_at AS "archivedAt"`, [staffArchive[1], venueDbId]);
        if (!rows[0]) return json(res, 404, { error: 'staff_not_found_or_owner' });
        recordAudit(req, 'staff.archived', 'staff', rows[0].id, { active: true }, { active: false, archivedAt: rows[0].archivedAt });
        return json(res, 200, rows[0]);
      } catch (error) { return json(res, 409, { error: 'staff_archive_failed', detail: error.message }); }
    }
    const index = staff.findIndex((person) => person.id === staffArchive[1]);
    const person = staff[index];
    if (!person || person.role === 'owner' || person.active || person.deletedAt) return json(res, 409, { error: 'staff_must_be_blocked_before_archive' });
    person.active = false; person.deletedAt = new Date().toISOString();
    recordAudit(req, 'staff.archived', 'staff', person.id, { active: true }, { active: false, archivedAt: person.deletedAt });
    return json(res, 200, { id: person.id, name: person.name, role: person.role, active: false, archivedAt: person.deletedAt });
  }
  const staffAvatar = pathname.match(/^\/api\/staff\/([^/]+)\/avatar$/);
  if (staffAvatar && req.method === 'POST') {
    if (!hasPermission(req, 'staff_manage') && String(req.user?.id || '') !== staffAvatar[1]) return json(res, 403, { error: 'forbidden', permission: 'staff' });
    const input = await body(req); if (!validImageData(input.imageData)) return json(res, 400, { error: 'invalid_avatar' });
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(staffAvatar[1])) { try { const { rows } = await repositories.pool.query(`UPDATE users SET avatar_url=$1 WHERE id=$2 AND venue_id=$3 RETURNING id,full_name AS name,role,is_active AS active,avatar_url AS "avatarUrl"`, [input.imageData, staffAvatar[1], venueDbId]); if (!rows[0]) return json(res, 404, { error: 'staff_not_found' }); recordAudit(req, 'staff.avatar_updated', 'staff', rows[0].id, { avatarUrl: '[image]' }, { avatarUrl: '[image]' }); return json(res, 200, rows[0]); } catch (error) { return json(res, 409, { error: 'staff_avatar_failed', detail: error.message }); } }
    const person = staff.find((entry) => entry.id === staffAvatar[1]); if (!person) return json(res, 404, { error: 'staff_not_found' });
    const hadAvatar = Boolean(person.avatarUrl); person.avatarUrl = input.imageData; recordAudit(req, 'staff.avatar_updated', 'staff', person.id, { avatarUrl: hadAvatar ? '[image]' : null }, { avatarUrl: '[image]' }); return json(res, 200, person);
  }
  const staffProfile = pathname.match(/^\/api\/staff\/([^/]+)\/profile$/);
  const staffPinPath = pathname.match(/^\/api\/staff\/([^/]+)\/pin$/);
  if (staffPinPath && req.method === 'PATCH') {
    const personId = staffPinPath[1]; const isSelf = String(req.user?.id || '') === personId;
    if (!isSelf && denyUnless(req, res, 'staff_manage')) return;
    const input = await body(req); const pin = String(input.pin || '').trim();
    if (!/^\d{4}$/.test(pin)) return json(res, 400, { error: 'invalid_staff_pin_format' });
    const memoryPerson = staff.find((entry) => entry.id === personId);
    if (memoryPerson) {
      if (!memoryPerson.active || memoryPerson.deletedAt) return json(res, 404, { error: 'staff_not_found' });
      memoryPerson.pinHash = await hashPassword(pin); memoryPerson.pinCode = null; memoryPerson.pinConfigured = true; memoryPerson.pinUpdatedAt = new Date().toISOString();
      for (const session of sessions.values()) if (String(session.user?.id || '') === personId) { session.unlockHash = memoryPerson.pinHash; session.user.pinConfigured = true; }
      const notification = { id: `staff-pin-${crypto.randomUUID()}`, venueId: notificationVenueScope(req, venueDbId), type: 'staff_pin_updated', staffId: personId, staffName: memoryPerson.name, actor: req.user?.name || 'сотрудник', createdAt: memoryPerson.pinUpdatedAt, notificationRecipients: ['owner', 'admin'] };
      staffNotifications.push(notification); recordAudit(req, 'staff.pin_updated', 'staff', personId, { pinConfigured: true }, { pinConfigured: true, notificationRecipients: ['owner', 'admin'] });
      return json(res, 200, { id: personId, pinConfigured: true, pinUpdatedAt: memoryPerson.pinUpdatedAt });
    }
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(personId)) {
      try {
        // PIN verification only needs the one-way hash. It must remain usable when
        // optional passport encryption is not configured for the venue.
        const { rows } = await repositories.pool.query('UPDATE users SET pin_hash=$1,pin_data_encrypted=NULL,pin_data_iv=NULL,pin_data_tag=NULL,pin_updated_at=now() WHERE id=$2 AND venue_id=$3 AND is_active=true AND deleted_at IS NULL RETURNING id,full_name AS name,pin_updated_at AS "pinUpdatedAt"', [await hashPassword(pin), personId, venueDbId]);
        if (!rows[0]) return json(res, 404, { error: 'staff_not_found' });
        for (const session of sessions.values()) if (String(session.user?.id || '') === personId) { session.unlockHash = null; session.user.pinConfigured = true; }
        recordAudit(req, 'staff.pin_updated', 'staff', personId, { pinConfigured: true }, { pinConfigured: true, notificationRecipients: ['owner', 'admin'] });
        return json(res, 200, { id: rows[0].id, pinConfigured: true, pinUpdatedAt: rows[0].pinUpdatedAt });
      } catch (error) { return json(res, 409, { error: 'staff_pin_save_failed', detail: error.message }); }
    }
    return json(res, 404, { error: 'staff_not_found' });
  }
if (staffProfile && req.method === 'GET') {
  const personId = staffProfile[1];
  const canRead = hasPermission(req, 'staff') || hasPermission(req, 'staff_view') || String(req.user?.id || '') === personId;
  if (!canRead) return json(res, 403, { error: 'forbidden', permission: 'staff_view' });
  if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(personId)) {
    try {
      const { rows } = await repositories.pool.query('SELECT id,full_name AS name,login,contact_email AS email,role,is_active AS active,avatar_url AS "avatarUrl",photo_url AS "photoUrl",birth_date::text AS "birthDate",telegram_url AS telegram,phone_numbers AS "phoneNumbers",permission_scopes AS "permissionScopes",custom_role_id AS "customRoleId",employment_started_at::text AS "employmentStartedAt",work_notes AS "workNotes",pin_updated_at AS "pinUpdatedAt",passport_data_encrypted,passport_data_iv,passport_data_tag FROM users WHERE id=$1 AND venue_id=$2 AND deleted_at IS NULL LIMIT 1', [personId, venueDbId]);
      if (!rows[0]) return json(res, 404, { error: 'staff_not_found' });
      const profile = { ...rows[0], pinConfigured: Boolean(rows[0].pinUpdatedAt), workspacePermissions: effectivePermissions({ role: rows[0].role, customRolePermissionScopes: rows[0].customRolePermissionScopes, permissionScopes: rows[0].permissionScopes }) };
      if (canSeeSensitiveStaff(req)) profile.passportData = staffPassportCipher.decrypt(rows[0]);
      if (!canSeeStaffPhoto(req)) delete profile.photoUrl;
      delete profile.passport_data_encrypted; delete profile.passport_data_iv; delete profile.passport_data_tag;
      return json(res, 200, profile);
    } catch (error) {
      // Keep migration 002 contact data available when the employment migration is not applied yet.
      try {
        const { rows } = await repositories.pool.query('SELECT id,full_name AS name,login,contact_email AS email,role,is_active AS active,avatar_url AS "avatarUrl",photo_url AS "photoUrl",birth_date::text AS "birthDate",telegram_url AS telegram,phone_numbers AS "phoneNumbers",passport_data_encrypted,passport_data_iv,passport_data_tag FROM users WHERE id=$1 AND venue_id=$2 AND deleted_at IS NULL LIMIT 1', [personId, venueDbId]);
        if (!rows[0]) return json(res, 404, { error: 'staff_not_found' });
        const profile = { ...rows[0], permissionScopes: [], employmentStartedAt: null, workNotes: '', workspacePermissions: effectivePermissions({ role: rows[0].role, permissionScopes: [] }) };
        if (canSeeSensitiveStaff(req)) profile.passportData = staffPassportCipher.decrypt(rows[0]);
        if (!canSeeStaffPhoto(req)) delete profile.photoUrl;
        delete profile.passport_data_encrypted; delete profile.passport_data_iv; delete profile.passport_data_tag;
        return json(res, 200, profile);
      } catch (_) {
        try {
          const { rows } = await repositories.pool.query('SELECT id,full_name AS name,login,contact_email AS email,role,is_active AS active,avatar_url AS "avatarUrl" FROM users WHERE id=$1 AND venue_id=$2 AND deleted_at IS NULL LIMIT 1', [personId, venueDbId]);
          if (!rows[0]) return json(res, 404, { error: 'staff_not_found' });
          return json(res, 200, { ...rows[0], telegram: null, phoneNumbers: [], permissionScopes: [], employmentStartedAt: null, workNotes: '', workspacePermissions: effectivePermissions({ role: rows[0].role, permissionScopes: [] }) });
        } catch (fallbackError) { return json(res, 409, { error: 'staff_profile_read_failed', detail: fallbackError.message }); }
      }
    }
  }
  const person = staff.find((entry) => entry.id === personId);
  if (!person) return json(res, 404, { error: 'staff_not_found' });
  const profile = { ...person, workspacePermissions: effectivePermissions(person) }; if (!canSeeSensitiveStaff(req)) delete profile.passportData; if (!canSeeStaffPhoto(req)) delete profile.photoUrl;
  return json(res, 200, profile);
}
if (staffProfile && req.method === 'PATCH') {
  const personId = staffProfile[1];
  const canManage = hasPermission(req, 'staff_manage');
  const canManageSensitive = canSeeSensitiveStaff(req);
  const isSelf = String(req.user?.id || '') === personId;
  if (!canManage && !isSelf) return json(res, 403, { error: 'forbidden', permission: 'staff' });
  const input = await body(req);
  const memoryPerson = staff.find((entry) => entry.id === personId);
  let before = memoryPerson ? { ...memoryPerson, phoneNumbers: Array.isArray(memoryPerson.phoneNumbers) ? memoryPerson.phoneNumbers.map((phone) => ({ ...phone })) : [] } : null;
  if (!before && repositories?.pool && /^[0-9a-f-]{36}$/i.test(personId)) {
    try {
      const { rows } = await repositories.pool.query('SELECT id,full_name AS name,login,contact_email AS email,role,is_active AS active,avatar_url AS "avatarUrl",photo_url AS "photoUrl",birth_date::text AS "birthDate",telegram_url AS telegram,phone_numbers AS "phoneNumbers",permission_scopes AS "permissionScopes",custom_role_id AS "customRoleId",employment_started_at::text AS "employmentStartedAt",work_notes AS "workNotes" FROM users WHERE id=$1 AND venue_id=$2 AND deleted_at IS NULL LIMIT 1', [personId, venueDbId]);
      before = rows[0] || null;
    } catch (_) {}
  }
  if (!before) return json(res, 404, { error: 'staff_not_found' });
  const selfContactOnly = isSelf && Object.keys(input).every((key) => key === 'email');
  if (!selfContactOnly && !canManageStaffTarget(req, before.role)) return json(res, 403, { error: before.role === 'owner' ? 'owner_staff_protected' : (req.user?.role === 'admin' && ['admin','developer'].includes(before.role) ? 'staff_role_assignment_required' : 'staff_management_required') });
  const nextLogin = input.login === undefined ? undefined : (typeof input.login === 'string' ? input.login.trim() : null);
  if (nextLogin !== undefined && (nextLogin === null || !/^[A-Za-zА-Яа-яЁё0-9_-]{3,32}$/.test(nextLogin))) return json(res, 400, { error: 'invalid_staff_login' });
  const nextEmail = input.email === undefined ? undefined : (input.email === null ? null : (typeof input.email === 'string' ? input.email.trim() : '__invalid_email_type__'));
  if (nextEmail !== undefined && (nextEmail === '__invalid_email_type__' || (nextEmail !== null && nextEmail.length > 254) || (nextEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(nextEmail)))) return json(res, 400, { error: 'invalid_staff_email' });
  const normalizedEmail = nextEmail ? nextEmail.replace(/@([^@]+)$/, (_, domain) => `@${domain.toLowerCase()}`) : null;
  const currentLogin = before.login;
  if (nextLogin !== undefined && ['admin', 'owner', 'staff', String(process.env.SAAS_OWNER_EMAIL || '').trim().toLowerCase()].includes(nextLogin.toLowerCase())) return json(res, 409, { error: 'reserved_staff_login' });
  if (nextLogin !== undefined && nextLogin !== currentLogin && repositories?.pool) {
    const duplicate = await repositories.pool.query('SELECT 1 FROM users WHERE login=$1 AND id<>$2 LIMIT 1', [nextLogin, personId]);
    if (duplicate.rowCount) return json(res, 409, { error: 'login_already_exists' });
    try {
      await repositories.pool.query('INSERT INTO audit_events (venue_id,actor_id,action,entity_type,entity_id,before_data,after_data) VALUES ($1,$2,$3,$4,$5,$6::jsonb,$7::jsonb)', [venueDbId, /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null, 'staff.login_updated', 'staff', personId, JSON.stringify({ login: currentLogin }), JSON.stringify({ login: nextLogin })]);
    } catch (error) { return json(res, 503, { error: 'staff_profile_save_failed', detail: error.message }); }
  }
  const auditBefore = { ...before, phoneNumbers: Array.isArray(before.phoneNumbers) ? before.phoneNumbers.map((phone) => ({ ...phone })) : [] };
  if (!canManageSensitive) delete auditBefore.passportData;
  if (input.name !== undefined && !canManage) return json(res, 403, { error: 'staff_management_required' });
  if (input.role !== undefined && !canManage) return json(res, 403, { error: 'staff_management_required' });
  if (input.name !== undefined && (!String(input.name).trim() || String(input.name).trim().length > 120)) return json(res, 400, { error: 'invalid_staff_name' });
  if (input.role !== undefined && (!rolePermissions[input.role] || input.role === 'owner')) return json(res, 400, { error: 'invalid_staff_role' });
  if (input.role !== undefined && !canAssignStaffRole(req, input.role)) return json(res, 403, { error: 'staff_role_assignment_required' });
  if (input.permissionScopes !== undefined && (!Array.isArray(input.permissionScopes) || normalizePermissionScopes(input.permissionScopes).length !== new Set(input.permissionScopes).size)) return json(res, 400, { error: 'invalid_permission_scopes' });
  if (input.permissionScopes !== undefined && process.env.AUTH_REQUIRED === 'true' && req.user?.role !== 'owner') return json(res, 403, { error: 'permission_scopes_owner_required' });
  if (input.customRoleId !== undefined && (req.user?.role !== 'owner' || before.role === 'owner')) return json(res, 403, { error: 'custom_role_owner_required' });
  if (input.customRoleId !== undefined && input.customRoleId !== null && !/^[0-9a-f-]{36}$/i.test(String(input.customRoleId))) return json(res, 400, { error: 'custom_role_id_invalid' });
  if (input.customRoleId !== undefined) before.customRoleId = input.customRoleId || null;
  if (input.employmentStartedAt !== undefined && !canManage) return json(res, 403, { error: 'staff_management_required' });
  if (input.birthDate !== undefined && !canManage) return json(res, 403, { error: 'staff_management_required' });
  if (input.workNotes !== undefined && !canManage) return json(res, 403, { error: 'staff_management_required' });
  if (input.birthDate !== undefined && !validBirthDate(input.birthDate)) return json(res, 400, { error: 'invalid_birth_date' });
  if (input.employmentStartedAt !== undefined && !validEmploymentDate(input.employmentStartedAt)) return json(res, 400, { error: 'invalid_employment_date' });
  if (input.workNotes !== undefined && String(input.workNotes).length > 4000) return json(res, 400, { error: 'work_notes_too_long' });
  if (input.telegram !== undefined && input.telegram && !/^(@[A-Za-z0-9_]{5,32}|https:\/\/t\.me\/[A-Za-z0-9_]{5,32}\/?$)/.test(String(input.telegram).trim())) return json(res, 400, { error: 'invalid_telegram' });
  if (input.phoneNumbers !== undefined && (!Array.isArray(input.phoneNumbers) || input.phoneNumbers.length > 5 || input.phoneNumbers.some((entry) => !entry || !/^\+7[0-9 ()-]{7,24}$/.test(String(entry.number || '').trim())))) return json(res, 400, { error: 'invalid_phone_numbers' });
  if (input.passportData !== undefined && !canManageSensitive) return json(res, 403, { error: 'sensitive_staff_permission_required' });
  const clearPassportRequested = input.passportData?.clear === true;
  if (clearPassportRequested && req.user?.role !== 'owner') return json(res, 403, { error: 'staff_passport_clear_owner_required' });
  if (input.avatarUrl !== undefined) {
    if (input.avatarUrl && !validImageData(input.avatarUrl)) return json(res, 400, { error: 'invalid_avatar' });
    before.avatarUrl = input.avatarUrl || null;
  }
  if (input.photoUrl !== undefined && !canSeeStaffPhoto(req)) return json(res, 403, { error: 'staff_photo_permission_required' });
  if (input.photoUrl && !validImageData(input.photoUrl)) return json(res, 400, { error: 'invalid_staff_photo' });
  if (input.name !== undefined) before.name = String(input.name).trim();
  if (input.role !== undefined) before.role = input.role;
  if (nextLogin !== undefined) before.login = nextLogin;
  if (nextEmail !== undefined) before.email = normalizedEmail;
  if (input.permissionScopes !== undefined) before.permissionScopes = normalizePermissionScopes(input.permissionScopes);
  if (input.telegram !== undefined) before.telegram = String(input.telegram || '').trim();
  if (input.employmentStartedAt !== undefined) before.employmentStartedAt = input.employmentStartedAt || null;
  if (input.birthDate !== undefined) before.birthDate = input.birthDate || null;
  if (input.photoUrl !== undefined) before.photoUrl = input.photoUrl || null;
  if (input.workNotes !== undefined) before.workNotes = String(input.workNotes || '').slice(0, 4000);
  let contactJson = null;
  if (input.phoneNumbers !== undefined) {
    const contacts = normalizePhoneNumbers(input.phoneNumbers);
    if (contacts.length && contacts.filter((entry) => entry.primary).length !== 1) return json(res, 400, { error: 'one_primary_phone_required' });
    before.phoneNumbers = contacts;
    contactJson = JSON.stringify(contacts);
  }
  const clearPassportData = clearPassportRequested && canManageSensitive;
  const hasPassportData = input.passportData !== undefined && input.passportData && typeof input.passportData === 'object' && ['number', 'issuedAt', 'issuer'].some((key) => String(input.passportData[key] || '').trim());
  if (clearPassportData) before.passportData = null; else if (hasPassportData) before.passportData = input.passportData;
  const encryptedPassport = hasPassportData && canManageSensitive ? staffPassportCipher.encrypt(input.passportData) : null;
  if (hasPassportData && repositories?.pool && canManageSensitive && !encryptedPassport) return json(res, 503, { error: 'staff_passport_key_required' });
  if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(personId)) {
    try {
      try { await repositories.pool.query('UPDATE users SET avatar_url=CASE WHEN $1 THEN $2 ELSE avatar_url END,photo_url=CASE WHEN $3 THEN $4 ELSE photo_url END,birth_date=CASE WHEN $5 THEN $6::date ELSE birth_date END,telegram_url=CASE WHEN $7 THEN $8 ELSE telegram_url END,phone_numbers=CASE WHEN $9 THEN $10::jsonb ELSE phone_numbers END,employment_started_at=CASE WHEN $11 THEN $12::date ELSE employment_started_at END,work_notes=CASE WHEN $13 THEN $14 ELSE work_notes END,passport_data_encrypted=CASE WHEN $24 THEN NULL ELSE COALESCE($15,passport_data_encrypted) END,passport_data_iv=CASE WHEN $24 THEN NULL ELSE COALESCE($16,passport_data_iv) END,passport_data_tag=CASE WHEN $24 THEN NULL ELSE COALESCE($17,passport_data_tag) END,full_name=CASE WHEN $18 THEN $19 ELSE full_name END,role=CASE WHEN $20 THEN $21 ELSE role END WHERE id=$22 AND venue_id=$23', [input.avatarUrl !== undefined, input.avatarUrl || null, input.photoUrl !== undefined, input.photoUrl || null, input.birthDate !== undefined, input.birthDate || null, input.telegram !== undefined, input.telegram !== undefined ? (input.telegram || null) : null, input.phoneNumbers !== undefined, contactJson || '[]', input.employmentStartedAt !== undefined, input.employmentStartedAt || null, input.workNotes !== undefined, input.workNotes !== undefined ? String(input.workNotes || '').slice(0, 4000) : null, encryptedPassport?.data || null, encryptedPassport?.iv || null, encryptedPassport?.tag || null, input.name !== undefined, before.name, input.role !== undefined, before.role, personId, venueDbId, clearPassportData]); } catch (_) {
        await repositories.pool.query('UPDATE users SET avatar_url=CASE WHEN $1 THEN $2 ELSE avatar_url END,photo_url=CASE WHEN $3 THEN $4 ELSE photo_url END,birth_date=CASE WHEN $5 THEN $6::date ELSE birth_date END,telegram_url=CASE WHEN $7 THEN $8 ELSE telegram_url END,phone_numbers=CASE WHEN $9 THEN $10::jsonb ELSE phone_numbers END,passport_data_encrypted=CASE WHEN $20 THEN NULL ELSE COALESCE($11,passport_data_encrypted) END,passport_data_iv=CASE WHEN $20 THEN NULL ELSE COALESCE($12,passport_data_iv) END,passport_data_tag=CASE WHEN $20 THEN NULL ELSE COALESCE($13,passport_data_tag) END,full_name=CASE WHEN $14 THEN $15 ELSE full_name END,role=CASE WHEN $16 THEN $17 ELSE role END WHERE id=$18 AND venue_id=$19', [input.avatarUrl !== undefined, input.avatarUrl || null, input.photoUrl !== undefined, input.photoUrl || null, input.birthDate !== undefined, input.birthDate || null, input.telegram !== undefined, input.telegram !== undefined ? (input.telegram || null) : null, input.phoneNumbers !== undefined, contactJson || '[]', encryptedPassport?.data || null, encryptedPassport?.iv || null, encryptedPassport?.tag || null, input.name !== undefined, before.name, input.role !== undefined, before.role, personId, venueDbId, clearPassportData]);
      }
      if (nextLogin !== undefined || nextEmail !== undefined) {
        if (nextLogin !== undefined && nextLogin !== currentLogin) {
          const duplicate = await repositories.pool.query('SELECT 1 FROM users WHERE login=$1 AND id<>$2 LIMIT 1', [nextLogin, personId]);
          if (duplicate.rowCount) return json(res, 409, { error: 'login_already_exists' });
        }
        try {
          await repositories.pool.query('UPDATE users SET login=COALESCE($1,login),contact_email=CASE WHEN $2 THEN $3 ELSE contact_email END WHERE id=$4 AND venue_id=$5', [nextLogin, nextEmail !== undefined, normalizedEmail, personId, venueDbId]);
          if (nextLogin !== undefined && nextLogin !== currentLogin) {
            await repositories.pool.query('DELETE FROM auth_sessions WHERE user_id=$1', [personId]);
            for (const [sessionToken, session] of sessions) if (String(session.user?.id || '') === personId) sessions.delete(sessionToken);
          }
        } catch (error) { if (error.code === '23505') return json(res, 409, { error: 'login_already_exists' }); throw error; }
      }
      if (input.permissionScopes !== undefined) { await repositories.pool.query('UPDATE users SET permission_scopes=$1::jsonb WHERE id=$2 AND venue_id=$3', [JSON.stringify(before.permissionScopes || []), personId, venueDbId]); }
      if (input.customRoleId !== undefined) { await repositories.pool.query('UPDATE users SET custom_role_id=$1::uuid WHERE id=$2 AND venue_id=$3', [input.customRoleId || null, personId, venueDbId]); }
    } catch (error) { return json(res, 409, { error: 'staff_profile_save_failed', detail: error.message }); }
  }
  if (memoryPerson) Object.assign(memoryPerson, before);
  const publicPerson = { ...before };
  if (!canManageSensitive) delete publicPerson.passportData;
  if (!canSeeStaffPhoto(req)) delete publicPerson.photoUrl;
  recordAudit(req, 'staff.profile_updated', 'staff', before.id, auditBefore, publicPerson);
  return json(res, 200, publicPerson);
}
  if (pathname === '/api/staff/schedule' && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['staff_manage', 'staff_view'])) return;
    const from = url.searchParams.get('from') || today(); const to = url.searchParams.get('to') || from;
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query('SELECT s.*,u.full_name AS "userName" FROM staff_schedules s JOIN users u ON u.id=s.user_id AND u.venue_id=s.venue_id WHERE s.venue_id=$1 AND s.work_date BETWEEN $2::date AND $3::date ORDER BY s.work_date,s.planned_start', [venueDbId, from, to]); return json(res, 200, { items: rows }); } catch (error) { return json(res, 503, { error: 'schedule_unavailable', detail: error.message }); } }
    return json(res, 200, { items: [] });
  }
  if (pathname === '/api/inventory/subdepartments' && req.method === 'GET') {
    if (denyUnless(req, res, 'inventory_read')) return;
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query('SELECT id,department_code AS "departmentCode",name,is_active AS active FROM inventory_subdepartments WHERE venue_id=$1 AND is_active=true ORDER BY department_code,name', [venueDbId]); return json(res, 200, { items: rows }); } catch (_) {} }
    return json(res, 200, { items: inventorySubdepartments.filter((item) => item.active) });
  }
  if (pathname === '/api/inventory/subdepartments' && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req); const name = String(input.name || '').trim(); const departmentCode = String(input.departmentCode || '').trim();
    if (!name || name.length > 80 || !departmentCode || departmentCode.length > 48) return json(res, 400, { error: 'invalid_inventory_subdepartment' });
    if (repositories?.pool) { let client; let checkingParent = true; try { client = await repositories.pool.connect(); await client.query('BEGIN'); const departmentResult = await client.query('SELECT 1 FROM inventory_departments WHERE venue_id=$1 AND code=$2 AND is_active=true FOR UPDATE', [venueDbId, departmentCode]); checkingParent = false; if (!departmentResult.rows[0]) { await client.query('ROLLBACK'); return json(res, 400, { error: 'inventory_department_not_found' }); } const { rows } = await client.query('INSERT INTO inventory_subdepartments (venue_id,department_code,name) VALUES ($1,$2,$3) RETURNING id,department_code AS "departmentCode",name,is_active AS active', [venueDbId, departmentCode, name]); await client.query('COMMIT'); recordAudit(req, 'inventory.subdepartment_created', 'inventory_subdepartment', rows[0].id, null, rows[0]); return json(res, 201, rows[0]); } catch (error) { await client?.query('ROLLBACK').catch(() => {}); if (checkingParent) return json(res, 503, { error: 'inventory_hierarchy_unavailable' }); return json(res, 409, { error: error.code === '23505' ? 'inventory_subdepartment_exists' : 'inventory_subdepartment_create_failed' }); } finally { client?.release(); } }
    if (inventorySubdepartments.some((item) => item.active && item.departmentCode === departmentCode && item.name.toLocaleLowerCase('ru-RU') === name.toLocaleLowerCase('ru-RU'))) return json(res, 409, { error: 'inventory_subdepartment_exists' });
    const created = { id: `subdepartment-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, departmentCode, name, active: true }; inventorySubdepartments.push(created); return json(res, 201, created);
  }
  const inventorySubdepartmentPath = pathname.match(/^\/api\/inventory\/subdepartments\/([^/]+)$/);
  if (inventorySubdepartmentPath && req.method === 'PATCH') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req); const id = decodeURIComponent(inventorySubdepartmentPath[1]); const name = String(input.name || '').trim(); const departmentCode = String(input.departmentCode || '').trim();
    if (!name || name.length > 80 || !departmentCode || departmentCode.length > 48) return json(res, 400, { error: 'invalid_inventory_subdepartment' });
    if (repositories?.pool) {
      let client;
      let updated;
      let before;
      let checkingParent = true;
      try {
        client = await repositories.pool.connect();
        await client.query('BEGIN');
        const departmentResult = await client.query('SELECT 1 FROM inventory_departments WHERE venue_id=$1 AND code=$2 AND is_active=true FOR UPDATE', [venueDbId, departmentCode]);
        checkingParent = false;
        if (!departmentResult.rows[0]) { await client.query('ROLLBACK'); return json(res, 400, { error: 'inventory_department_not_found' }); }
        const current = await client.query('SELECT id,department_code AS "departmentCode",name FROM inventory_subdepartments WHERE venue_id=$1 AND id=$2 AND is_active=true FOR UPDATE', [venueDbId, id]);
        before = current.rows[0];
        if (!before) { await client.query('ROLLBACK'); return json(res, 404, { error: 'inventory_subdepartment_not_found' }); }
        const result = await client.query('UPDATE inventory_subdepartments SET name=$1,department_code=$2 WHERE venue_id=$3 AND id=$4 AND is_active=true RETURNING id,department_code AS "departmentCode",name,is_active AS active', [name, departmentCode, venueDbId, id]);
        updated = result.rows[0];
        if (!updated) { await client.query('ROLLBACK'); return json(res, 404, { error: 'inventory_subdepartment_not_found' }); }
        if (before.name !== name || before.departmentCode !== departmentCode) {
          if (before.departmentCode !== departmentCode) await client.query('UPDATE product_categories SET department=$1 WHERE venue_id=$2 AND subdepartment_id=$3 AND is_active=true', [departmentCode, venueDbId, id]);
          await client.query('UPDATE ingredients SET subdepartment=$1,department=$2 WHERE venue_id=$3 AND subdepartment=$4 AND department=$5 AND is_marked=true', [name, departmentCode, venueDbId, before.name, before.departmentCode]);
        }
        await client.query('COMMIT');
      } catch (error) {
        if (client) await client.query('ROLLBACK').catch(() => {});
        if (checkingParent) return json(res, 503, { error: 'inventory_hierarchy_unavailable' });
        return json(res, 409, { error: error.code === '23505' ? 'inventory_subdepartment_exists' : 'inventory_subdepartment_update_failed' });
      } finally { client?.release(); }
      recordAudit(req, 'inventory.subdepartment_updated', 'inventory_subdepartment', id, before, updated);
      return json(res, 200, updated);
    }
    const memoryItem = inventorySubdepartments.find((item) => item.id === id && item.active);
    if (!memoryItem) return json(res, 404, { error: 'inventory_subdepartment_not_found' });
    if (inventorySubdepartments.some((item) => item.active && item.id !== id && item.departmentCode === departmentCode && item.name.toLocaleLowerCase('ru-RU') === name.toLocaleLowerCase('ru-RU'))) return json(res, 409, { error: 'inventory_subdepartment_exists' });
    const before = { ...memoryItem };
    Object.assign(memoryItem, { departmentCode, name });
    for (const category of productCategories) if (category.active && category.subdepartmentId === id) category.department = departmentCode;
    for (const item of inventory) if (item.department === before.departmentCode && item.subdepartment === before.name) Object.assign(item, { department: departmentCode, subdepartment: name });
    return json(res, 200, memoryItem);
  }
  if (inventorySubdepartmentPath && req.method === 'DELETE') {
    if (denyUnless(req, res, 'inventory')) return;
    const id = decodeURIComponent(inventorySubdepartmentPath[1]); if (repositories?.pool) { const client = await repositories.pool.connect(); try { await client.query('BEGIN'); const current = await client.query('SELECT id,department_code AS "departmentCode",name FROM inventory_subdepartments WHERE venue_id=$1 AND id=$2 AND is_active=true FOR UPDATE', [venueDbId, id]); if (!current.rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'inventory_subdepartment_not_found' }); } const used = await client.query('SELECT EXISTS(SELECT 1 FROM ingredients WHERE venue_id=$1 AND department=$2 AND subdepartment=$3 AND is_marked=true) OR EXISTS(SELECT 1 FROM product_categories WHERE venue_id=$1 AND subdepartment_id=$4 AND is_active=true) AS used', [venueDbId, current.rows[0].departmentCode, current.rows[0].name, id]); if (used.rows[0]?.used) { await client.query('ROLLBACK'); return json(res, 409, { error: 'inventory_subdepartment_in_use' }); } const { rows } = await client.query('UPDATE inventory_subdepartments SET is_active=false WHERE venue_id=$1 AND id=$2 AND is_active=true RETURNING id,name,is_active AS active', [venueDbId, id]); if (!rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'inventory_subdepartment_not_found' }); } await client.query('COMMIT'); recordAudit(req, 'inventory.subdepartment_archived', 'inventory_subdepartment', id, { active: true }, rows[0]); return json(res, 200, rows[0]); } catch (_) { await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'inventory_subdepartment_archive_failed' }); } finally { client.release(); } }
    const memoryItem = inventorySubdepartments.find((item) => item.id === id && item.active); if (!memoryItem) return json(res, 404, { error: 'inventory_subdepartment_not_found' }); if (productCategories.some((item) => item.active && item.subdepartmentId === id) || inventory.some((item) => item.department === memoryItem.departmentCode && item.subdepartment === memoryItem.name)) return json(res, 409, { error: 'inventory_subdepartment_in_use' }); memoryItem.active = false; return json(res, 200, { id, active: false });
  }
  const recipeCostPath = pathname.match(/^\/api\/recipes\/([^/]+)\/cost$/);
  if (recipeCostPath && req.method === 'GET') {
    if (denyUnless(req, res, 'inventory_read')) return;
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(recipeCostPath[1])) { try { const { rows } = await repositories.pool.query('SELECT id,name,ingredients,yield_quantity AS "yieldQuantity",yield_unit AS "yieldUnit",portion_count AS "portionCount" FROM inventory_recipe_cards WHERE id=$1 AND venue_id=$2 AND active=true', [recipeCostPath[1], venueDbId]); const recipe = rows[0]; if (!recipe) return json(res, 404, { error: 'recipe_not_found' }); const stock = (await repositories.inventory.list(venueDbId)).items; const lines = calculateRecipeCostLines(recipe.ingredients, stock); const totalCost = Math.round(lines.reduce((sum, line) => sum + line.cost, 0) * 100) / 100; const portionCount = Math.max(1, Number(recipe.portionCount || 1)); return json(res, 200, { recipeId: recipe.id, yieldQuantity: Number(recipe.yieldQuantity), yieldUnit: recipe.yieldUnit, portionCount, lines, totalCost, costPerPortion: Math.round((totalCost / portionCount) * 100) / 100, missing: lines.filter((line) => !line.linked) }); } catch (error) { if (error.code === 'recipe_ingredient_unit_mismatch' || error.code === 'invalid_recipe_quantity') return json(res, 409, { error: error.code, ingredient: error.ingredient, sourceUnit: error.sourceUnit, targetUnit: error.targetUnit }); return json(res, 503, { error: 'recipe_cost_unavailable', detail: error.message }); } }
    const recipe = recipes.find((item) => item.id === recipeCostPath[1]); if (!recipe) return json(res, 404, { error: 'recipe_not_found' });
    const stock = repositories?.inventory ? (await repositories.inventory.list(venueDbId)).items : inventory;
    let lines; try { lines = calculateRecipeCostLines(recipe.ingredients, stock); } catch (error) { return json(res, 409, { error: error.code || 'recipe_cost_invalid', ingredient: error.ingredient, sourceUnit: error.sourceUnit, targetUnit: error.targetUnit }); }
    const totalCost = Math.round(lines.reduce((sum, line) => sum + line.cost, 0) * 100) / 100; const portionCount = Math.max(1, Number(recipe.portionCount || 1)); return json(res, 200, { recipeId: recipe.id, yieldQuantity: Number(recipe.yieldQuantity || 1), yieldUnit: recipe.yieldUnit || 'порция', portionCount, lines, totalCost, costPerPortion: Math.round((totalCost / portionCount) * 100) / 100, missing: lines.filter((line) => !line.linked) });
  }
  if (pathname === '/api/staff/schedule' && req.method === 'POST') {
    if (denyUnless(req, res, 'staff_manage')) return;
    const input = await body(req); const userId = String(input.userId || '').trim(); const workDate = String(input.workDate || '').trim(); const plannedStart = input.plannedStart === '' || input.plannedStart == null ? null : input.plannedStart; const plannedEnd = input.plannedEnd === '' || input.plannedEnd == null ? null : input.plannedEnd;
    if (!userId || !isValidIsoDate(workDate)) return json(res, 400, { error: 'invalid_schedule_entry' });
    if ((plannedStart !== null && !isValidIsoTimestamp(plannedStart)) || (plannedEnd !== null && !isValidIsoTimestamp(plannedEnd)) || (plannedStart !== null && plannedEnd !== null && Date.parse(plannedEnd) <= Date.parse(plannedStart))) return json(res, 400, { error: 'invalid_schedule_time' });
    if (repositories?.pool) { if (!/^[0-9a-f-]{36}$/i.test(userId)) return json(res, 400, { error: 'invalid_schedule_employee' }); try { const employee = await repositories.pool.query('SELECT id FROM users WHERE id=$1 AND venue_id=$2 AND is_active=true AND deleted_at IS NULL', [userId, venueDbId]); if (!employee.rows[0]) return json(res, 404, { error: 'staff_member_not_found' }); const { rows } = await repositories.pool.query('INSERT INTO staff_schedules (venue_id,user_id,work_date,planned_start,planned_end,note,created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT (venue_id,user_id,work_date) DO UPDATE SET planned_start=EXCLUDED.planned_start,planned_end=EXCLUDED.planned_end,note=EXCLUDED.note RETURNING *', [venueDbId, userId, workDate, plannedStart, plannedEnd, String(input.note || '').slice(0,500) || null, req.user?.id || null]); return json(res, 201, rows[0]); } catch (error) { return json(res, 409, { error: 'schedule_save_failed', detail: error.message }); } }
  }
  if (pathname === '/api/staff/time' && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['staff_manage', 'staff_view'])) return;
    let from = url.searchParams.get('from') || ''; let to = url.searchParams.get('to') || '';
    if (repositories?.pool && (!from || !to)) {
      try {
        const localDate = await repositories.pool.query(`SELECT (now() AT TIME ZONE COALESCE(NULLIF(v.timezone,''),NULLIF(org.timezone,''),'Asia/Yekaterinburg'))::date::text AS date FROM venues v LEFT JOIN organizations org ON org.id=v.organization_id WHERE v.id=$1`, [venueDbId]);
        const venueDate = localDate.rows[0]?.date;
        if (!venueDate) return json(res, 503, { error: 'work_time_unavailable' });
        if (!from) from = venueDate;
        if (!to) to = from;
      } catch (error) { return json(res, 503, { error: 'work_time_unavailable', detail: error.message }); }
    } else {
      from ||= today();
      to ||= from;
    }
    if (!isValidIsoDate(from) || !isValidIsoDate(to) || to < from) return json(res, 400, { error: 'invalid_work_time_period' });
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query(`WITH tz AS (SELECT COALESCE(NULLIF(v.timezone,''),NULLIF(org.timezone,''),'Asia/Yekaterinburg') AS name FROM venues v LEFT JOIN organizations org ON org.id=v.organization_id WHERE v.id=$1), bounds AS (SELECT ($2::date::timestamp AT TIME ZONE name) starts_at, (($3::date+1)::timestamp AT TIME ZONE name) ends_at FROM tz), clipped AS (SELECT w.*,u.full_name AS "userName",GREATEST(w.started_at,b.starts_at) starts_at,LEAST(COALESCE(w.ended_at,now()),b.ends_at) ends_at FROM bounds b JOIN staff_work_logs w ON w.venue_id=$1 AND w.started_at < b.ends_at AND COALESCE(w.ended_at,now()) > b.starts_at JOIN users u ON u.id=w.user_id), ordered AS (SELECT *,MAX(ends_at) OVER (PARTITION BY user_id ORDER BY starts_at,ends_at ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) previous_end FROM clipped), merged AS (SELECT *,GREATEST(starts_at,COALESCE(previous_end,starts_at)) effective_start FROM ordered) SELECT id,venue_id,user_id,started_at AS "started_at",ended_at AS "ended_at",source,note,created_at,"userName",COALESCE(GREATEST(0,EXTRACT(EPOCH FROM (ends_at-effective_start))/3600),0)::numeric AS hours FROM merged ORDER BY started_at DESC`, [venueDbId, from, to]); return json(res, 200, { items: rows.map((row) => ({ ...row, hours: Number(Number(row.hours || 0).toFixed(2)) })) }); } catch (error) { return json(res, 503, { error: 'work_time_unavailable', detail: error.message }); } }
    return json(res, 200, { items: [] });
  }
  if (pathname === '/api/staff/time' && req.method === 'POST') {
    if (denyUnless(req, res, 'staff_manage')) return;
    const input = await body(req); const userId = String(input.userId || '').trim(); const startedAt = new Date(input.startedAt || ''); const endedAt = input.endedAt ? new Date(input.endedAt) : null;
    const source = String(input.source || 'manual');
    if (!/^[0-9a-f-]{36}$/i.test(userId) || Number.isNaN(startedAt.getTime()) || (endedAt && Number.isNaN(endedAt.getTime())) || (endedAt && endedAt <= startedAt) || !['manual','shift','device'].includes(source)) return json(res, 400, { error: 'invalid_work_log' });
    if (repositories?.pool) { let client; try { client = await repositories.pool.connect(); await client.query('BEGIN'); const employee = await client.query('SELECT id FROM users WHERE id=$1 AND venue_id=$2 AND is_active=true AND deleted_at IS NULL FOR UPDATE', [userId,venueDbId]); if (!employee.rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'staff_member_not_found' }); } const overlapping = await client.query(`SELECT id FROM staff_work_logs WHERE venue_id=$1 AND user_id=$2 AND started_at < COALESCE($4::timestamptz,'infinity'::timestamptz) AND COALESCE(ended_at,'infinity'::timestamptz) > $3::timestamptz LIMIT 1 FOR UPDATE`, [venueDbId,userId,startedAt.toISOString(),endedAt?.toISOString() || null]); if (overlapping.rows[0]) { await client.query('ROLLBACK'); return json(res, 409, { error: 'work_log_overlaps_existing' }); } const { rows } = await client.query('INSERT INTO staff_work_logs (venue_id,user_id,started_at,ended_at,source,note) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *', [venueDbId,userId,startedAt.toISOString(),endedAt?.toISOString() || null,source,String(input.note || '').slice(0,500) || null]); await client.query('COMMIT'); recordAudit(req, 'staff.work_time_recorded', 'staff', rows[0].user_id, null, rows[0]); return json(res, 201, rows[0]); } catch (error) { await client?.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'work_log_save_failed', detail: error.message }); } finally { client?.release(); } }
  }
  if (pathname === '/api/payroll/rules' && req.method === 'GET') {
    if (denyUnless(req, res, 'finance')) return;
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query('SELECT * FROM payroll_rules WHERE venue_id=$1 ORDER BY active DESC,name', [venueDbId]); return json(res, 200, { items: rows }); } catch (error) { return json(res, 503, { error: 'payroll_rules_unavailable', detail: error.message }); } }
    return json(res, 200, { items: [] });
  }
  if (pathname === '/api/finance/purchase-payables' && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['finance', 'finance_read'])) return;
    if (isOperationalEmployee(req)) return json(res, 403, { error: 'forbidden', permission: 'finance_read' });
    if (!repositories?.purchaseDocuments) return json(res, 503, { error: 'purchase_payables_unavailable' });
    try { return json(res, 200, { items: await repositories.purchaseDocuments.listPayables(venueDbId) }); }
    catch (error) { return json(res, 503, { error: 'purchase_payables_unavailable', detail: error.message }); }
  }
  const purchasePaymentPath = pathname.match(/^\/api\/finance\/purchase-payables\/([^/]+)\/payments$/);
  if (purchasePaymentPath && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['finance', 'finance_read'])) return;
    if (isOperationalEmployee(req)) return json(res, 403, { error: 'forbidden', permission: 'finance_read' });
    if (!repositories?.purchaseDocuments) return json(res, 503, { error: 'purchase_payments_unavailable' });
    const id = decodeURIComponent(purchasePaymentPath[1]);
    if (!/^[0-9a-f-]{36}$/i.test(id)) return json(res, 400, { error: 'invalid_purchase_document_id' });
    try {
      const items = await repositories.purchaseDocuments.listPayments(venueDbId, id);
      return items === null ? json(res, 404, { error: 'purchase_document_not_found' }) : json(res, 200, { items });
    } catch (error) { return json(res, 503, { error: 'purchase_payments_unavailable', detail: error.message }); }
  }
  if (purchasePaymentPath && req.method === 'POST') {
    if (denyUnless(req, res, 'finance')) return;
    if (!repositories?.purchaseDocuments) return json(res, 503, { error: 'purchase_payments_unavailable' });
    const id = decodeURIComponent(purchasePaymentPath[1]);
    if (!/^[0-9a-f-]{36}$/i.test(id)) return json(res, 400, { error: 'invalid_purchase_document_id' });
    const input = await body(req);
    const amount = Number(input.amount);
    const paymentDate = String(input.paymentDate || '');
    const paymentMethod = String(input.paymentMethod || '');
    const idempotencyKey = String(input.idempotencyKey || req.headers['idempotency-key'] || '').trim();
    const documentUrl = String(input.documentUrl || '');
    if (!Number.isFinite(amount) || amount <= 0 || amount > 9999999999.99 || Math.abs(amount * 100 - Math.round(amount * 100)) > 0.00001) return json(res, 400, { error: 'invalid_purchase_payment_amount' });
    if (!isValidIsoDate(paymentDate)) return json(res, 400, { error: 'invalid_purchase_payment_date' });
    if (!['cash','card','bank_transfer','other'].includes(paymentMethod)) return json(res, 400, { error: 'invalid_purchase_payment_method' });
    if (!/^[\w:.-]{8,128}$/.test(idempotencyKey)) return json(res, 400, { error: 'purchase_payment_idempotency_key_required' });
    const documentValidation = validatePurchasePaymentDocument(documentUrl);
    if (!documentValidation.valid) return json(res, 400, { error: documentValidation.error });
    try {
      const result = await repositories.purchaseDocuments.addPayment({ id, venueId: venueDbId, amount, paymentDate, paymentMethod, documentUrl, idempotencyKey, createdBy: /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null });
      if (!result.idempotent) recordAudit(req, 'finance.purchase_payment_created', 'purchase_document', id, null, { expenseId: result.expenseId, amount: result.amount, paymentDate: result.paymentDate, paymentMethod: result.paymentMethod, totalPaid: result.totalPaid, balanceDue: result.balanceDue });
      return json(res, result.idempotent ? 200 : 201, result);
    } catch (error) {
      const statuses = { purchase_document_not_found: 404, purchase_document_not_posted: 409, purchase_payment_exceeds_balance: 409, purchase_payment_idempotency_conflict: 409 };
      return json(res, statuses[error.message] || (error.code === '23505' ? 409 : 503), { error: statuses[error.message] ? error.message : error.code === '23505' ? 'purchase_payment_idempotency_conflict' : 'purchase_payment_save_failed', detail: error.message });
    }
  }
  if (pathname === '/api/expenses' && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['finance', 'finance_read'])) return;
    if (isOperationalEmployee(req)) return json(res, 403, { error: 'forbidden', permission: 'finance_read' });
    const from = url.searchParams.get('from') || '1900-01-01'; const to = url.searchParams.get('to') || '2999-12-31';
    const rawLimit = url.searchParams.get('limit'); const rawOffset = url.searchParams.get('offset');
    const limit = rawLimit === null ? null : Number(rawLimit); const offset = rawOffset === null ? 0 : Number(rawOffset);
    if ((limit !== null && (!Number.isInteger(limit) || limit < 1 || limit > 100)) || !Number.isInteger(offset) || offset < 0 || (limit === null && rawOffset !== null)) return json(res, 400, { error: 'invalid_expense_pagination' });
    if (repositories?.pool) {
      try {
        const values = [venueDbId,from,to,hasPermission(req,'finance')];
        const where = 'WHERE e.venue_id=$1 AND e.expense_date BETWEEN $2::date AND $3::date AND ($4::boolean OR e.source <> \'payroll\')';
        const [countResult, expenseResult] = await Promise.all([
          repositories.pool.query(`SELECT COUNT(*)::int AS count FROM expenses e ${where}`, values),
          repositories.pool.query(`SELECT e.*, CASE WHEN e.source='payroll' THEN COALESCE(payroll.status,'legacy_unmatched') ELSE NULL END AS "payrollStatus", (e.source='payroll' AND NOT EXISTS (SELECT 1 FROM payroll_entries pe WHERE pe.venue_id=e.venue_id AND pe.expense_id=e.id AND pe.status='paid')) AS "payrollNeedsReview", CASE WHEN e.source='payroll' AND payroll.id IS NOT NULL THEN 'Выплата зарплаты за ' || to_char(payroll.period_from,'DD.MM.YYYY') || ' — ' || to_char(payroll.period_to,'DD.MM.YYYY') ELSE e.description END AS description FROM expenses e LEFT JOIN LATERAL (SELECT pe.id,pe.status,pe.period_from,pe.period_to FROM payroll_entries pe WHERE pe.venue_id=e.venue_id AND pe.expense_id=e.id ORDER BY pe.created_at DESC,pe.id DESC LIMIT 1) payroll ON true ${where} ORDER BY e.expense_date DESC,e.created_at DESC${limit === null ? '' : ' LIMIT $5 OFFSET $6'}`, limit === null ? values : [...values,limit,offset]),
        ]);
        return json(res, 200, { items: expenseResult.rows, totalCount: countResult.rows[0].count, limit, offset });
      } catch (error) { return json(res, 503, { error: 'expenses_unavailable', detail: error.message }); }
    }
    const filteredExpenses = manualExpenses.filter((expense) => expense.date >= from && expense.date <= to).sort((a,b) => b.date.localeCompare(a.date));
    return json(res, 200, { items: limit === null ? filteredExpenses : filteredExpenses.slice(offset, offset + limit), totalCount: filteredExpenses.length, limit, offset });
  }
  if (pathname === '/api/expenses' && req.method === 'POST') {
    if (denyUnless(req, res, 'finance')) return;
    const input = await body(req); let category = String(input.category || '').trim(); let categoryId = input.categoryId ? String(input.categoryId) : null; const amount = Number(input.amount); const expenseDate = String(input.expenseDate || today());
    if (repositories?.pool && categoryId && !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(categoryId)) return json(res, 400, { error: 'invalid_finance_category' });
    if ((!categoryId && (!category || category.length > 80)) || !Number.isFinite(amount) || amount < 0 || !/^\d{4}-\d{2}-\d{2}$/.test(expenseDate)) return json(res, 400, { error: 'invalid_expense' });
    if (input.source === 'payroll') return json(res, 400, { error: 'payroll_expense_must_be_paid_through_payroll' });
    if (input.source === 'purchase') return json(res, 400, { error: 'purchase_payment_requires_receipt_link' });
    if (repositories?.pool) {
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        if (categoryId) {
          const selected = await client.query("SELECT name FROM finance_categories WHERE id=$1 AND venue_id=$2 AND active=true AND kind='expense' FOR UPDATE", [categoryId,venueDbId]);
          if (!selected.rows[0]) { await client.query('ROLLBACK'); return json(res, 400, { error: 'invalid_finance_category' }); }
          category = selected.rows[0].name;
        }
        if (!category || category.length > 80) { await client.query('ROLLBACK'); return json(res, 400, { error: 'invalid_expense' }); }
        const { rows } = await client.query('INSERT INTO expenses (venue_id,category,category_id,amount,expense_date,description,source,document_url,created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *', [venueDbId,category,categoryId,amount,expenseDate,String(input.description || '').slice(0,1000) || null,['manual','purchase','other'].includes(input.source) ? input.source : 'manual',String(input.documentUrl || '').slice(0,500) || null,req.user?.id || null]);
        await client.query('COMMIT');
        return json(res, 201, rows[0]);
      } catch (error) {
        await client.query('ROLLBACK').catch(() => {});
        return json(res, error.code === '23503' ? 400 : 409, { error: error.code === '23503' ? 'invalid_finance_category' : 'expense_save_failed', detail: error.message });
      } finally { client.release(); }
    }
    if (categoryId) { const selected = financeCategories.find((item) => item.id === categoryId && item.active !== false && item.kind === 'expense'); if (!selected) return json(res, 400, { error: 'invalid_finance_category' }); category = selected.name; }
    if (!category || category.length > 80) return json(res, 400, { error: 'invalid_expense' });
    const expense = { id: `expense-${Date.now()}`, category, categoryId, amount, date: expenseDate, expenseDate, description: String(input.description || '').slice(0,1000), source: ['manual','other'].includes(input.source) ? input.source : 'manual', createdAt: new Date().toISOString() }; manualExpenses.push(expense); return json(res, 201, expense);
  }
  if (pathname === '/api/payroll/rules' && req.method === 'POST') {
    if (denyUnless(req, res, 'finance')) return;
    const input = await body(req); const name = String(input.name || '').trim(); const ruleType = String(input.ruleType || 'hourly'); const rate = Number(input.rate);
    if (!name || !['hourly','monthly','percent_revenue','per_shift'].includes(ruleType) || !Number.isFinite(rate) || rate < 0) return json(res, 400, { error: 'invalid_payroll_rule' });
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query('INSERT INTO payroll_rules (venue_id,name,rule_type,rate) VALUES ($1,$2,$3,$4) RETURNING *', [venueDbId,name,ruleType,rate]); return json(res, 201, rows[0]); } catch (error) { return json(res, 409, { error: 'payroll_rule_save_failed', detail: error.message }); } }
  }
  const payrollEntryPath = pathname.match(/^\/api\/payroll\/entries\/([^/]+)$/);
  if ((pathname === '/api/payroll/entries' && req.method === 'GET') || (payrollEntryPath && req.method === 'GET')) {
    if (denyUnless(req, res, 'finance')) return;
    if (!repositories?.pool) return json(res, 503, { error: 'payroll_requires_database' });
    const from = String(url.searchParams.get('from') || '1900-01-01'); const to = String(url.searchParams.get('to') || '2999-12-31');
    const userId = String(url.searchParams.get('userId') || ''); const status = String(url.searchParams.get('status') || '');
    if (!isValidIsoDate(from) || !isValidIsoDate(to) || to < from || (userId && !/^[0-9a-f-]{36}$/i.test(userId)) || (status && !['draft','approved','paid','cancelled'].includes(status))) return json(res, 400, { error: 'invalid_payroll_filter' });
    const id = payrollEntryPath ? decodeURIComponent(payrollEntryPath[1]) : '';
    if (id && !/^[0-9a-f-]{36}$/i.test(id)) return json(res, 400, { error: 'invalid_payroll_entry_id' });
    try {
      const { rows } = await repositories.pool.query(`SELECT pe.id,pe.user_id AS "userId",u.full_name AS "userName",pe.rule_id AS "ruleId",pr.name AS "ruleName",pr.rule_type AS "ruleType",pe.period_from AS "periodFrom",pe.period_to AS "periodTo",pe.amount,pe.status,pe.payment_date AS "paymentDate",pe.expense_id AS "expenseId",pe.approved_at AS "approvedAt",pe.paid_at AS "paidAt",pe.cancelled_at AS "cancelledAt",COALESCE(work.hours,0)::numeric AS hours FROM payroll_entries pe JOIN users u ON u.id=pe.user_id LEFT JOIN payroll_rules pr ON pr.id=pe.rule_id AND pr.venue_id=pe.venue_id JOIN venues v ON v.id=pe.venue_id LEFT JOIN organizations org ON org.id=v.organization_id LEFT JOIN LATERAL (WITH bounds AS (SELECT (pe.period_from::timestamp AT TIME ZONE COALESCE(NULLIF(v.timezone,''),NULLIF(org.timezone,''),'Asia/Yekaterinburg')) starts_at,((pe.period_to+1)::timestamp AT TIME ZONE COALESCE(NULLIF(v.timezone,''),NULLIF(org.timezone,''),'Asia/Yekaterinburg')) ends_at),clipped AS (SELECT GREATEST(w.started_at,b.starts_at) starts_at,LEAST(COALESCE(w.ended_at,now()),b.ends_at) ends_at FROM bounds b JOIN staff_work_logs w ON w.venue_id=pe.venue_id AND w.user_id=pe.user_id AND w.started_at < b.ends_at AND COALESCE(w.ended_at,now()) > b.starts_at),ordered AS (SELECT *,MAX(ends_at) OVER (ORDER BY starts_at,ends_at ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) previous_end FROM clipped),merged AS (SELECT *,GREATEST(starts_at,COALESCE(previous_end,starts_at)) effective_start FROM ordered) SELECT SUM(GREATEST(0,EXTRACT(EPOCH FROM (ends_at-effective_start))/3600)) hours FROM merged) work ON true WHERE pe.venue_id=$1 AND ($2::date IS NULL OR pe.period_to >= $2::date) AND ($3::date IS NULL OR pe.period_from <= $3::date) AND ($4::uuid IS NULL OR pe.user_id=$4) AND ($5::text='' OR pe.status=$5) AND ($6::uuid IS NULL OR pe.id=$6) ORDER BY pe.period_from DESC,u.full_name`, [venueDbId, from === '1900-01-01' ? null : from, to === '2999-12-31' ? null : to, userId || null, status, id || null]);
      if (id && !rows[0]) return json(res, 404, { error: 'payroll_entry_not_found' });
      return json(res, 200, id ? rows[0] : { items: rows.map((row) => ({ ...row, amount: Number(row.amount || 0), hours: Number(Number(row.hours || 0).toFixed(2)) })) });
    } catch (error) { return json(res, 503, { error: 'payroll_entries_unavailable', detail: error.message }); }
  }
  if (pathname === '/api/payroll/entries' && req.method === 'POST') {
    if (denyUnless(req, res, 'finance')) return;
    if (!repositories?.pool) return json(res, 503, { error: 'payroll_requires_database' });
    const input = await body(req); const userId = String(input.userId || '').trim(); const periodFrom = String(input.periodFrom || '').trim(); const periodTo = String(input.periodTo || '').trim(); const ruleId = String(input.ruleId || '').trim();
    if (!/^[0-9a-f-]{36}$/i.test(userId) || !/^[0-9a-f-]{36}$/i.test(ruleId) || !isValidIsoDate(periodFrom) || !isValidIsoDate(periodTo) || periodTo < periodFrom || countInclusiveDays(periodFrom, periodTo) > 366) return json(res, 400, { error: 'invalid_payroll_period' });
    try {
      const [userResult, ruleResult] = await Promise.all([
        repositories.pool.query('SELECT id FROM users WHERE id=$1 AND venue_id=$2 AND is_active=true AND deleted_at IS NULL', [userId, venueDbId]),
        repositories.pool.query('SELECT * FROM payroll_rules WHERE id=$1 AND venue_id=$2 AND active=true LIMIT 1', [ruleId, venueDbId]),
      ]);
      if (!userResult.rows[0]) return json(res, 404, { error: 'payroll_user_not_found' });
      const rule = ruleResult.rows[0]; if (!rule) return json(res, 404, { error: 'payroll_rule_not_found' });
      const timeResult = await repositories.pool.query(`WITH tz AS (SELECT COALESCE(NULLIF(v.timezone,''),NULLIF(org.timezone,''),'Asia/Yekaterinburg') AS name FROM venues v LEFT JOIN organizations org ON org.id=v.organization_id WHERE v.id=$1), bounds AS (SELECT ($3::date::timestamp AT TIME ZONE name) starts_at, (($4::date+1)::timestamp AT TIME ZONE name) ends_at, name FROM tz), clipped AS (SELECT GREATEST(w.started_at,b.starts_at) starts_at,LEAST(COALESCE(w.ended_at,now()),b.ends_at) ends_at,(w.started_at AT TIME ZONE b.name)::date shift_date,(w.started_at >= b.starts_at AND w.started_at < b.ends_at) is_shift_start FROM bounds b JOIN staff_work_logs w ON w.venue_id=$1 AND w.user_id=$2 AND w.started_at < b.ends_at AND COALESCE(w.ended_at,now()) > b.starts_at), ordered AS (SELECT *,MAX(ends_at) OVER (ORDER BY starts_at,ends_at ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) previous_end FROM clipped), merged AS (SELECT *,GREATEST(starts_at,COALESCE(previous_end,starts_at)) effective_start FROM ordered) SELECT COALESCE(SUM(GREATEST(0,EXTRACT(EPOCH FROM (ends_at-effective_start))/3600)),0) AS hours,COUNT(DISTINCT shift_date) FILTER (WHERE is_shift_start)::int AS shifts FROM merged`, [venueDbId,userId,periodFrom,periodTo]);
      const hours = Number(timeResult.rows[0]?.hours || 0); const shifts = Number(timeResult.rows[0]?.shifts || 0); let revenue = 0;
      if (rule.rule_type === 'percent_revenue') {
        const sales = await repositories.pool.query(`SELECT COALESCE(SUM(p.amount),0) AS revenue FROM orders o JOIN payments p ON p.order_id=o.id JOIN venues v ON v.id=o.venue_id LEFT JOIN organizations org ON org.id=v.organization_id WHERE o.venue_id=$1 AND o.opened_by=$2 AND o.status='closed' AND o.closed_at >= ($3::date::timestamp AT TIME ZONE COALESCE(NULLIF(v.timezone,''),NULLIF(org.timezone,''),'Asia/Yekaterinburg')) AND o.closed_at < (($4::date+1)::timestamp AT TIME ZONE COALESCE(NULLIF(v.timezone,''),NULLIF(org.timezone,''),'Asia/Yekaterinburg')) AND p.status IN ('paid','partially_paid')`, [venueDbId,userId,periodFrom,periodTo]);
        revenue = Number(sales.rows[0]?.revenue || 0);
      }
      const amount = calculatePayrollAmount({ ruleType: rule.rule_type, rate: rule.rate, hours, shifts, revenue, periodFrom, periodTo });
      if (amount === null) return json(res, 400, { error: 'invalid_payroll_rule' });
      const { rows } = await repositories.pool.query(`INSERT INTO payroll_entries (venue_id,user_id,rule_id,period_from,period_to,amount,status) VALUES ($1,$2,$3,$4,$5,$6,'draft') ON CONFLICT (venue_id,user_id,period_from,period_to,rule_id) DO UPDATE SET amount=EXCLUDED.amount WHERE payroll_entries.status='draft' RETURNING *`, [venueDbId,userId,ruleId,periodFrom,periodTo,amount]);
      if (!rows[0]) return json(res, 409, { error: 'payroll_entry_not_editable' });
      const entry = rows[0]; recordAudit(req, 'payroll.entry_drafted', 'payroll_entry', entry.id, null, { ...entry, hours });
      return json(res, 201, { ...entry, amount: Number(entry.amount), hours: Number(hours.toFixed(2)), expenseId: entry.expense_id || null });
    } catch (error) { return json(res, 409, { error: 'payroll_entry_save_failed', detail: error.message }); }
  }
  if (payrollEntryPath && req.method === 'PATCH') {
    if (denyUnless(req, res, 'finance')) return;
    if (!repositories?.pool) return json(res, 503, { error: 'payroll_requires_database' });
    const id = decodeURIComponent(payrollEntryPath[1]); if (!/^[0-9a-f-]{36}$/i.test(id)) return json(res, 400, { error: 'invalid_payroll_entry_id' });
    const input = await body(req); const action = String(input.action || '');
    if (!['approve','pay','cancel'].includes(action)) return json(res, 400, { error: 'invalid_payroll_action' });
    const paymentDate = String(input.paymentDate || today()); const reason = String(input.reason || '').trim();
    if (action === 'pay' && !isValidIsoDate(paymentDate)) return json(res, 400, { error: 'invalid_payroll_payment_date' });
    if (action === 'cancel' && (reason.length < 3 || reason.length > 500)) return json(res, 400, { error: 'payroll_cancellation_reason_required' });
    let client; let before;
    try {
      client = await repositories.pool.connect(); await client.query('BEGIN');
      const locked = await client.query("SELECT *, to_char(period_from,'DD.MM.YYYY') AS period_from_label, to_char(period_to,'DD.MM.YYYY') AS period_to_label FROM payroll_entries WHERE id=$1 AND venue_id=$2 FOR UPDATE", [id, venueDbId]); before = locked.rows[0];
      if (!before) { await client.query('ROLLBACK'); return json(res, 404, { error: 'payroll_entry_not_found' }); }
      if (!canTransitionPayroll(before.status, action)) { await client.query('ROLLBACK'); return json(res, 409, { error: 'payroll_transition_not_allowed', status: before.status, action }); }
      const findPayrollPeriodOverlap = async () => {
        // Serialize approve/pay transitions for one employee and rule so two
        // overlapping entries cannot be approved or paid at the same time.
        await client.query("SELECT pg_advisory_xact_lock(hashtext('territory_crm_payroll_period'),hashtext($1::text || ':' || $2::text || ':' || $3::text))", [venueDbId, before.user_id, before.rule_id]);
        return client.query(`SELECT id FROM payroll_entries
          WHERE venue_id=$1 AND user_id=$2 AND rule_id=$3 AND id<>$4
            AND status IN ('approved','paid')
            AND period_from <= $6::date AND period_to >= $5::date
          LIMIT 1`, [venueDbId, before.user_id, before.rule_id, id, before.period_from, before.period_to]);
      };
      let updated;
      if (action === 'approve') {
        const overlap = await findPayrollPeriodOverlap();
        if (overlap.rows[0]) {
          await client.query('ROLLBACK');
          return json(res, 409, { error: 'payroll_period_overlap', conflictingEntryId: overlap.rows[0].id });
        }
        const { rows } = await client.query("UPDATE payroll_entries SET status='approved',approved_at=now(),approved_by=$3 WHERE id=$1 AND venue_id=$2 RETURNING *", [id,venueDbId,/^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null]); updated = rows[0];
      } else if (action === 'cancel') {
        const { rows } = await client.query("UPDATE payroll_entries SET status='cancelled',cancelled_at=now(),cancelled_by=$3,cancellation_reason=$4 WHERE id=$1 AND venue_id=$2 RETURNING *", [id,venueDbId,/^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null,reason]); updated = rows[0];
      } else {
        const overlap = await findPayrollPeriodOverlap();
        if (overlap.rows[0]) {
          await client.query('ROLLBACK');
          return json(res, 409, { error: 'payroll_period_overlap', conflictingEntryId: overlap.rows[0].id });
        }
        const description = `Выплата зарплаты за ${before.period_from_label} — ${before.period_to_label}`;
        let expenseId = before.expense_id;
        if (expenseId) {
          const { rows } = await client.query("UPDATE expenses SET category='Зарплата',amount=$1,expense_date=$2,description=$3,source='payroll',created_by=COALESCE($4,created_by) WHERE id=$5 AND venue_id=$6 RETURNING id", [before.amount,paymentDate,description,/^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null,expenseId,venueDbId]);
          if (!rows[0]) return await client.query('ROLLBACK').then(() => json(res, 409, { error: 'payroll_expense_link_invalid' }));
          expenseId = rows[0].id;
        } else {
          const { rows } = await client.query("INSERT INTO expenses (venue_id,category,amount,expense_date,description,source,created_by) VALUES ($1,'Зарплата',$2,$3,$4,'payroll',$5) RETURNING id", [venueDbId,before.amount,paymentDate,description,/^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null]); expenseId = rows[0].id;
        }
        const { rows } = await client.query("UPDATE payroll_entries SET status='paid',paid_at=now(),paid_by=$3,payment_date=$4,expense_id=$5 WHERE id=$1 AND venue_id=$2 RETURNING *", [id,venueDbId,/^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null,paymentDate,expenseId]); updated = rows[0];
      }
      await client.query('COMMIT');
      recordAudit(req, `payroll.entry_${action === 'pay' ? 'paid' : action === 'approve' ? 'approved' : 'cancelled'}`, 'payroll_entry', id, before, updated);
      return json(res, 200, { ...updated, amount: Number(updated.amount), expenseId: updated.expense_id || null });
    } catch (error) { if (client) await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'payroll_entry_transition_failed', detail: error.message }); }
    finally { client?.release(); }
  }
  if (pathname === '/api/inventory/auto-orders' && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['inventory', 'inventory_read'])) return;
    const buildSuggestions = (items) => items.filter((item) => Number(item.minLevel || 0) > 0 && Number(item.onHand || 0) <= Number(item.minLevel || 0)).map((item) => {
      const onHand = Number(item.onHand || 0); const minLevel = Number(item.minLevel || 0); const packMultiplier = Math.max(0.000001, Number(item.packMultiplier || 1));
      const targetLevel = Math.max(minLevel * 2, minLevel + packMultiplier); const shortage = Math.max(0, targetLevel - onHand); const orderQuantity = Math.ceil(shortage / packMultiplier) * packMultiplier;
      return { id: item.id, name: item.name, department: item.department, subdepartment: item.subdepartment, category: item.category, unit: item.unit, purchaseUnit: item.purchaseUnit || item.unit, packMultiplier, supplier: item.supplier || null, cost: Number(item.cost || 0), onHand, minLevel, targetLevel: Number(targetLevel.toFixed(6)), shortage: Number(shortage.toFixed(6)), orderQuantity: Number(orderQuantity.toFixed(6)), estimate: Number((orderQuantity * Number(item.cost || 0)).toFixed(2)) };
    });
    if (repositories?.inventory) {
      try {
        const data = await repositories.inventory.list(venueDbId);
        const { rows } = await repositories.pool.query(`SELECT id,status,lines,note,total_estimate AS "totalEstimate",created_at AS "createdAt",sent_at AS "sentAt",updated_at AS "updatedAt" FROM inventory_auto_orders WHERE venue_id=$1 ORDER BY created_at DESC LIMIT 20`, [venueDbId]);
        return json(res, 200, { items: buildSuggestions(data.items), requests: rows.map((row) => ({ ...row, totalEstimate: Number(row.totalEstimate || 0), lines: Array.isArray(row.lines) ? row.lines.map((line) => ({ ...line, quantity: Number(line.quantity || 0), receivedQuantity: Number(line.receivedQuantity || 0) })) : [] })) });
      } catch (error) { return json(res, 503, { error: 'auto_orders_unavailable', detail: error.message }); }
    }
    const suggestions = buildSuggestions(inventory); return json(res, 200, { items: suggestions, requests: autoOrderRequests.slice().reverse().slice(0, 20).map((request) => ({ ...request, lines: Array.isArray(request.lines) ? request.lines.map((line) => ({ ...line, quantity: Number(line.quantity || 0), receivedQuantity: Number(line.receivedQuantity || 0) })) : [] })) });
  }
  if (pathname === '/api/inventory/auto-orders' && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req); const rawItems = Array.isArray(input.items) ? input.items.slice(0, 100) : [];
    if (!rawItems.length) return json(res, 400, { error: 'auto_order_items_required' });
    const requestedLines = rawItems.map((line) => ({ itemId: String(line.itemId || '').trim(), quantity: Number(line.quantity) })).filter((line) => line.itemId && Number.isFinite(line.quantity) && line.quantity > 0);
    if (!requestedLines.length || requestedLines.length !== rawItems.length) return json(res, 400, { error: 'invalid_auto_order_lines' });
    const current = repositories?.inventory ? (await repositories.inventory.list(venueDbId)).items : inventory;
    const lines = requestedLines.map((line) => { const item = current.find((entry) => entry.id === line.itemId); if (!item) return null; const pack = Math.max(0.000001, Number(item.packMultiplier || 1)); const quantity = Math.ceil(line.quantity / pack) * pack; return { itemId: item.id, name: item.name, quantity: Number(quantity.toFixed(6)), receivedQuantity: 0, unit: item.unit, purchaseUnit: item.purchaseUnit || item.unit, packMultiplier: Number(item.packMultiplier || 1), supplier: item.supplier || null, unitCost: Number(item.cost || 0), estimate: Number((quantity * Number(item.cost || 0)).toFixed(2)) }; });
    if (lines.some((line) => !line)) return json(res, 400, { error: 'auto_order_item_not_found' });
    const totalEstimate = Number(lines.reduce((sum, line) => sum + line.estimate, 0).toFixed(2)); const note = String(input.note || '').trim().slice(0, 500) || null;
    if (repositories?.pool) {
      try {
        const requestedBy = /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null;
        const { rows } = await repositories.pool.query(`INSERT INTO inventory_auto_orders (venue_id,status,lines,note,total_estimate,requested_by,sent_at) VALUES ($1,'sent',$2::jsonb,$3,$4,$5,now()) RETURNING id,status,lines,note,total_estimate AS "totalEstimate",created_at AS "createdAt",sent_at AS "sentAt",updated_at AS "updatedAt"`, [venueDbId, JSON.stringify(lines), note, totalEstimate, requestedBy]);
        recordAudit(req, 'inventory.auto_order_sent', 'inventory_auto_order', rows[0].id, null, rows[0]); return json(res, 201, { ...rows[0], totalEstimate: Number(rows[0].totalEstimate || 0), lines: rows[0].lines || [] });
      } catch (error) { return json(res, 409, { error: 'auto_order_save_failed', detail: error.message }); }
    }
    const request = { id: `auto-order-${crypto.randomUUID()}`, venueId: notificationVenueScope(req, venueDbId), status: 'sent', lines, note, totalEstimate, createdAt: new Date().toISOString(), sentAt: new Date().toISOString() }; autoOrderRequests.push(request); recordAudit(req, 'inventory.auto_order_sent', 'inventory_auto_order', request.id, null, request); return json(res, 201, request);
  }
  const autoOrderPath = pathname.match(/^\/api\/inventory\/auto-orders\/([^/]+)$/);
  if (autoOrderPath && req.method === 'PATCH') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req);
    if (input.status === 'received' || input.status === 'partially_received' || Array.isArray(input.receipts)) {
      return json(res, 409, { error: 'purchase_document_required' });
    }
    if (input.status !== 'cancelled') return json(res, 400, { error: 'invalid_auto_order_status' });
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(autoOrderPath[1])) {
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        const current = await client.query('SELECT id,status,lines FROM inventory_auto_orders WHERE id=$1 AND venue_id=$2 FOR UPDATE', [autoOrderPath[1], venueDbId]);
        if (!current.rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'auto_order_not_found' }); }
        if (!['sent', 'partially_received'].includes(current.rows[0].status)) { await client.query('ROLLBACK'); return json(res, 409, { error: 'auto_order_not_cancellable' }); }
        const drafts = await client.query("SELECT EXISTS(SELECT 1 FROM inventory_purchase_documents WHERE source_auto_order_id=$1 AND venue_id=$2 AND status='draft') AS has_drafts", [autoOrderPath[1], venueDbId]);
        if (drafts.rows[0]?.has_drafts) { await client.query('ROLLBACK'); return json(res, 409, { error: 'auto_order_has_draft_receipts' }); }
        const { rows } = await client.query(`UPDATE inventory_auto_orders SET status='cancelled',updated_at=now() WHERE id=$1 AND venue_id=$2 RETURNING id,status,lines,note,total_estimate AS "totalEstimate",created_at AS "createdAt",sent_at AS "sentAt",updated_at AS "updatedAt"`, [autoOrderPath[1], venueDbId]);
        await client.query('COMMIT');
        recordAudit(req, 'inventory.auto_order_cancelled', 'inventory_auto_order', rows[0].id, null, rows[0]);
        return json(res, 200, { ...rows[0], totalEstimate: Number(rows[0].totalEstimate || 0), lines: rows[0].lines || [] });
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'auto_order_status_save_failed', detail: error.message }); } finally { client.release(); }
    }
    const request = autoOrderRequests.find((entry) => entry.id === autoOrderPath[1]);
    if (!request) return json(res, 404, { error: 'auto_order_not_found' });
    if (!['sent', 'partially_received'].includes(request.status)) return json(res, 409, { error: 'auto_order_not_cancellable' });
    request.status = 'cancelled'; request.updatedAt = new Date().toISOString();
    recordAudit(req, 'inventory.auto_order_cancelled', 'inventory_auto_order', request.id, null, request);
    return json(res, 200, request);
  }
  const inventoryItemPath = pathname.match(/^\/api\/inventory\/items\/([^/]+)$/);
  const validateInventoryHierarchy = async (department, subdepartment, client = repositories?.pool) => {
    if (!repositories?.pool) return null;
    const departmentCode = String(department || '').trim(); const subdepartmentName = String(subdepartment || '').trim();
    try {
      const departmentResult = await client.query('SELECT 1 FROM inventory_departments WHERE venue_id=$1 AND code=$2 AND is_active=true FOR SHARE', [venueDbId, departmentCode]);
      if (!departmentResult.rows[0]) return 'inventory_department_not_found';
      if (subdepartmentName) {
        const subdepartmentResult = await client.query('SELECT 1 FROM inventory_subdepartments WHERE venue_id=$1 AND department_code=$2 AND name=$3 AND is_active=true FOR SHARE', [venueDbId, departmentCode, subdepartmentName]);
        if (!subdepartmentResult.rows[0]) return 'inventory_subdepartment_not_found';
      }
      return null;
    } catch (error) { if (error?.code === '42P01') return 'inventory_hierarchy_unavailable'; throw error; }
  };
  const validateInventoryCategorySubdepartment = async (department, subdepartment, categoryName, client = repositories?.pool) => {
    if (!repositories?.pool || !String(categoryName || '').trim()) return null;
    try {
      const result = await client.query(`SELECT c.department,s.name AS "subdepartmentName" FROM product_categories c
        LEFT JOIN inventory_subdepartments s ON s.id=c.subdepartment_id AND s.venue_id=c.venue_id
        WHERE c.venue_id=$1 AND lower(btrim(c.name))=lower(btrim($2)) AND c.is_active=true FOR SHARE OF c`, [venueDbId, String(categoryName).trim()]);
      const rows = result.rows;
      const selected = rows.find((row) => row.department === String(department || '').trim());
      if (!selected && rows.length) return 'inventory_category_department_mismatch';
      if (String(categoryName).trim() !== 'Без категории' && !selected) return 'inventory_category_not_found';
      const requiredSubdepartment = selected?.subdepartmentName;
      if (requiredSubdepartment && String(subdepartment || '').trim() !== requiredSubdepartment) return 'inventory_category_subdepartment_mismatch';
      return null;
    } catch (error) { if (error?.code === '42P01' || error?.code === '42703') return 'inventory_hierarchy_unavailable'; throw error; }
  };
  const withInventoryHierarchyTransaction = async (department, subdepartment, categoryName, write) => {
    const client = await repositories.pool.connect();
    try {
      await client.query('BEGIN');
      const hierarchyError = await validateInventoryHierarchy(department, subdepartment, client);
      if (hierarchyError) { await client.query('ROLLBACK'); return { error: hierarchyError }; }
      const categoryError = await validateInventoryCategorySubdepartment(department, subdepartment, categoryName, client);
      if (categoryError) { await client.query('ROLLBACK'); return { error: categoryError }; }
      const value = await write(client);
      await client.query('COMMIT');
      return { value };
    } catch (error) {
      await client.query('ROLLBACK').catch(() => {});
      throw error;
    } finally { client.release(); }
  };
  if (pathname === '/api/inventory/items' && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req);
    const name = String(input.name || '').trim();
    const allowedUnits = ['шт', 'г', 'кг', 'мл', 'л', 'порция', 'уп', 'упаковка'];
    const itemType = String(input.itemType || 'ingredient');
    const department = String(input.department || 'inventory').trim();
    const unit = String(input.unit || '').trim();
    const cost = Number(input.cost || 0); const minLevel = Number(input.minLevel || 0); const packMultiplier = Number(input.packMultiplier ?? 1);
    if (!name || name.length > 120) return json(res, 400, { error: 'invalid_inventory_item_name' });
    if (!allowedUnits.includes(unit) || !['ingredient', 'product', 'consumable', 'equipment'].includes(itemType)) return json(res, 400, { error: 'invalid_inventory_item_measurement' });
    if (!Number.isFinite(cost) || cost < 0 || !Number.isFinite(minLevel) || minLevel < 0 || !Number.isFinite(packMultiplier) || packMultiplier <= 0) return json(res, 400, { error: 'invalid_inventory_item_numbers' });
    if (String(input.subdepartment || '').length > 80 || String(input.category || '').length > 80 || String(input.supplier || '').length > 160 || String(input.barcode || '').length > 64 || String(input.note || '').length > 500) return json(res, 400, { error: 'inventory_item_field_too_long' });
    const clean = { name, shortName: String(input.shortName || '').trim().slice(0, 80) || null, department, subdepartment: String(input.subdepartment || '').trim().slice(0, 80), category: String(input.category || 'Без категории').trim().slice(0, 80) || 'Без категории', itemType, unit, purchaseUnit: String(input.purchaseUnit || '').trim().slice(0, 30) || null, packMultiplier, cost, minLevel, supplier: String(input.supplier || '').trim().slice(0, 160) || null, barcode: String(input.barcode || '').trim().slice(0, 64) || null, note: String(input.note || '').trim().slice(0, 500) || null };
    if (repositories?.inventory) { try { const result = repositories?.pool ? await withInventoryHierarchyTransaction(department, clean.subdepartment, clean.category, (client) => repositories.inventory.create(venueDbId, clean, client)) : { value: await repositories.inventory.create(venueDbId, clean) }; if (result.error) return json(res, result.error === 'inventory_hierarchy_unavailable' ? 503 : 400, { error: result.error }); const item = result.value; recordAudit(req, 'inventory.item_created', 'inventory', item.id, null, item); return json(res, 201, { ...item, onHand: 0 }); } catch (error) { return json(res, 409, { error: 'inventory_item_create_failed', detail: error.message }); } }
    const item = { id: `ing-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`, ...clean, onHand: 0, active: true }; inventory.push(item); recordAudit(req, 'inventory.item_created', 'inventory', item.id, null, item); return json(res, 201, item);
  }
  if (inventoryItemPath && req.method === 'PATCH') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req);
    const editableFields = ['name','shortName','department','subdepartment','category','itemType','unit','purchaseUnit','packMultiplier','cost','minLevel','supplier','barcode','note'];
    if (!Object.keys(input).length || Object.keys(input).some((key) => !editableFields.includes(key))) return json(res, 400, { error: 'invalid_inventory_item_fields' });
    const allowedUnits = ['шт', 'г', 'кг', 'мл', 'л', 'порция', 'уп', 'упаковка'];
    if (input.name !== undefined && (!String(input.name).trim() || String(input.name).length > 120)) return json(res, 400, { error: 'invalid_inventory_item_name' });
    if (input.unit !== undefined && !allowedUnits.includes(String(input.unit))) return json(res, 400, { error: 'invalid_inventory_item_measurement' });
    if (input.itemType !== undefined && !['ingredient', 'product', 'consumable', 'equipment'].includes(String(input.itemType))) return json(res, 400, { error: 'invalid_inventory_item_measurement' });
    for (const key of ['cost', 'minLevel', 'packMultiplier']) if (input[key] !== undefined && (!Number.isFinite(Number(input[key])) || Number(input[key]) < (key === 'packMultiplier' ? 0.01 : 0))) return json(res, 400, { error: 'invalid_inventory_item_numbers' });
    if (repositories?.inventory) {
      try {
        let item;
        if (repositories?.pool) {
          const client = await repositories.pool.connect();
          try {
            await client.query('BEGIN');
            const current = await client.query('SELECT department,subdepartment,category FROM ingredients WHERE id=$1 AND venue_id=$2 AND is_marked=true', [inventoryItemPath[1], venueDbId]);
            if (!current.rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'inventory_item_not_found' }); }
            const observed = current.rows[0];
            const nextDepartment = input.department !== undefined ? input.department : observed.department;
            const nextSubdepartment = input.subdepartment !== undefined ? input.subdepartment : observed.subdepartment;
            const nextCategory = input.category !== undefined ? input.category : observed.category;
            const hierarchyError = await validateInventoryHierarchy(nextDepartment, nextSubdepartment, client);
            if (hierarchyError) { await client.query('ROLLBACK'); return json(res, hierarchyError === 'inventory_hierarchy_unavailable' ? 503 : 400, { error: hierarchyError }); }
            const categoryChanged = input.category !== undefined || input.department !== undefined || input.subdepartment !== undefined;
            const categoryError = categoryChanged ? await validateInventoryCategorySubdepartment(nextDepartment, nextSubdepartment, nextCategory, client) : null;
            if (categoryError) { await client.query('ROLLBACK'); return json(res, categoryError === 'inventory_hierarchy_unavailable' ? 503 : 400, { error: categoryError }); }
            const locked = await client.query('SELECT department,subdepartment,category FROM ingredients WHERE id=$1 AND venue_id=$2 AND is_marked=true FOR UPDATE', [inventoryItemPath[1], venueDbId]);
            if (!locked.rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'inventory_item_not_found' }); }
            if (locked.rows[0].department !== observed.department || locked.rows[0].subdepartment !== observed.subdepartment || locked.rows[0].category !== observed.category) { await client.query('ROLLBACK'); return json(res, 409, { error: 'inventory_item_changed_retry' }); }
            item = await repositories.inventory.update(venueDbId, inventoryItemPath[1], input, client);
            await client.query('COMMIT');
          } catch (error) { await client.query('ROLLBACK').catch(() => {}); throw error; }
          finally { client.release(); }
        } else item = await repositories.inventory.update(venueDbId, inventoryItemPath[1], input);
        if (!item) return json(res, 404, { error: 'inventory_item_not_found' });
        recordAudit(req, 'inventory.item_updated', 'inventory', item.id, null, item);
        return json(res, 200, item);
      } catch (error) { return json(res, 409, { error: 'inventory_item_update_failed', detail: error.message }); }
    }
    const item = inventory.find((entry) => entry.id === inventoryItemPath[1]); if (!item) return json(res, 404, { error: 'inventory_item_not_found' }); if (input.unit !== undefined && input.unit !== item.unit && stockMovements.some((movement) => movement.itemId === item.id)) return json(res, 409, { error: 'inventory_unit_has_movements' }); Object.assign(item, input); recordAudit(req, 'inventory.item_updated', 'inventory', item.id, null, item); return json(res, 200, item);
  }
  if (inventoryItemPath && req.method === 'DELETE') {
    if (denyUnless(req, res, 'inventory')) return;
    if (repositories?.inventory) { try { const item = await repositories.inventory.archive(venueDbId, inventoryItemPath[1]); if (!item) return json(res, 404, { error: 'inventory_item_not_found' }); recordAudit(req, 'inventory.item_archived', 'inventory', item.id, item, null); return json(res, 200, item); } catch (error) { return json(res, 409, { error: error.code === 'inventory_item_has_stock' ? 'inventory_item_has_stock' : 'inventory_item_archive_failed', detail: error.message }); } }
    const index = inventory.findIndex((entry) => entry.id === inventoryItemPath[1]); if (index < 0) return json(res, 404, { error: 'inventory_item_not_found' }); if (inventory[index].onHand !== 0) return json(res, 409, { error: 'inventory_item_has_stock' }); const [item] = inventory.splice(index, 1); recordAudit(req, 'inventory.item_archived', 'inventory', item.id, item, null); return json(res, 200, item);
  }
  if (pathname === '/api/inventory' && req.method === 'GET') {
    if (process.env.AUTH_REQUIRED === 'true' && !hasPermission(req, 'inventory') && !hasPermission(req, 'inventory_read')) return json(res, 403, { error: 'forbidden', permission: 'inventory' });
    if (repositories?.inventory) { try { const data = await repositories.inventory.list(venueDbId); return json(res, 200, { ...data, lowStock: data.items.filter(isBelowInventoryMinimum) }); } catch (_) { return json(res, 503, { error: 'inventory_unavailable' }); } }
    return json(res, 200, { items: inventory, lowStock: inventory.filter(isBelowInventoryMinimum), movements: stockMovements.slice(-20).reverse() });
  }
  if (pathname === '/api/inventory/supplies' && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req); const quantity = Number(input.quantity); const unitCost = Number(input.unitCost);
    if (!input.itemId || !Number.isFinite(quantity) || quantity <= 0 || !Number.isFinite(unitCost) || unitCost < 0) return json(res, 400, { error: 'invalid_supply' });
    const reason = String(input.reason || `Поставка${input.supplier ? ` · ${input.supplier}` : ''}`).trim().slice(0, 200);
    const unitFactors = { г: { г: 1, кг: 0.001 }, кг: { кг: 1, г: 1000 }, мл: { мл: 1, л: 0.001 }, л: { л: 1, мл: 1000 }, шт: { шт: 1 }, порция: { порция: 1 }, уп: { уп: 1 }, упаковка: { упаковка: 1 } };
    if (repositories?.inventory) {
      try {
        const current = await repositories.inventory.list(venueDbId); const item = current.items.find((entry) => entry.id === input.itemId); const sourceUnit = String(input.unit || item?.unit || ''); const conversionFactor = item && unitFactors[sourceUnit]?.[item.unit]; const converted = item && conversionFactor ? quantity * conversionFactor : quantity;
        if (!item || !conversionFactor || !Number.isFinite(converted) || converted <= 0) return json(res, 400, { error: 'invalid_supply_unit' });
        const movement = await repositories.inventory.receive({ venueId: venueDbId, ingredientId: item.id, stockUnit: item.unit, quantity: converted, conversionFactor, unitCost, reason, createdBy: /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null });
        recordAudit(req, 'inventory.supply_received', 'inventory', item.id, { onHand: movement.onHandBefore, cost: item.cost }, { onHand: movement.onHandAfter, cost: movement.weightedCost, movement });
        return json(res, 201, { ...movement, delta: converted, sourceUnit, unitCost });
      } catch (error) { return json(res, 409, { error: 'supply_save_failed', detail: error.message }); }
    }
    const item = inventory.find((entry) => entry.id === input.itemId); const sourceUnit = String(input.unit || item?.unit || ''); const conversionFactor = item && unitFactors[sourceUnit]?.[item.unit]; const converted = item && conversionFactor ? quantity * conversionFactor : quantity;
    if (!item || !conversionFactor || !Number.isFinite(converted) || converted <= 0) return json(res, 400, { error: 'invalid_supply_unit' }); const previousValue = Number(item.onHand || 0) * Number(item.cost || 0); const normalizedUnitCost = unitCost / conversionFactor; item.cost = Number(((previousValue + converted * normalizedUnitCost) / (Number(item.onHand || 0) + converted)).toFixed(4)); item.onHand = Number((Number(item.onHand || 0) + converted).toFixed(6)); const movement = { id: `mov-${Date.now()}`, itemId: item.id, itemName: item.name, delta: converted, unit: item.unit, sourceUnit, reason, createdAt: new Date().toISOString() }; stockMovements.push(movement); recordAudit(req, 'inventory.supply_received', 'inventory', item.id, null, { onHand: item.onHand, cost: item.cost, movement }); return json(res, 201, { ...movement, unitCost, weightedCost: item.cost });
  }
  const purchaseDocumentPath = pathname.match(/^\/api\/inventory\/purchase-documents\/([^/]+)$/);
  const purchaseDocumentPostPath = pathname.match(/^\/api\/inventory\/purchase-documents\/([^/]+)\/post$/);
  const purchaseDocumentVoidPath = pathname.match(/^\/api\/inventory\/purchase-documents\/([^/]+)\/void$/);
  if (pathname === '/api/inventory/purchase-documents' && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['inventory_read', 'inventory'])) return;
    if (!repositories?.purchaseDocuments) return json(res, 200, { items: [] });
    const status = url.searchParams.get('status') || null;
    if (status && !['draft', 'posted', 'voided'].includes(status)) return json(res, 400, { error: 'invalid_purchase_status' });
    try { return json(res, 200, { items: await repositories.purchaseDocuments.list(venueDbId, status) }); } catch (error) { return json(res, 503, { error: 'purchase_documents_unavailable', detail: error.message }); }
  }
  if (pathname === '/api/inventory/purchase-documents' && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    if (!repositories?.purchaseDocuments) return json(res, 503, { error: 'purchase_documents_unavailable' });
    try {
      const input = normalizePurchaseInput(await body(req));
      const created = await repositories.purchaseDocuments.saveDraft({ ...input, venueId: venueDbId, createdBy: /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null });
      recordAudit(req, 'inventory.purchase_document_created', 'purchase_document', created.id, null, created);
      return json(res, 201, created);
    } catch (error) { return json(res, error.message === 'purchase_ingredient_not_found' ? 400 : error.message === 'invalid_purchase_unit' ? 400 : error.code === '23505' ? 409 : 400, { error: error.message === 'purchase_ingredient_not_found' ? 'purchase_ingredient_not_found' : error.message === 'invalid_purchase_unit' ? 'invalid_purchase_unit' : error.message === 'invalid_purchase_document' || error.message === 'invalid_purchase_line' || error.message === 'invalid_purchase_lines' || error.message === 'invalid_source_auto_order' ? error.message : 'purchase_document_create_failed', ingredientId: error.ingredientId, sourceUnit: error.sourceUnit, targetUnit: error.targetUnit, detail: error.code === '23505' ? 'document_number_exists' : error.message }); }
  }
  if (purchaseDocumentPath && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['inventory_read', 'inventory'])) return;
    if (!repositories?.purchaseDocuments) return json(res, 404, { error: 'purchase_document_not_found' });
    try { const item = await repositories.purchaseDocuments.get(venueDbId, purchaseDocumentPath[1]); return item ? json(res, 200, item) : json(res, 404, { error: 'purchase_document_not_found' }); } catch (error) { return json(res, 503, { error: 'purchase_document_unavailable', detail: error.message }); }
  }
  if (purchaseDocumentPath && req.method === 'PATCH') {
    if (denyUnless(req, res, 'inventory')) return;
    if (!repositories?.purchaseDocuments) return json(res, 503, { error: 'purchase_documents_unavailable' });
    try {
      const input = normalizePurchaseInput(await body(req));
      const updated = await repositories.purchaseDocuments.updateDraft({ ...input, id: purchaseDocumentPath[1], venueId: venueDbId });
      recordAudit(req, 'inventory.purchase_document_updated', 'purchase_document', updated.id, null, updated);
      return json(res, 200, updated);
    } catch (error) { const status = ['purchase_document_not_found', 'purchase_document_not_draft'].includes(error.message) ? 409 : 400; return json(res, status, { error: ['purchase_ingredient_not_found', 'invalid_purchase_unit', 'invalid_source_auto_order'].includes(error.message) ? error.message : 'purchase_document_update_failed', ingredientId: error.ingredientId, sourceUnit: error.sourceUnit, targetUnit: error.targetUnit, detail: error.message }); }
  }
  if (purchaseDocumentVoidPath && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    if (!repositories?.purchaseDocuments) return json(res, 503, { error: 'purchase_documents_unavailable' });
    try {
      const cancelled = await repositories.purchaseDocuments.voidDraft(venueDbId, purchaseDocumentVoidPath[1]);
      recordAudit(req, 'inventory.purchase_document_voided', 'purchase_document', cancelled.id, null, cancelled);
      return json(res, 200, cancelled);
    } catch (error) {
      const status = error.message === 'purchase_document_not_found' ? 404 : error.message === 'purchase_document_not_voidable' ? 409 : 400;
      return json(res, status, { error: ['purchase_document_not_found', 'purchase_document_not_voidable'].includes(error.message) ? error.message : 'purchase_document_void_failed', status: error.status, detail: error.message });
    }
  }
  if (purchaseDocumentPostPath && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    if (!repositories?.purchaseDocuments) return json(res, 503, { error: 'purchase_documents_unavailable' });
    try {
      const result = await repositories.purchaseDocuments.post(venueDbId, purchaseDocumentPostPath[1], /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null);
      recordAudit(req, 'inventory.purchase_document_posted', 'purchase_document', result.document.id, { status: 'draft' }, result.document);
      return json(res, 200, result);
    } catch (error) { const status = ['purchase_document_not_found'].includes(error.message) ? 404 : ['purchase_document_not_postable', 'purchase_document_empty'].includes(error.message) ? 409 : 400; return json(res, status, { error: error.message === 'purchase_document_not_postable' ? 'purchase_document_not_postable' : error.message === 'purchase_document_empty' ? 'purchase_document_empty' : error.message === 'purchase_document_not_found' ? 'purchase_document_not_found' : 'purchase_document_post_failed', status: error.status, detail: error.message }); }
  }
  if (pathname === '/api/inventory/premixes' && req.method === 'GET') {
    if (process.env.AUTH_REQUIRED === 'true' && !hasPermission(req, 'inventory_read') && !hasPermission(req, 'inventory')) return json(res, 403, { error: 'forbidden', permission: 'inventory' });
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query(`SELECT b.id,b.recipe_id AS "recipeId",r.name AS "recipeName",b.output_ingredient_id AS "outputItemId",i.name AS "outputItemName",b.output_movement_id AS "outputMovementId",b.output_quantity AS "outputQuantity",b.planned_output_quantity AS "plannedOutputQuantity",GREATEST(0,b.output_quantity+COALESCE(SUM(m.quantity_delta),0)) AS "remainingQuantity",b.output_unit AS "outputUnit",b.total_cost AS "totalCost",b.ingredients,b.expires_at AS "expiresAt",(b.expires_at IS NOT NULL AND b.expires_at<=now()) AS expired,b.status,b.created_at AS "createdAt",b.produced_by AS "producedById",u.full_name AS "producedBy" FROM inventory_premix_batches b JOIN inventory_recipe_cards r ON r.id=b.recipe_id JOIN ingredients i ON i.id=b.output_ingredient_id LEFT JOIN inventory_premix_batch_movements m ON m.batch_id=b.id LEFT JOIN users u ON u.id=b.produced_by WHERE b.venue_id=$1 GROUP BY b.id,r.name,i.name,u.full_name ORDER BY b.created_at DESC LIMIT 100`, [venueDbId]); return json(res, 200, { items: rows.map((row) => ({ ...row, expired: Boolean(row.expired), outputQuantity: Number(row.outputQuantity), plannedOutputQuantity: Number(row.plannedOutputQuantity), remainingQuantity: Number(row.remainingQuantity), totalCost: Number(row.totalCost) })) }); } catch (error) { return json(res, 503, { error: 'premixes_unavailable', detail: error.message }); } }
    return json(res, 200, { items: stockMovements.filter((item) => item.type === 'premix').slice(-100).reverse().map((batch) => ({ ...batch, plannedOutputQuantity: Number(batch.plannedOutputQuantity ?? batch.outputQuantity), remainingQuantity: memoryPremixRemaining(batch), producedBy: batch.producedBy || null, expired: Boolean(batch.expiresAt && new Date(batch.expiresAt).getTime() <= Date.now()) })) });
  }
  const premixAction = pathname.match(/^\/api\/inventory\/premixes\/([^/]+)\/(waste|count|void)$/);
  if (premixAction && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    const batchId = premixAction[1]; const action = premixAction[2]; const input = await body(req);
    const reason = String(input.reason || (action === 'waste' ? 'Списание порчи' : action === 'count' ? 'Инвентаризационная корректировка' : '')).trim();
    if (action !== 'void' && (!reason || reason.length > 200)) return json(res, 400, { error: 'premix_batch_reason_required' });
    if (!repositories?.pool) {
      const batch = stockMovements.find((entry) => entry.type === 'premix' && String(entry.id) === String(batchId)); if (!batch) return json(res, 404, { error: 'premix_batch_not_found' });
      const item = inventory.find((entry) => String(entry.id) === String(batch.outputItemId)); if (!item) return json(res, 404, { error: 'premix_output_item_not_found' });
      const remaining = memoryPremixRemaining(batch); const actor = req.user?.name || 'администратор';
      if (batch.status === 'voided') return json(res, 409, { error: 'premix_batch_not_active' });
      if (action === 'void') {
        const later = stockMovements.some((entry) => entry.type !== 'premix' && String(entry.itemId) === String(item.id) && new Date(entry.createdAt || 0) > new Date(batch.createdAt));
        if (!batch.outputMovementId || (batch.lotMovements || []).length || later || Math.abs(remaining - Number(batch.outputQuantity)) > 0.000001) return json(res, 409, { error: 'premix_batch_cannot_be_voided_after_stock_activity' });
        const components = (batch.ingredients || []).map((entry) => ({ entry, item: inventory.find((candidate) => String(candidate.id) === String(entry.ingredientId)) }));
        if (components.some(({ item: source }) => !source)) return json(res, 409, { error: 'premix_ingredient_not_found' });
        if (Number(item.onHand || 0) + 0.000001 < remaining) return json(res, 409, { error: 'insufficient_stock' });
        item.onHand = Number((Number(item.onHand) - remaining).toFixed(6)); item.cost = Number(batch.previousOutputCost || 0);
        for (const { entry, item: source } of components) { source.onHand = Number((Number(source.onHand || 0) + Number(entry.quantity)).toFixed(6)); stockMovements.push({ id: `mov-${Date.now()}-${Math.random()}`, itemId: source.id, itemName: source.name, direction: 'in', delta: Number(entry.quantity), quantity: Number(entry.quantity), reason: `Возврат сырья при отмене партии ${batchId}`, createdAt: new Date().toISOString() }); }
        batch.status = 'voided'; batch.voidReason = String(input.reason || 'Ошибка выпуска').slice(0, 200); batch.voidedBy = actor; batch.voidedAt = new Date().toISOString(); stockMovements.push({ id: `mov-${Date.now()}-${Math.random()}`, itemId: item.id, itemName: item.name, direction: 'out', delta: -remaining, quantity: remaining, reason: `Отмена выпуска партии ${batchId}`, createdAt: new Date().toISOString() });
      } else {
        let delta; if (action === 'waste') { const quantity = Number(input.quantity); if (!Number.isFinite(quantity) || quantity <= 0 || quantity > remaining) return json(res, 400, { error: 'invalid_premix_batch_quantity' }); delta = -quantity; } else { const actual = Number(input.actualQuantity); if (!Number.isFinite(actual) || actual < 0) return json(res, 400, { error: 'invalid_premix_batch_count' }); delta = actual - remaining; if (Math.abs(delta) < 0.000001) return json(res, 200, { id: batchId, remainingQuantity: remaining }); }
        if (Number(item.onHand || 0) + delta < -0.000001) return json(res, 409, { error: 'insufficient_stock' }); item.onHand = Number((Number(item.onHand || 0) + delta).toFixed(6)); batch.lotMovements ||= []; batch.lotMovements.push({ id: `premix-move-${Date.now()}`, type: action === 'waste' ? 'waste' : 'adjustment', quantityDelta: delta, reason, createdBy: actor, createdAt: new Date().toISOString() }); stockMovements.push({ id: `mov-${Date.now()}-${Math.random()}`, itemId: item.id, itemName: item.name, direction: delta < 0 ? (action === 'waste' ? 'waste' : 'out') : 'adjustment', delta, quantity: Math.abs(delta), reason, createdAt: new Date().toISOString() });
      }
      recordAudit(req, `inventory.premix_batch_${action}`, 'premix', batchId, { remainingQuantity: remaining }, { action, reason }); return json(res, 200, { id: batchId, status: batch.status || 'produced', remainingQuantity: action === 'void' ? 0 : memoryPremixRemaining(batch) });
    }
    let client;
    try {
      client = await repositories.pool.connect(); await client.query('BEGIN');
      const { rows: batchRows } = await client.query(`SELECT b.*,i.name AS output_name,i.unit AS output_stock_unit,i.cost AS output_cost
        FROM inventory_premix_batches b JOIN ingredients i ON i.id=b.output_ingredient_id
        WHERE b.id=$1 AND b.venue_id=$2 FOR UPDATE OF b,i`, [batchId, venueDbId]);
      const batch = batchRows[0]; if (!batch) { await client.query('ROLLBACK'); return json(res, 404, { error: 'premix_batch_not_found' }); }
      const balanceRows = await client.query('SELECT COALESCE(SUM(quantity_delta),0)::numeric AS delta FROM inventory_premix_batch_movements WHERE batch_id=$1', [batchId]);
      const remaining = Math.max(0, Number(batch.output_quantity) + Number(balanceRows.rows[0]?.delta || 0));
      const actorId = /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null;
      if (batch.status !== 'produced') { await client.query('ROLLBACK'); return json(res, 409, { error: 'premix_batch_not_active' }); }
      if (action === 'void') {
        const hasLotEvents = await client.query('SELECT 1 FROM inventory_premix_batch_movements WHERE batch_id=$1 LIMIT 1', [batchId]);
        const hasLaterItemMovement = await client.query(`SELECT 1 FROM stock_movements sm
          WHERE sm.venue_id=$1 AND sm.ingredient_id=$2 AND sm.id<>$3
            AND sm.created_at >= (SELECT source.created_at FROM stock_movements source WHERE source.id=$3)
          LIMIT 1`, [venueDbId, batch.output_ingredient_id, batch.output_movement_id]);
        if (!batch.output_movement_id || hasLotEvents.rowCount || hasLaterItemMovement.rowCount || Math.abs(remaining - Number(batch.output_quantity)) > 0.000001) { await client.query('ROLLBACK'); return json(res, 409, { error: 'premix_batch_cannot_be_voided_after_stock_activity' }); }
        const { rows: reverseRows } = await client.query(`INSERT INTO stock_movements (venue_id,ingredient_id,direction,quantity,reason,created_by)
          VALUES ($1,$2,'out',$3,$4,$5) RETURNING id`, [venueDbId, batch.output_ingredient_id, Number(batch.output_quantity), `Отмена выпуска партии ${batchId}`, actorId]);
        await client.query(`INSERT INTO inventory_premix_batch_movements (venue_id,batch_id,stock_movement_id,movement_type,quantity_delta,reason,created_by)
          VALUES ($1,$2,$3,'reversal',$4,$5,$6)`, [venueDbId, batchId, reverseRows[0].id, -Number(batch.output_quantity), 'Отмена выпуска партии', actorId]);
        const components = Array.isArray(batch.ingredients) ? batch.ingredients : [];
        const componentIds = [...new Set(components.map((component) => String(component.ingredientId || '')).filter(Boolean))];
        const sourceRows = componentIds.length ? await client.query(`SELECT id FROM ingredients WHERE venue_id=$1 AND id=ANY($2::uuid[]) AND is_marked=true FOR UPDATE`, [venueDbId, componentIds]) : { rows: [] };
        if (!components.length || sourceRows.rowCount !== componentIds.length || components.some((component) => !component.ingredientId || !Number.isFinite(Number(component.quantity)) || Number(component.quantity) <= 0)) {
          throw new Error('premix_ingredient_not_found');
        }
        for (const component of components) {
          const { rows: restoredRows } = await client.query(`INSERT INTO stock_movements (venue_id,ingredient_id,direction,quantity,reason,created_by)
            SELECT $1,i.id,'in',$3,$4,$5 FROM ingredients i WHERE i.id=$2 AND i.venue_id=$1 AND i.is_marked=true RETURNING id`,
          [venueDbId, component.ingredientId, Number(component.quantity), `Возврат сырья при отмене партии ${batchId}`, actorId]);
          if (!restoredRows.length) throw new Error('premix_ingredient_not_found');
        }
        await client.query('UPDATE ingredients SET cost=$1 WHERE id=$2 AND venue_id=$3', [batch.previous_output_cost, batch.output_ingredient_id, venueDbId]);
        await client.query('UPDATE inventory_premix_batches SET status=\'voided\',voided_at=now(),voided_by=$1,void_reason=$2 WHERE id=$3 AND venue_id=$4', [actorId, String(input.reason || 'Ошибка выпуска').slice(0, 200), batchId, venueDbId]);
      } else {
        let delta; let movementDirection; let movementType;
        if (action === 'waste') {
          delta = -Number(input.quantity); movementDirection = 'waste'; movementType = 'waste';
          if (!Number.isFinite(-delta) || delta >= 0 || -delta > remaining || -delta <= 0) { await client.query('ROLLBACK'); return json(res, 400, { error: 'invalid_premix_batch_quantity', remainingQuantity: remaining }); }
        } else {
          const counted = Number(input.actualQuantity); delta = counted - remaining; movementDirection = delta >= 0 ? 'adjustment' : 'out'; movementType = 'adjustment';
          if (!Number.isFinite(counted) || counted < 0) { await client.query('ROLLBACK'); return json(res, 400, { error: 'invalid_premix_batch_count', remainingQuantity: remaining }); }
          if (Math.abs(delta) < 0.0000001) { await client.query('COMMIT'); return json(res, 200, { id: batchId, status: 'produced', remainingQuantity: remaining }); }
        }
        const { rows: movementRows } = await client.query(`INSERT INTO stock_movements (venue_id,ingredient_id,direction,quantity,reason,created_by)
          VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`, [venueDbId, batch.output_ingredient_id, movementDirection, Math.abs(delta), reason, actorId]);
        await client.query(`INSERT INTO inventory_premix_batch_movements (venue_id,batch_id,stock_movement_id,movement_type,quantity_delta,reason,created_by)
          VALUES ($1,$2,$3,$4,$5,$6,$7)`, [venueDbId, batchId, movementRows[0].id, movementType, delta, reason, actorId]);
      }
      await client.query('COMMIT');
      recordAudit(req, `inventory.premix_batch_${action}`, 'premix', batchId, { remainingQuantity: remaining }, { action, reason, quantity: input.quantity, actualQuantity: input.actualQuantity });
      return json(res, 200, { id: batchId, status: action === 'void' ? 'voided' : 'produced', remainingQuantity: action === 'void' ? 0 : action === 'count' ? Number(input.actualQuantity) : Number((remaining - Number(input.quantity)).toFixed(6)) });
    } catch (error) { if (client) await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: error.message === 'insufficient_stock' ? 'insufficient_stock' : 'premix_batch_action_failed', detail: error.message }); }
    finally { client?.release(); }
  }
  if (pathname === '/api/inventory/premixes/produce' && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req); const recipeId = String(input.recipeId || '').trim(); const outputItemId = String(input.outputItemId || '').trim(); const multiplier = Number(input.multiplier || 1);
    const requestedActualOutput = input.actualOutput === undefined || input.actualOutput === '' ? null : Number(input.actualOutput);
    const expiresAt = input.expiresAt ? new Date(input.expiresAt) : null;
    if (!recipeId || !outputItemId || !Number.isFinite(multiplier) || multiplier <= 0 || multiplier > 1000 || (requestedActualOutput !== null && (!Number.isFinite(requestedActualOutput) || requestedActualOutput <= 0 || requestedActualOutput > 100000000)) || (input.expiresAt && (!expiresAt || !Number.isFinite(expiresAt.getTime()) || expiresAt <= new Date()))) return json(res, 400, { error: 'invalid_premix_production' });
    const unitFactors = { г: { г: 1, кг: 0.001 }, кг: { кг: 1, г: 1000 }, мл: { мл: 1, л: 0.001 }, л: { л: 1, мл: 1000 }, шт: { шт: 1 }, порция: { порция: 1 }, уп: { уп: 1 }, упаковка: { упаковка: 1 } };
    if (repositories?.pool) {
      let client;
      try {
        const recipeResult = await repositories.pool.query('SELECT id,name,ingredients,yield_quantity AS "yieldQuantity",yield_unit AS "yieldUnit" FROM inventory_recipe_cards WHERE id=$1 AND venue_id=$2 AND active=true AND recipe_type=\'premix\'', [recipeId, venueDbId]); const recipe = recipeResult.rows[0]; if (!recipe) return json(res, 404, { error: 'premix_recipe_not_found' });
        const outputResult = await repositories.pool.query('SELECT id,name,unit,cost FROM ingredients WHERE id=$1 AND venue_id=$2 AND is_marked=true', [outputItemId, venueDbId]); const output = outputResult.rows[0]; if (!output) return json(res, 404, { error: 'premix_output_item_not_found' });
        const stock = (await repositories.inventory.list(venueDbId)).items; const requirements = []; for (const entry of (recipe.ingredients || [])) { const item = stock.find((candidate) => String(candidate.id) === String(entry.ingredientId) || String(candidate.name).toLocaleLowerCase('ru-RU') === String(entry.name || '').toLocaleLowerCase('ru-RU')); if (!item) return json(res, 409, { error: 'premix_ingredient_not_found', ingredient: entry.name || entry.ingredientId }); const parsed = parseRecipeQuantity(entry.quantity, item.unit, entry.unit || null); if (parsed.error) return json(res, 409, { error: parsed.error, ingredient: item.name, sourceUnit: parsed.sourceUnit, targetUnit: parsed.targetUnit }); requirements.push({ item, quantity: Number((parsed.amount * parsed.factor * multiplier).toFixed(6)), unit: item.unit }); }
        const combinedRequirements = new Map(); for (const entry of requirements) { const key = String(entry.item.id); const previous = combinedRequirements.get(key); if (previous) previous.quantity += entry.quantity; else combinedRequirements.set(key, { ...entry }); } requirements.splice(0, requirements.length, ...combinedRequirements.values());
        const outputFactor = unitFactors[recipe.yieldUnit]?.[output.unit]; if (!outputFactor) return json(res, 409, { error: 'premix_output_unit_mismatch', sourceUnit: recipe.yieldUnit, targetUnit: output.unit }); const plannedOutputQuantity = Number((Number(recipe.yieldQuantity) * multiplier * outputFactor).toFixed(6)); const outputQuantity = Number(((requestedActualOutput ?? Number(recipe.yieldQuantity) * multiplier) * outputFactor).toFixed(6));
        if (requirements.some((entry) => String(entry.item.id) === String(output.id))) return json(res, 409, { error: 'premix_output_cannot_be_an_ingredient' });
        client = await repositories.pool.connect(); await client.query('BEGIN'); let totalCost = 0;
        const lockIds = [...new Set([...requirements.map((entry) => String(entry.item.id)), String(output.id)])].sort();
        const locked = await client.query('SELECT id,name,unit,cost FROM ingredients WHERE venue_id=$1 AND id=ANY($2::uuid[]) AND is_marked=true ORDER BY id FOR UPDATE', [venueDbId, lockIds]);
        const lockedById = new Map(locked.rows.map((row) => [String(row.id), row]));
        for (const requirement of requirements) {
          const row = lockedById.get(String(requirement.item.id));
          const stockResult = row ? await client.query("SELECT COALESCE(SUM(CASE WHEN direction IN ('in','transfer','adjustment') THEN quantity WHEN direction IN ('out','waste') THEN -quantity ELSE 0 END),0)::numeric AS on_hand FROM stock_movements WHERE ingredient_id=$1 AND venue_id=$2", [requirement.item.id, venueDbId]) : { rows: [] };
          const onHand = Number(stockResult.rows[0]?.on_hand || 0);
          if (!row || onHand < requirement.quantity) { const error = new Error('insufficient_premix_stock'); error.missing = [{ name: requirement.item.name, required: requirement.quantity, onHand, unit: requirement.unit }]; throw error; }
          requirement.item = { ...row, onHand }; totalCost += requirement.quantity * Number(row.cost || 0);
        }
        const outputRow = lockedById.get(String(output.id));
        if (!outputRow) throw new Error('premix_output_item_not_found');
        const outputBalance = await client.query("SELECT COALESCE(SUM(CASE WHEN direction IN ('in','transfer','adjustment') THEN quantity WHEN direction IN ('out','waste') THEN -quantity ELSE 0 END),0)::numeric AS on_hand FROM stock_movements WHERE ingredient_id=$1 AND venue_id=$2", [output.id, venueDbId]);
        const previousOutputQuantity = Number(outputBalance.rows[0]?.on_hand || 0);
        for (const requirement of requirements) {
          const { rows: movementRows } = await client.query('INSERT INTO stock_movements (venue_id,ingredient_id,direction,quantity,reason,created_by) VALUES ($1,$2,\'out\',$3,$4,$5) RETURNING id', [venueDbId, requirement.item.id, requirement.quantity, `Приготовление премикса «${recipe.name}»`, /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null]);
          await allocatePremixBatchConsumption(client, { venueId: venueDbId, ingredientId: requirement.item.id, stockMovementId: movementRows[0].id, quantity: requirement.quantity, onHandBefore: Number(requirement.item.onHand || 0), createdBy: /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null, reason: `Приготовление премикса «${recipe.name}»` });
        }
        const { rows: outputMovementRows } = await client.query('INSERT INTO stock_movements (venue_id,ingredient_id,direction,quantity,reason,created_by) VALUES ($1,$2,\'in\',$3,$4,$5) RETURNING id', [venueDbId, output.id, outputQuantity, `Выход премикса «${recipe.name}»`, /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null]);
        const nextOutputQuantity = previousOutputQuantity + outputQuantity;
        const batchUnitCost = outputQuantity > 0 ? totalCost / outputQuantity : 0;
        const nextOutputCost = nextOutputQuantity > 0 ? ((previousOutputQuantity * Number(outputRow.cost || 0)) + totalCost) / nextOutputQuantity : batchUnitCost;
        await client.query('UPDATE ingredients SET cost=$1 WHERE id=$2 AND venue_id=$3', [Number(nextOutputCost.toFixed(4)), output.id, venueDbId]);
        const { rows } = await client.query('INSERT INTO inventory_premix_batches (venue_id,recipe_id,output_ingredient_id,output_quantity,planned_output_quantity,previous_output_cost,output_movement_id,output_unit,total_cost,ingredients,produced_by,expires_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10::jsonb,$11,$12) RETURNING id,recipe_id AS "recipeId",output_ingredient_id AS "outputItemId",output_quantity AS "outputQuantity",planned_output_quantity AS "plannedOutputQuantity",output_unit AS "outputUnit",total_cost AS "totalCost",ingredients,expires_at AS "expiresAt",created_at AS "createdAt",produced_by AS "producedById"', [venueDbId, recipe.id, output.id, outputQuantity, plannedOutputQuantity, Number(outputRow.cost || 0), outputMovementRows[0].id, output.unit, Math.round(totalCost * 100) / 100, JSON.stringify(requirements.map((entry) => ({ ingredientId: entry.item.id, name: entry.item.name, quantity: entry.quantity, unit: entry.unit }))), /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null, expiresAt]); await client.query('COMMIT'); recordAudit(req, 'inventory.premix_produced', 'premix', rows[0].id, null, { ...rows[0], recipeName: recipe.name, outputItemName: output.name, batchUnitCost: Math.round(totalCost / outputQuantity * 100) / 100 }); return json(res, 201, { ...rows[0], recipeName: recipe.name, outputItemName: output.name, remainingQuantity: outputQuantity, producedBy: req.user?.name || null, batchUnitCost: Math.round(totalCost / outputQuantity * 100) / 100 });
      } catch (error) { if (client) await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: ['insufficient_premix_stock','expired_premix_stock'].includes(error.message) ? error.message : 'premix_production_failed', missing: error.missing, detail: error.message }); } finally { client?.release(); }
    }
    const recipe = recipes.find((item) => item.id === recipeId && (item.recipeType || 'sale') === 'premix'); const output = inventory.find((item) => item.id === outputItemId); if (!recipe) return json(res, 404, { error: 'premix_recipe_not_found' }); if (!output) return json(res, 404, { error: 'premix_output_item_not_found' }); const requirements = []; let totalCost = 0; for (const entry of recipe.ingredients || []) { const item = inventory.find((candidate) => candidate.id === entry.ingredientId || String(candidate.name).toLocaleLowerCase('ru-RU') === String(entry.name || '').toLocaleLowerCase('ru-RU')); if (!item) return json(res, 409, { error: 'premix_ingredient_not_found', ingredient: entry.name || entry.ingredientId }); if (String(item.id) === String(output.id)) return json(res, 409, { error: 'premix_output_cannot_be_an_ingredient' }); const parsed = parseRecipeQuantity(entry.quantity, item.unit, entry.unit || null); if (parsed.error) return json(res, 409, { error: parsed.error, ingredient: item.name }); const quantity = Number((parsed.amount * parsed.factor * multiplier).toFixed(6)); requirements.push({ item, quantity, unit: item.unit }); } const combinedRequirements = new Map(); for (const entry of requirements) { const key = String(entry.item.id); const previous = combinedRequirements.get(key); if (previous) previous.quantity += entry.quantity; else combinedRequirements.set(key, { ...entry }); } requirements.splice(0, requirements.length, ...combinedRequirements.values()); for (const entry of requirements) { if (Number(entry.item.onHand || 0) < entry.quantity) return json(res, 409, { error: 'insufficient_premix_stock', missing: [{ name: entry.item.name, required: entry.quantity, onHand: Number(entry.item.onHand || 0), unit: entry.unit }] }); totalCost += entry.quantity * Number(entry.item.cost || 0); } const outputFactor = unitFactors[recipe.yieldUnit]?.[output.unit]; if (!outputFactor) return json(res, 409, { error: 'premix_output_unit_mismatch' }); const plannedOutputQuantity = Number((Number(recipe.yieldQuantity) * multiplier * outputFactor).toFixed(6)); const actualOutput = input.actualOutput === undefined || input.actualOutput === '' ? null : Number(input.actualOutput); if (actualOutput !== null && (!Number.isFinite(actualOutput) || actualOutput <= 0)) return json(res, 400, { error: 'invalid_premix_production' }); const outputQuantity = Number(((actualOutput ?? Number(recipe.yieldQuantity) * multiplier) * outputFactor).toFixed(6)); const batchExpiresAt = expiresAt ? expiresAt.toISOString() : null; const previousOutputCost = Number(output.cost || 0); const newOutputQuantity = Number(output.onHand || 0) + outputQuantity; const batchUnitCost = outputQuantity > 0 ? totalCost / outputQuantity : 0; output.cost = Number((newOutputQuantity > 0 ? ((Number(output.onHand || 0) * Number(output.cost || 0)) + totalCost) / newOutputQuantity : batchUnitCost).toFixed(4)); const sourceMovements = requirements.map((requirement) => ({ requirement, id: `mov-${Date.now()}-${Math.random().toString(36).slice(2, 7)}` })); for (const { requirement, id } of sourceMovements) { try { allocateMemoryPremixConsumption(requirement.item.id, requirement.quantity, Number(requirement.item.onHand || 0), id, `Приготовление премикса «${recipe.name}»`, { apply: false }); } catch (error) { return json(res, 409, { error: error.message }); } } for (const { requirement, id } of sourceMovements) { allocateMemoryPremixConsumption(requirement.item.id, requirement.quantity, Number(requirement.item.onHand || 0), id, `Приготовление премикса «${recipe.name}»`); requirement.item.onHand = Number((Number(requirement.item.onHand || 0) - requirement.quantity).toFixed(6)); stockMovements.push({ id, itemId: requirement.item.id, itemName: requirement.item.name, direction: 'out', delta: -requirement.quantity, quantity: requirement.quantity, reason: `Приготовление премикса «${recipe.name}»`, createdAt: new Date().toISOString() }); } output.onHand = Number(newOutputQuantity.toFixed(6)); const batch = { id: `premix-${Date.now()}`, recipeId, recipeName: recipe.name, outputItemId, outputItemName: output.name, outputQuantity, plannedOutputQuantity, previousOutputCost, expiresAt: batchExpiresAt, outputUnit: output.unit, totalCost: Math.round(totalCost * 100) / 100, batchUnitCost: Math.round(batchUnitCost * 100) / 100, producedBy: req.user?.name || 'администратор', ingredients: requirements.map(({ item, quantity, unit }) => ({ ingredientId: item.id, name: item.name, quantity, unit })), type: 'premix', status: 'produced', lotMovements: [], createdAt: new Date().toISOString() }; batch.outputMovementId = `premix-out-${batch.id}`; batch.outputMovementId = `premix-out-${batch.id}`; stockMovements.push(batch); recordAudit(req, 'inventory.premix_produced', 'premix', batch.id, null, batch); return json(res, 201, batch);
  }
  if (pathname === '/api/inventory/movements' && req.method === 'POST') {
    if (denyUnless(req, res, 'inventory')) return;
    const input = await body(req);
    if (input.reason !== undefined && String(input.reason).length > 200) return json(res, 400, { error: 'movement_reason_too_long' });
    input.reason = String(input.reason || 'Корректировка').trim().slice(0, 200);
    const unitFactors = { г: { г: 1, кг: 0.001 }, кг: { кг: 1, г: 1000 }, мл: { мл: 1, л: 0.001 }, л: { л: 1, мл: 1000 }, шт: { шт: 1 }, порция: { порция: 1 }, уп: { уп: 1 }, упаковка: { упаковка: 1 } };
    if (repositories?.inventory) {
      const current = await repositories.inventory.list(venueDbId); const item = current.items.find((entry) => entry.id === input.itemId); const delta = Number(input.delta);
      const sourceUnit = String(input.unit || item?.unit || ''); const conversionFactor = item && unitFactors[sourceUnit]?.[item.unit]; const convertedDelta = item && conversionFactor ? delta * conversionFactor : delta;
      if (!item || !conversionFactor || !Number.isFinite(delta) || delta === 0 || !Number.isFinite(convertedDelta)) return json(res, 400, { error: !conversionFactor ? 'invalid_movement_unit' : 'item_and_nonzero_delta_required' });
      let movement;
      try { movement = await repositories.inventory.move({ venueId: venueDbId, ingredientId: item.id, unit: item.unit, direction: convertedDelta > 0 ? 'in' : 'out', quantity: Math.abs(convertedDelta), reason: input.reason, createdBy: /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null }); }
      catch (error) { if (error.code === 'insufficient_stock') return json(res, 409, { error: 'insufficient_stock', onHand: error.onHand }); if (error.message === 'expired_premix_stock') return json(res, 409, { error: 'expired_premix_stock' }); if (error.message === 'inventory_unit_changed') return json(res, 409, { error: 'invalid_movement_unit' }); throw error; }
      recordAudit(req, 'inventory.movement', 'inventory', item.id, { onHand: movement.onHandBefore }, { onHand: movement.onHandAfter, movement });
      return json(res, 201, { ...movement, delta: convertedDelta, sourceUnit });
    }
    const item = inventory.find((entry) => entry.id === input.itemId);
    const delta = Number(input.delta); const sourceUnit = String(input.unit || item?.unit || ''); const conversionFactor = item && unitFactors[sourceUnit]?.[item.unit]; const convertedDelta = item && conversionFactor ? delta * conversionFactor : delta;
    if (!item || !conversionFactor || !Number.isFinite(delta) || delta === 0 || !Number.isFinite(convertedDelta)) return json(res, 400, { error: !conversionFactor ? 'invalid_movement_unit' : 'item_and_nonzero_delta_required' });
    if (item.onHand + convertedDelta < 0) return json(res, 409, { error: 'insufficient_stock', onHand: item.onHand });
    const movement = { id: `mov-${Date.now()}`, itemId: item.id, itemName: item.name, delta: convertedDelta, unit: item.unit, sourceUnit, reason: input.reason, createdAt: new Date().toISOString() };
    if (convertedDelta < 0) { try { allocateMemoryPremixConsumption(item.id, -convertedDelta, Number(item.onHand || 0), movement.id, input.reason || 'Списание'); } catch (error) { return json(res, 409, { error: error.message }); } }
    item.onHand = Number((item.onHand + convertedDelta).toFixed(6));
    stockMovements.push(movement);
    recordAudit(req, 'inventory.movement', 'inventory', item.id, { onHand: item.onHand - convertedDelta }, { onHand: item.onHand, movement });
    return json(res, 201, movement);
  }
  if (pathname === '/api/dashboard/shift-kpis' && req.method === 'GET') {
    if (process.env.AUTH_REQUIRED === 'true' && !hasPermission(req, 'finance') && !hasPermission(req, 'finance_read')) return json(res, 403, { error: 'forbidden', permission: 'finance_read' });
    const employeeView = isOperationalEmployee(req);
    let timezone = businessTimezone;
    const requestedDate = url.searchParams.get('date') || '';
    const requestedShiftId = employeeView ? '' : (url.searchParams.get('shiftId') || '');
    if (repositories?.pool && requestedShiftId && !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(requestedShiftId)) return json(res, 400, { error: 'invalid_shift_id' });
    let reportDate = requestedDate || today();
    if (repositories?.pool) {
      try {
        const venueRow = await repositories.pool.query('SELECT timezone FROM venues WHERE id=$1', [venueDbId]);
        timezone = String(venueRow.rows[0]?.timezone || timezone);
        try { new Intl.DateTimeFormat('en-US', { timeZone: timezone }).format(new Date()); } catch (_) { timezone = businessTimezone; }
        const currentDate = await repositories.pool.query("SELECT (now() AT TIME ZONE $1)::date::text AS date", [timezone]);
        if (employeeView && !/^[0-9a-f-]{36}$/i.test(req.user?.id || '')) return json(res, 403, { error: 'employee_identity_required' });
        if (employeeView || !requestedDate) reportDate = currentDate.rows[0]?.date || reportDate;
        const dateTimestamp = Date.parse(`${reportDate}T00:00:00Z`);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(reportDate) || !Number.isFinite(dateTimestamp) || new Date(dateTimestamp).toISOString().slice(0, 10) !== reportDate) return json(res, 400, { error: 'invalid_shift_kpi_date' });
        if (employeeView) {
          const employeeTotals = await repositories.pool.query(`
            SELECT COALESCE(payments.revenue,0) AS revenue, COALESCE(payments.payment_count,0)::int AS payment_count,
              COALESCE(payments.cash,0) AS cash, COALESCE(payments.cashless,0) AS cashless,
              COALESCE(payments.other,0) AS other, checks.closed_orders
            FROM (
              SELECT SUM(p.amount) AS revenue, COUNT(p.id)::int AS payment_count,
                SUM(p.amount) FILTER (WHERE p.method='cash') AS cash,
                SUM(p.amount) FILTER (WHERE p.method IN ('card','qr')) AS cashless,
                SUM(p.amount) FILTER (WHERE p.method NOT IN ('cash','card','qr')) AS other
              FROM payments p JOIN orders o ON o.id=p.order_id
              WHERE o.venue_id=$1 AND o.opened_by=$2 AND p.status IN ('paid','partially_paid')
                AND p.created_at >= ($3::date::timestamp AT TIME ZONE $4)
                AND p.created_at < (($3::date + 1)::timestamp AT TIME ZONE $4)
            ) payments CROSS JOIN (
              SELECT COUNT(*)::int AS closed_orders FROM orders o
              WHERE o.venue_id=$1 AND o.opened_by=$2 AND o.status='closed'
                AND o.closed_at >= ($3::date::timestamp AT TIME ZONE $4)
                AND o.closed_at < (($3::date + 1)::timestamp AT TIME ZONE $4)
            ) checks`, [venueDbId, req.user.id, reportDate, timezone]);
          const row = employeeTotals.rows[0] || {};
          return json(res, 200, { date: reportDate, timezone, employeeView: true, selectedShiftId: null,
            shifts: [{ id: 'employee-today' }], totals: { revenue: Number(row.revenue || 0), paymentCount: Number(row.payment_count || 0), cash: Number(row.cash || 0), cashless: Number(row.cashless || 0), other: Number(row.other || 0), closedOrders: Number(row.closed_orders || 0) },
            unassignedPaymentCount: 0, ambiguousPaymentCount: 0 });
        }
        const selectedShiftId = requestedShiftId;
        const shiftsResult = await repositories.pool.query(`
          SELECT s.id, s.opened_at AS "openedAt", s.closed_at AS "closedAt",
            COALESCE(payments.revenue,0)::numeric AS revenue,
            COALESCE(payments.payment_count,0)::int AS "paymentCount",
            COALESCE(payments.cash,0)::numeric AS cash,
            COALESCE(payments.cashless,0)::numeric AS cashless,
            COALESCE(payments.other,0)::numeric AS other,
            COALESCE(checks.closed_orders,0)::int AS "closedOrders"
          FROM shifts s
          LEFT JOIN LATERAL (
            SELECT SUM(p.amount) AS revenue,
              COUNT(p.id)::int AS payment_count,
              SUM(p.amount) FILTER (WHERE p.method='cash') AS cash,
              SUM(p.amount) FILTER (WHERE p.method IN ('card','qr')) AS cashless,
              SUM(p.amount) FILTER (WHERE p.method NOT IN ('cash','card','qr')) AS other
            FROM payments p JOIN orders o ON o.id=p.order_id AND o.venue_id=s.venue_id
            WHERE p.status IN ('paid','partially_paid') AND p.shift_id=s.id
              AND ($3::uuid IS NULL OR o.opened_by=$3::uuid)
          ) payments ON true
          LEFT JOIN LATERAL (
            SELECT COUNT(*)::int AS closed_orders FROM orders o
            WHERE o.venue_id=s.venue_id AND o.status='closed' AND o.closed_in_shift_id=s.id
              AND ($3::uuid IS NULL OR o.opened_by=$3::uuid)
          ) checks ON true
          WHERE s.venue_id=$1 AND (s.opened_at AT TIME ZONE $2)::date=$4::date
          ORDER BY s.opened_at DESC`, [venueDbId, timezone, employeeView ? req.user.id : null, reportDate]);
        const shiftsForDate = shiftsResult.rows.map((row) => ({ ...row, revenue: Number(row.revenue || 0), cash: Number(row.cash || 0), cashless: Number(row.cashless || 0), other: Number(row.other || 0), paymentCount: Number(row.paymentCount || 0), closedOrders: Number(row.closedOrders || 0) }));
        if (selectedShiftId && !shiftsForDate.some((shift) => shift.id === selectedShiftId)) return json(res, 404, { error: 'shift_not_found_for_date' });
        const selected = selectedShiftId ? shiftsForDate.filter((shift) => shift.id === selectedShiftId) : shiftsForDate;
        const totals = selected.reduce((result, shift) => ({ revenue: result.revenue + shift.revenue, paymentCount: result.paymentCount + shift.paymentCount, cash: result.cash + shift.cash, cashless: result.cashless + shift.cashless, other: result.other + shift.other, closedOrders: result.closedOrders + shift.closedOrders }), { revenue: 0, paymentCount: 0, cash: 0, cashless: 0, other: 0, closedOrders: 0 });
        const unmatchedResult = employeeView ? { rows: [{ count: 0 }] } : await repositories.pool.query(`SELECT COUNT(DISTINCT p.id)::int AS count FROM payments p JOIN orders o ON o.id=p.order_id AND o.venue_id=$1 WHERE p.status IN ('paid','partially_paid') AND p.shift_id IS NULL AND ((($4::uuid IS NULL) AND (p.created_at AT TIME ZONE $2)::date=$3::date) OR EXISTS (SELECT 1 FROM shifts s WHERE s.venue_id=$1 AND (s.opened_at AT TIME ZONE $2)::date=$3::date AND ($4::uuid IS NULL OR s.id=$4::uuid) AND p.created_at>=s.opened_at AND p.created_at<COALESCE(s.closed_at,now())))`, [venueDbId, timezone, reportDate, selectedShiftId || null]);
        const visibleShifts = employeeView ? (shiftsForDate.length ? [{ id: 'employee-today' }] : []) : shiftsForDate;
        return json(res, 200, { date: reportDate, timezone, employeeView, selectedShiftId: selectedShiftId || null, shifts: visibleShifts, totals, unassignedPaymentCount: Number(unmatchedResult.rows[0]?.count || 0), ambiguousPaymentCount: 0 });
      } catch (error) { return json(res, 503, { error: 'shift_kpis_unavailable', detail: error.message }); }
    }
    if (employeeView) reportDate = today();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(reportDate) || !Number.isFinite(Date.parse(`${reportDate}T00:00:00Z`)) || new Date(`${reportDate}T00:00:00Z`).toISOString().slice(0, 10) !== reportDate) return json(res, 400, { error: 'invalid_shift_kpi_date' });
    if (employeeView) {
      const totals = { revenue: 0, paymentCount: 0, cash: 0, cashless: 0, other: 0, closedOrders: 0 };
      for (const order of orders.filter((item) => String(item.openedById || item.openedBy || '') === String(req.user?.id || ''))) {
        if (order.status === 'closed' && order.closedAt && businessDateKey(order.closedAt) === reportDate) totals.closedOrders += 1;
        for (const payment of order.payments || []) {
          if (!['paid', 'partially_paid'].includes(payment.status) || !payment.createdAt || businessDateKey(payment.createdAt) !== reportDate) continue;
          const amount = Number(payment.amount || 0);
          const method = payment.method === 'cash' ? 'cash' : ['card', 'qr'].includes(payment.method) ? 'cashless' : 'other';
          totals.revenue += amount; totals.paymentCount += 1; totals[method] += amount;
        }
      }
      return json(res, 200, { date: reportDate, timezone: businessTimezone, employeeView: true, selectedShiftId: null,
        shifts: [{ id: 'employee-today' }], totals, unassignedPaymentCount: 0, ambiguousPaymentCount: 0 });
    }
    const localShifts = shifts.filter((shift) => businessDateKey(shift.openedAt) === reportDate);
    const matches = localShifts;
    const selectedShiftId = requestedShiftId;
    if (selectedShiftId && !matches.some((shift) => shift.id === selectedShiftId)) return json(res, 404, { error: 'shift_not_found_for_date' });
    const chosen = selectedShiftId ? matches.filter((shift) => shift.id === selectedShiftId) : matches;
    const sums = { revenue: 0, paymentCount: 0, cash: 0, cashless: 0, other: 0, closedOrders: 0, ambiguousPayments: 0 };
    const visibleOrders = orders.filter((order) => !employeeView || String(order.openedById || order.openedBy || '') === String(req.user?.id || ''));
    for (const order of visibleOrders) {
      if (order.status === 'closed' && order.closedAt) {
        const closedAt = new Date(order.closedAt);
        const closingShift = order.closedInShiftId || null;
        if (closingShift && chosen.some((shift) => shift.id === closingShift)) sums.closedOrders += 1;
      }
      for (const payment of order.payments || []) {
        if (!['paid','partially_paid'].includes(payment.status)) continue;
        const paymentShiftId = payment.shiftId || null;
        if (!paymentShiftId || !chosen.some((shift) => shift.id === paymentShiftId)) continue;
        const key = payment.method === 'cash' ? 'cash' : ['card','qr'].includes(payment.method) ? 'cashless' : 'other';
        const amount = Number(payment.amount || 0);
        sums.revenue += amount; sums.paymentCount += 1; sums[key] += amount;
      }
    }
    const safeShifts = employeeView ? (matches.length ? [{ id: 'employee-today' }] : []) : matches.map(({ id, openedAt, closedAt }) => ({ id, openedAt, closedAt: closedAt || null }));
    const unmatchedPaymentCount = employeeView ? 0 : visibleOrders.reduce((count, order) => count + (order.payments || []).filter((payment) => {
      if (!['paid', 'partially_paid'].includes(payment.status) || payment.shiftId) return false;
      const paidAt = new Date(payment.createdAt || order.closedAt || order.createdAt || 0);
      const relatesToDate = businessDateKey(paidAt) === reportDate;
      const relatesToShift = chosen.some((shift) => paidAt >= new Date(shift.openedAt) && (!shift.closedAt || paidAt < new Date(shift.closedAt)));
      return selectedShiftId ? relatesToShift : (relatesToDate || relatesToShift);
    }).length, 0);
    return json(res, 200, { date: reportDate, timezone, employeeView, selectedShiftId: selectedShiftId || null, shifts: safeShifts, totals: sums, unassignedPaymentCount: unmatchedPaymentCount, ambiguousPaymentCount: sums.ambiguousPayments });
  }
  if (pathname === '/api/finance/summary' && req.method === 'GET') {
    if (process.env.AUTH_REQUIRED === 'true' && !hasPermission(req, 'finance') && !hasPermission(req, 'finance_read')) return json(res, 403, { error: 'forbidden', permission: 'finance' });
    const employeeFinanceView = isOperationalEmployee(req); const requestedDate = url.searchParams.get('date') || ''; let date = employeeFinanceView ? today() : (requestedDate || today()); let timezone = businessTimezone;
    if (repositories?.pool) {
      try { const context = await venueBusinessDateContext(repositories.pool, venueDbId); if (!context) return json(res, 503, { error: 'database_unavailable' }); timezone = context.timezone; if (employeeFinanceView || !requestedDate) date = context.date; }
      catch (error) { return json(res, 503, { error: 'database_unavailable', detail: error.message }); }
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return json(res, 400, { error: 'invalid_finance_date' });
    if (employeeFinanceView && repositories?.pool) {
      try {
        const actorId = /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null;
        const { rows } = await repositories.pool.query(`SELECT COALESCE(SUM(p.amount),0) AS revenue FROM orders o JOIN payments p ON p.order_id=o.id WHERE o.venue_id=$1 AND o.opened_by=$2 AND p.created_at >= ($3::date::timestamp AT TIME ZONE $4) AND p.created_at < (($3::date + 1)::timestamp AT TIME ZONE $4) AND p.status IN ('paid','partially_paid')`, [venueDbId, actorId, date, timezone]);
        const row = rows[0] || {}; return json(res, 200, { date, revenue: Number(row.revenue || 0), employeeView: true });
      } catch (error) { return json(res, 503, { error: 'database_unavailable', detail: error.message }); }
    }
    if (repositories?.pool) {
      try {
        const totals = await repositories.pool.query(`
          SELECT COALESCE(SUM(p.amount), 0) AS revenue, COUNT(DISTINCT o.id)::int AS closed_orders, COUNT(p.id)::int AS payment_count
          FROM orders o JOIN payments p ON p.order_id=o.id
          WHERE o.venue_id=$1 AND o.status='closed'
            AND o.closed_at >= ($2::date::timestamp AT TIME ZONE $3) AND o.closed_at < (($2::date + 1)::timestamp AT TIME ZONE $3)
            AND p.status IN ('paid','partially_paid')`, [venueDbId, date, timezone]);
        const methods = await repositories.pool.query(`
          SELECT p.method, COALESCE(SUM(p.amount), 0) AS amount
          FROM orders o JOIN payments p ON p.order_id=o.id
          WHERE o.venue_id=$1 AND o.status='closed'
            AND o.closed_at >= ($2::date::timestamp AT TIME ZONE $3) AND o.closed_at < (($2::date + 1)::timestamp AT TIME ZONE $3)
            AND p.status IN ('paid','partially_paid')
          GROUP BY p.method ORDER BY p.method`, [venueDbId, date, timezone]);
        const pending = await repositories.pool.query(`
          SELECT COUNT(*)::int AS count FROM discounts d JOIN orders o ON o.id=d.order_id
          WHERE o.venue_id=$1 AND d.status='requested'`, [venueDbId]);
        const pendingTotals = await repositories.pool.query(`WITH item_totals AS (SELECT order_id, COALESCE(SUM(quantity * unit_price),0) AS subtotal FROM order_items GROUP BY order_id), discount_totals AS (SELECT order_id, COALESCE(SUM(CASE WHEN type='percent' THEN (SELECT COALESCE(SUM(oi.quantity * oi.unit_price),0) FROM order_items oi WHERE oi.order_id=d.order_id) * LEAST(100,GREATEST(0,value))/100 ELSE GREATEST(0,value) END),0) AS discount FROM discounts d WHERE status='approved' GROUP BY order_id), paid_totals AS (SELECT order_id, COALESCE(SUM(amount) FILTER (WHERE status IN ('paid','partially_paid')),0) AS paid FROM payments GROUP BY order_id) SELECT COUNT(*)::int AS pending_orders, COALESCE(SUM(GREATEST(0, GREATEST(COALESCE(o.vip_minimum,0),COALESCE(i.subtotal,0)-COALESCE(d.discount,0))-COALESCE(p.paid,0))),0) AS pending_revenue FROM orders o LEFT JOIN item_totals i ON i.order_id=o.id LEFT JOIN discount_totals d ON d.order_id=o.id LEFT JOIN paid_totals p ON p.order_id=o.id WHERE o.venue_id=$1 AND o.status IN ('open','in_progress','ready')`, [venueDbId]);
        const shiftStats = await repositories.pool.query(`WITH current_shift AS (SELECT id,venue_id FROM shifts WHERE venue_id=$1 AND closed_at IS NULL ORDER BY opened_at DESC LIMIT 1), closed_checks AS (SELECT o.id FROM orders o JOIN current_shift s ON s.venue_id=o.venue_id WHERE o.status='closed' AND o.closed_in_shift_id=s.id) SELECT COALESCE((SELECT SUM(p.amount) FROM payments p JOIN closed_checks c ON c.id=p.order_id WHERE p.status IN ('paid','partially_paid')),0) AS check_total, (SELECT COUNT(*)::int FROM closed_checks) AS orders FROM current_shift`, [venueDbId]);
        const row = totals.rows[0] || { revenue: 0, closed_orders: 0, payment_count: 0 }; const shiftRow = shiftStats.rows[0] || { check_total: 0, orders: 0 }; const shiftRevenue = Number(shiftRow.check_total || 0); const shiftOrders = Number(shiftRow.orders || 0);
        const fullSummary = { date, revenue: Number(row.revenue || 0), closedOrders: Number(row.closed_orders || 0), paymentCount: Number(row.payment_count || 0), byPaymentMethod: Object.fromEntries(methods.rows.map((entry) => [entry.method, Number(entry.amount || 0)])), currentShiftOrders: shiftOrders, currentShiftAverageCheck: shiftOrders ? shiftRevenue / shiftOrders : 0, pendingOrders: Number(pendingTotals.rows[0]?.pending_orders || 0), pendingRevenue: Number(pendingTotals.rows[0]?.pending_revenue || 0), pendingDiscounts: Number(pending.rows[0]?.count || 0) }; return json(res, 200, employeeFinanceView ? { date, revenue: fullSummary.revenue, employeeView: true } : fullSummary);
      } catch (error) {
        return json(res, 503, { error: 'database_unavailable', detail: error.message });
      }
    }
    if (employeeFinanceView) {
      const revenue = orders.filter((order) => String(order.openedBy || order.openedById || '') === String(req.user?.id || ''))
        .flatMap((order) => order.payments || [])
        .filter((payment) => ['paid', 'partially_paid'].includes(payment.status) && payment.createdAt && businessDateKey(payment.createdAt) === date)
        .reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
      return json(res, 200, { date, revenue, employeeView: true });
    }
    const closed = orders.filter((order) => order.status === 'closed' && businessDateKey(order.closedAt || order.createdAt) === date);
    const byType = {}; let revenue = 0; let paymentCount = 0;
    closed.forEach((order) => { const payments = (order.payments || []).filter((payment) => ['paid', 'partially_paid'].includes(payment.status)); if (payments.length) payments.forEach((payment) => { const amount = Number(payment.amount || 0); paymentCount += 1; revenue += amount; const key = payment.method || 'не указан'; byType[key] = (byType[key] || 0) + amount; }); else if (!employeeFinanceView) { const amount = Number(order.finalTotal !== undefined && order.finalTotal !== null ? order.finalTotal : orderNetTotal(order)); revenue += amount; const key = order.paymentMethod || 'не указан'; byType[key] = (byType[key] || 0) + amount; } });
    const pending = pendingPaymentSummary(); const currentShift = shifts.find((shift) => !shift.closedAt); const shiftClosed = currentShift ? orders.filter((order) => order.status === 'closed' && String(order.closedInShiftId || '') === String(currentShift.id)) : []; const shiftCheckTotal = shiftClosed.reduce((sum, order) => sum + (order.payments || []).filter((payment) => ['paid', 'partially_paid'].includes(payment.status)).reduce((orderSum, payment) => orderSum + Number(payment.amount || 0), 0), 0); const fullSummary = { date, revenue, closedOrders: closed.length, paymentCount, byPaymentMethod: byType, currentShiftOrders: shiftClosed.length, currentShiftAverageCheck: shiftClosed.length ? shiftCheckTotal / shiftClosed.length : 0, pendingOrders: pending.pendingOrders, pendingRevenue: pending.pendingRevenue, pendingDiscounts: discountRequests.filter((request) => request.status === 'requested').length }; return json(res, 200, employeeFinanceView ? { date, revenue, employeeView: true } : fullSummary);
  }
  if (pathname === '/api/finance/report' && req.method === 'GET') {
    if (process.env.AUTH_REQUIRED === 'true' && !hasPermission(req, 'finance') && !hasPermission(req, 'finance_read')) return json(res, 403, { error: 'forbidden', permission: 'finance_read' });
    const employeeFinanceView = isOperationalEmployee(req); const requestedDate = url.searchParams.get('date') || ''; let date = employeeFinanceView ? today() : (requestedDate || today()); let timezone = businessTimezone;
    if (repositories?.pool) {
      try { const context = await venueBusinessDateContext(repositories.pool, venueDbId); if (!context) return json(res, 503, { error: 'database_unavailable' }); timezone = context.timezone; if (employeeFinanceView || !requestedDate) date = context.date; }
      catch (error) { return json(res, 503, { error: 'database_unavailable', detail: error.message }); }
    }
    const requestedReportType = String(url.searchParams.get('type') || 'x');
    const type = ['x', 'z', 'waiter'].includes(requestedReportType) ? requestedReportType : 'x';
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return json(res, 400, { error: 'invalid_finance_date' });
    const reportNumber = `R-${date.replace(/-/g, '')}-${type.toUpperCase()}-${String(Date.now()).slice(-6)}`;
    if (employeeFinanceView && repositories?.pool) {
      try {
        const actorId = /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null;
        const { rows } = await repositories.pool.query(`SELECT COALESCE((SELECT SUM(p.amount) FROM orders o JOIN payments p ON p.order_id=o.id WHERE o.venue_id=$1 AND o.opened_by=$2 AND p.created_at >= ($3::date::timestamp AT TIME ZONE $4) AND p.created_at < (($3::date + 1)::timestamp AT TIME ZONE $4) AND p.status IN ('paid','partially_paid')),0) AS revenue, (SELECT COUNT(*)::int FROM orders o WHERE o.venue_id=$1 AND o.opened_by=$2 AND o.status='closed' AND o.closed_at >= ($3::date::timestamp AT TIME ZONE $4) AND o.closed_at < (($3::date + 1)::timestamp AT TIME ZONE $4)) AS checks_count`, [venueDbId, actorId, date, timezone]);
        const report = { type: 'x', date, generatedAt: new Date().toISOString(), reportNumber, checksCount: Number(rows[0]?.checks_count || 0), revenue: Number(rows[0]?.revenue || 0), employeeView: true };
        recordAudit(req, 'finance.report_generated', 'finance_report', reportNumber, null, { type: 'x', date, checksCount: report.checksCount, revenue: report.revenue });
        return json(res, 200, report);
      } catch (error) { return json(res, 503, { error: 'database_unavailable', detail: error.message }); }
    }
    const byPaymentMethod = {}; const byStation = {}; const byStaff = {}; let revenue = 0; let paymentCount = 0; let closedOrders = [];
    const addOrder = (order) => {
      const payments = (order.payments || []).filter((payment) => ['paid', 'partially_paid'].includes(payment.status));
      let orderRevenue = 0;
      if (payments.length) payments.forEach((payment) => { const amount = Number(payment.amount || 0); revenue += amount; orderRevenue += amount; paymentCount += 1; const key = payment.method || 'не указан'; byPaymentMethod[key] = (byPaymentMethod[key] || 0) + amount; });
      else if (!employeeFinanceView) { const amount = order.finalTotal !== undefined && order.finalTotal !== null ? Number(order.finalTotal) : Number(orderNetTotal(order)); orderRevenue = Number.isFinite(amount) ? amount : Number(orderTotal(order) || 0); revenue += orderRevenue; const key = order.paymentMethod || 'не указан'; byPaymentMethod[key] = (byPaymentMethod[key] || 0) + orderRevenue; paymentCount += orderRevenue > 0 ? 1 : 0; }
      const stationAllocations = allocateMoneyByGross(order.items || [], orderRevenue, (item) => item.station || 'other', (item) => Number(item.unitPrice || item.price || 0) * Number(item.quantity || 0));
      stationAllocations.forEach((amount, station) => { byStation[station] = (byStation[station] || 0) + amount; });
      const staffName = order.createdByName || order.waiterName || order.cashierName || 'Не указан'; byStaff[staffName] = (byStaff[staffName] || 0) + orderRevenue;
    };
    if (repositories?.pool) {
      try {
        const { rows } = await repositories.pool.query(`WITH item_totals AS (SELECT order_id,COALESCE(SUM(quantity*unit_price),0) AS subtotal FROM order_items GROUP BY order_id), discount_totals AS (SELECT d.order_id,COALESCE(SUM(CASE WHEN d.type='percent' THEN COALESCE(i.subtotal,0)*LEAST(100,GREATEST(0,d.value))/100 ELSE GREATEST(0,d.value) END),0) AS discount FROM discounts d LEFT JOIN item_totals i ON i.order_id=d.order_id WHERE d.status='approved' GROUP BY d.order_id) SELECT o.id,o.created_at AS "createdAt",o.closed_at AS "closedAt",COALESCE(u.full_name,u.login,'Не указан') AS "createdByName",GREATEST(0,GREATEST(COALESCE(o.vip_minimum,0),COALESCE(i.subtotal,0)-COALESCE(d.discount,0))) AS "finalTotal",COALESCE(json_agg(json_build_object('method',p.method,'amount',p.amount,'status',p.status)) FILTER (WHERE p.id IS NOT NULL),'[]') AS payments FROM orders o LEFT JOIN item_totals i ON i.order_id=o.id LEFT JOIN discount_totals d ON d.order_id=o.id LEFT JOIN payments p ON p.order_id=o.id LEFT JOIN users u ON u.id=o.opened_by WHERE o.venue_id=$1 AND o.status='closed' AND o.closed_at >= ($2::date::timestamp AT TIME ZONE $3) AND o.closed_at < (($2::date + 1)::timestamp AT TIME ZONE $3) GROUP BY o.id,u.full_name,u.login,i.subtotal,d.discount ORDER BY o.closed_at`, [venueDbId, date, timezone]);
        closedOrders = rows.map((row) => ({ ...row, payments: row.payments || [], items: [] }));
        const itemRows = await repositories.pool.query(`SELECT oi.order_id AS "orderId",oi.quantity,oi.unit_price AS "unitPrice",COALESCE(oi.station,'other') AS station FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.venue_id=$1 AND o.status='closed' AND o.closed_at >= ($2::date::timestamp AT TIME ZONE $3) AND o.closed_at < (($2::date + 1)::timestamp AT TIME ZONE $3)`, [venueDbId, date, timezone]);
        const itemsByOrder = new Map(); itemRows.rows.forEach((item) => { if (!itemsByOrder.has(item.orderId)) itemsByOrder.set(item.orderId, []); itemsByOrder.get(item.orderId).push(item); }); closedOrders.forEach((order) => { order.items = itemsByOrder.get(order.id) || []; addOrder(order); });
      } catch (error) { return json(res, 503, { error: 'database_unavailable', detail: error.message }); }
    } else { closedOrders = orders.filter((order) => order.status === 'closed' && businessDateKey(order.closedAt || order.createdAt) === date && (!employeeFinanceView || String(order.openedBy || order.openedById || '') === String(req.user?.id || ''))); closedOrders.forEach(addOrder); }
    const activeShift = repositories?.pool ? null : shifts.find((shift) => !shift.closedAt);
    const report = { type, date, generatedAt: new Date().toISOString(), reportNumber, cashier: req.user?.name || 'Кассир', checksCount: closedOrders.length, closedOrders: closedOrders.length, paymentCount, revenue: Math.round(revenue * 100) / 100, cash: Math.round(Number(byPaymentMethod.cash || 0) * 100) / 100, card: Math.round(Number(byPaymentMethod.card || 0) * 100) / 100, qr: Math.round(Number(byPaymentMethod.qr || 0) * 100) / 100, byPaymentMethod, byStation, byStaff: type === 'waiter' ? byStaff : undefined, shift: { id: activeShift?.id || null, status: activeShift ? 'open' : 'closed', isFinal: type === 'z' } };
    recordAudit(req, 'finance.report_generated', 'finance_report', reportNumber, null, { type, date, checksCount: report.checksCount, revenue: report.revenue });
    return json(res, 200, employeeFinanceView ? { type: 'x', date, generatedAt: report.generatedAt, reportNumber: report.reportNumber, checksCount: report.checksCount, revenue: report.revenue, employeeView: true } : report);
  }
  if (pathname === '/api/deliveries' && req.method === 'GET') {
    if (denyUnless(req, res, 'delivery')) return;
    if (process.env.DATABASE_URL) {
      try {
        const { rows } = await repositories.pool.query(`SELECT id,customer_name AS "customerName",phone,address,comment,total,payment_method AS "paymentMethod",status,courier,created_at AS "createdAt" FROM deliveries WHERE venue_id=$1 ORDER BY created_at DESC,id`, [venueDbId]);
        return json(res, 200, { items: rows.map((row) => ({ ...row, total: Number(row.total) })) });
      } catch (_) { return json(res, 503, { error: 'database_unavailable' }); }
    }
    return json(res, 200, { items: deliveries.filter((entry) => entry.venueId === venueDbId).map(({ venueId, ...entry }) => entry).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))) });
  }
  if (pathname === '/api/deliveries' && req.method === 'POST') {
    if (denyUnless(req, res, 'delivery')) return;
    const input = await body(req); const customerName = String(input.customerName || '').trim(); const phone = String(input.phone || '').trim(); const address = String(input.address || '').trim(); const rawTotal = Number(input.total ?? 0);
    const total = Math.round((rawTotal + Number.EPSILON) * 100) / 100;
    if (!customerName || customerName.length > 120 || !address || address.length > 500) return json(res, 400, { error: 'delivery_contact_required' });
    if (phone && !/^\+7[0-9 ()-]{7,24}$/.test(phone)) return json(res, 400, { error: 'invalid_guest_phone' });
    if (!Number.isFinite(rawTotal) || rawTotal < 0 || !Number.isFinite(total) || total > 999999999999.99) return json(res, 400, { error: 'invalid_delivery_total' });
    const delivery = { id: `delivery-${Date.now()}`, customerName, phone, address, comment: String(input.comment || '').trim().slice(0, 500), total, paymentMethod: ['cash', 'card', 'qr'].includes(input.paymentMethod) ? input.paymentMethod : 'cash', status: 'new', courier: '', createdAt: new Date().toISOString() };
    if (process.env.DATABASE_URL) {
      try {
        const { rows } = await repositories.pool.query(`INSERT INTO deliveries (venue_id,customer_name,phone,address,comment,total,payment_method) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id,customer_name AS "customerName",phone,address,comment,total,payment_method AS "paymentMethod",status,courier,created_at AS "createdAt"`, [venueDbId,customerName,phone,address,delivery.comment,total,delivery.paymentMethod]);
        const saved = { ...rows[0], total: Number(rows[0].total) };
        recordAudit(req, 'delivery.created', 'delivery', saved.id, null, saved);
        return json(res, 201, saved);
      } catch (_) { return json(res, 503, { error: 'database_unavailable' }); }
    }
    deliveries.push({ ...delivery, venueId: venueDbId }); recordAudit(req, 'delivery.created', 'delivery', delivery.id, null, delivery); return json(res, 201, delivery);
  }
  const deliveryPath = pathname.match(/^\/api\/deliveries\/([^/]+)$/);
  if (deliveryPath && req.method === 'PATCH') {
    if (denyUnless(req, res, 'delivery')) return;
    const input = await body(req);
    const allowed = ['new', 'confirmed', 'in_delivery', 'delivered', 'cancelled'];
    if (input.status !== undefined && !allowed.includes(input.status)) return json(res, 400, { error: 'invalid_delivery_status' });
    const courier = input.courier === undefined ? null : String(input.courier || '').trim().slice(0, 120);
    if (process.env.DATABASE_URL) {
      if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(deliveryPath[1])) return json(res, 404, { error: 'delivery_not_found' });
      let client;
      try {
        client = await repositories.pool.connect();
        await client.query('BEGIN');
        const fields = `id,customer_name AS "customerName",phone,address,comment,total,payment_method AS "paymentMethod",status,courier,created_at AS "createdAt"`;
        const prior = await client.query(`SELECT ${fields} FROM deliveries WHERE id=$1 AND venue_id=$2 FOR UPDATE`, [deliveryPath[1],venueDbId]);
        if (!prior.rows.length) {
          await client.query('ROLLBACK');
          return json(res, 404, { error: 'delivery_not_found' });
        }
        const { rows } = await client.query(`UPDATE deliveries SET status=COALESCE($3,status),courier=COALESCE($4,courier),updated_at=now() WHERE id=$1 AND venue_id=$2 RETURNING ${fields}`, [deliveryPath[1],venueDbId,input.status ?? null,courier]);
        await client.query('COMMIT');
        const saved = { ...rows[0], total: Number(rows[0].total) };
        const before = { ...prior.rows[0], total: Number(prior.rows[0].total) };
        recordAudit(req, 'delivery.updated', 'delivery', saved.id, before, saved);
        return json(res, 200, saved);
      } catch (_) {
        if (client) { try { await client.query('ROLLBACK'); } catch (_) {} }
        return json(res, 503, { error: 'database_unavailable' });
      } finally { client?.release(); }
    }
    const delivery = deliveries.find((entry) => entry.id === deliveryPath[1] && entry.venueId === venueDbId);
    if (!delivery) return json(res, 404, { error: 'delivery_not_found' });
    const { venueId, ...before } = delivery;
    if (input.status !== undefined) delivery.status = input.status;
    if (courier !== null) delivery.courier = courier;
    const { venueId: ignoredVenueId, ...saved } = delivery;
    recordAudit(req, 'delivery.updated', 'delivery', delivery.id, before, saved);
    return json(res, 200, saved);
  }
  if (pathname === '/api/tasks' && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['orders', 'staff_view'])) return;
    const ownTasksOnly = Boolean(req.user && !hasPermission(req, 'staff_manage') && !hasPermission(req, 'tasks_manage'));
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query(`SELECT t.id,t.title,t.description,t.status,t.priority,t.assignee_id AS "assigneeId",assigned_user.full_name AS "assigneeName",t.due_at AS "dueAt",to_char(t.due_date,'YYYY-MM-DD') AS "dueDate",t.created_at AS "createdAt",t.updated_at AS "updatedAt" FROM tasks t LEFT JOIN users assigned_user ON assigned_user.id=t.assignee_id AND assigned_user.venue_id=t.venue_id WHERE t.venue_id=$1 AND ($2::boolean=false OR t.assignee_id=$3) ORDER BY CASE t.priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END,COALESCE(t.due_at,t.due_date::timestamp AT TIME ZONE COALESCE((SELECT timezone FROM venues WHERE id=t.venue_id),'UTC')) NULLS LAST,t.created_at DESC`, [venueDbId, ownTasksOnly, req.user?.id || null]); return json(res, 200, { items: rows }); } catch (_) { return json(res, 503, { error: 'database_unavailable' }); } }
    const visibleTasks = ownTasksOnly ? tasks.filter((task) => String(task.assigneeId || '') === String(req.user.id)) : tasks;
    return json(res, 200, { items: visibleTasks.map((task) => ({ ...task, assigneeName: staff.find((person) => String(person.id) === String(task.assigneeId))?.name || task.assigneeName || null })) });
  }
  if (pathname === '/api/tasks' && req.method === 'POST') {
    if (denyUnlessAny(req, res, ['staff_manage', 'tasks_manage'])) return;
    const input = await body(req); const title = String(input.title || '').trim(); const description = String(input.description || '').trim(); const status = String(input.status || 'open'); const priority = String(input.priority || 'normal');
    if (!title || title.length > 160 || description.length > 2000 || !['open','in_progress','done','cancelled'].includes(status) || !['low','normal','high','urgent'].includes(priority)) return json(res, 400, { error: 'invalid_task' });
    const deadline = normalizeTaskDeadline(input);
    if (deadline.error) return json(res, 400, { error: deadline.error });
    if (process.env.AUTH_REQUIRED === 'true' && !input.assigneeId) return json(res, 400, { error: 'task_assignee_required' });
    if (repositories?.pool) { try { if (input.assigneeId) { const assignee = await repositories.pool.query('SELECT id FROM users WHERE id=$1 AND venue_id=$2 AND is_active=true AND deleted_at IS NULL', [String(input.assigneeId), venueDbId]); if (!assignee.rows[0]) return json(res, 400, { error: 'task_assignee_not_found' }); } const { rows } = await repositories.pool.query('INSERT INTO tasks (venue_id,title,description,status,priority,assignee_id,due_at,due_date,created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id,title,description,status,priority,assignee_id AS "assigneeId",due_at AS "dueAt",to_char(due_date,\'YYYY-MM-DD\') AS "dueDate",created_at AS "createdAt",updated_at AS "updatedAt"', [venueDbId,title,description,status,priority,input.assigneeId || null,deadline.dueAt || null,deadline.dueDate || null,/^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : null]); recordAudit(req, 'task.created', 'task', rows[0].id, null, rows[0]); return json(res, 201, rows[0]); } catch (error) { return json(res, 409, { error: 'task_create_failed', detail: error.message }); } }
    const assignedPerson = input.assigneeId ? staff.find((person) => String(person.id) === String(input.assigneeId) && person.active !== false && !person.deletedAt) : null;
    if (input.assigneeId && process.env.AUTH_REQUIRED === 'true' && !assignedPerson) return json(res, 400, { error: 'task_assignee_not_found' });
    const task = { id: `task-${Date.now()}`, title, description, status, priority, assigneeId: input.assigneeId || null, assigneeName: assignedPerson?.name || null, dueAt: deadline.dueAt || null, dueDate: deadline.dueDate || null, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }; tasks.push(task); recordAudit(req, 'task.created', 'task', task.id, null, task); return json(res, 201, task);
  }
  const taskPath = pathname.match(/^\/api\/tasks\/([^/]+)$/);
  if (taskPath && req.method === 'PATCH') {
    if (denyUnlessAny(req, res, ['orders', 'staff_view', 'staff_manage', 'tasks_manage'])) return;
    const input = await body(req); const canManageTasks = hasPermission(req, 'staff_manage') || hasPermission(req, 'tasks_manage'); const allowed = canManageTasks ? ['title','description','status','priority','assigneeId','dueAt','dueDate'] : ['status'];
    const invalidTaskTitle = input.title !== undefined && (!String(input.title).trim() || String(input.title).trim().length > 160);
    const invalidTaskDescription = input.description !== undefined && String(input.description).length > 2000;
    const deadline = normalizeTaskDeadline(input);
    if (invalidTaskTitle) return json(res, 400, { error: 'invalid_task_title' });
    if (invalidTaskDescription) return json(res, 400, { error: 'invalid_task_description' });
    if (deadline.error) return json(res, 400, { error: deadline.error });
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(taskPath[1])) { try { const { rows: taskRows } = await repositories.pool.query('SELECT id,assignee_id AS "assigneeId" FROM tasks WHERE id=$1 AND venue_id=$2', [taskPath[1], venueDbId]); const task = taskRows[0]; if (!task) return json(res, 404, { error: 'task_not_found' }); if (!canManageTasks && String(task.assigneeId || '') !== String(req.user?.id || '')) return json(res, 403, { error: 'task_update_forbidden' }); if (!canManageTasks && Object.keys(input).some((key) => !allowed.includes(key))) return json(res, 403, { error: 'task_update_forbidden' }); const fields = []; const values = [taskPath[1], venueDbId]; for (const key of allowed) if (input[key] !== undefined && !['dueAt','dueDate'].includes(key)) { if (key === 'status' && !['open','in_progress','done','cancelled'].includes(String(input[key]))) return json(res, 400, { error: 'invalid_task_status' }); if (key === 'priority' && !['low','normal','high','urgent'].includes(String(input[key]))) return json(res, 400, { error: 'invalid_task_priority' }); if (key === 'assigneeId' && input[key] !== null && input[key] !== '') { const assignee = await repositories.pool.query('SELECT 1 FROM users WHERE id=$1 AND venue_id=$2 AND is_active=true AND deleted_at IS NULL', [String(input[key]), venueDbId]); if (!assignee.rows[0]) return json(res, 400, { error: 'task_assignee_not_found' }); } fields.push(`${key === 'assigneeId' ? 'assignee_id' : key === 'dueAt' ? 'due_at' : key}=$${values.length + 1}`); values.push(key === 'title' || key === 'description' ? String(input[key] || '').trim() : key === 'dueAt' && input[key] === '' || key === 'assigneeId' && input[key] === '' ? null : input[key]); } if (deadline.changed) { fields.push(`due_at=$${values.length + 1}`, `due_date=$${values.length + 2}`); values.push(deadline.dueAt, deadline.dueDate); } if (!fields.length) return json(res, 400, { error: 'task_fields_required' }); fields.push('updated_at=now()'); const { rows } = await repositories.pool.query(`UPDATE tasks SET ${fields.join(',')} WHERE id=$1 AND venue_id=$2 RETURNING id,title,description,status,priority,assignee_id AS "assigneeId",due_at AS "dueAt",to_char(due_date,'YYYY-MM-DD') AS "dueDate",created_at AS "createdAt",updated_at AS "updatedAt"`, values); if (!rows[0]) return json(res, 404, { error: 'task_not_found' }); recordAudit(req, 'task.updated', 'task', rows[0].id, null, rows[0]); return json(res, 200, rows[0]); } catch (error) { return json(res, 409, { error: 'task_update_failed', detail: error.message }); } }
    const task = tasks.find((entry) => entry.id === taskPath[1]); if (!task) return json(res, 404, { error: 'task_not_found' }); if (!canManageTasks && String(task.assigneeId || '') !== String(req.user?.id || '')) return json(res, 403, { error: 'task_update_forbidden' }); if (!canManageTasks && Object.keys(input).some((key) => !allowed.includes(key))) return json(res, 403, { error: 'task_update_forbidden' }); if (input.status !== undefined && !['open','in_progress','done','cancelled'].includes(String(input.status))) return json(res, 400, { error: 'invalid_task_status' }); if (input.priority !== undefined && !['low','normal','high','urgent'].includes(String(input.priority))) return json(res, 400, { error: 'invalid_task_priority' }); if (input.assigneeId && process.env.AUTH_REQUIRED === 'true' && !staff.some((person) => String(person.id) === String(input.assigneeId) && person.active !== false && !person.deletedAt)) return json(res, 400, { error: 'task_assignee_not_found' }); Object.assign(task, input, deadline.changed ? { dueAt: deadline.dueAt, dueDate: deadline.dueDate } : {}, { assigneeId: input.assigneeId === undefined ? task.assigneeId : input.assigneeId === '' ? null : input.assigneeId, updatedAt: new Date().toISOString() }); return json(res, 200, task);
  }
  if (pathname === '/api/reservations' && req.method === 'GET') {
    if (denyUnless(req, res, 'reservations')) return;
    const date = url.searchParams.get('date');
    if (repositories?.reservations) { try { return json(res, 200, { items: await repositories.reservations.list(venueDbId, date) }); } catch (_) {} }
    return json(res, 200, { items: date ? reservations.filter((reservation) => reservation.date === date) : reservations });
  }
  if (pathname === '/api/reservations' && req.method === 'POST') {
    if (denyUnless(req, res, 'reservations')) return;
    const input = await body(req);
    if (!input.guestName || !input.date || !input.time || !input.tableId) return json(res, 400, { error: 'guest_date_time_table_required' });
    if (String(input.guestName).trim().length > 120) return json(res, 400, { error: 'guest_name_too_long' });
    if (input.notes !== undefined && String(input.notes).length > 2000) return json(res, 400, { error: 'reservation_notes_too_long' });
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(input.date)) || !/^\d{2}:\d{2}$/.test(String(input.time)) || Number.isNaN(Date.parse(`${input.date}T${input.time}:00`)) || Date.parse(`${input.date}T${input.time}:00`) <= Date.now()) return json(res, 400, { error: 'invalid_reservation_datetime' });
    if (input.phone && !/^\+7[0-9 ()-]{7,24}$/.test(String(input.phone).trim())) return json(res, 400, { error: 'invalid_guest_phone' });
    if (!Number.isInteger(Number(input.guests || 1)) || Number(input.guests || 1) < 1 || Number(input.guests || 1) > 50) return json(res, 400, { error: 'invalid_guest_count' });
    let tableMinimum = 0;
    let tableMaximum = 50;
    let tableName = input.tableId;
    let zoneName = '';
    let table = null;
    if (repositories?.pool) {
      try {
        const { rows } = await repositories.pool.query('SELECT t.name,t.status,t.capacity,t.max_capacity AS "maxCapacity",z.name AS "zoneName",t.min_order_total AS "minimumOrderTotal" FROM tables t JOIN zones z ON z.id=t.zone_id WHERE t.id=$1 AND z.venue_id=$2', [input.tableId, venueDbId]);
        if (!rows[0]) return json(res, 400, { error: 'table_not_found' });
        tableName = rows[0].name;
        zoneName = rows[0].zoneName || '';
        tableMaximum = Number(rows[0].maxCapacity || rows[0].capacity || 50);
        if (rows[0].status === 'blocked') return json(res, 409, { error: 'table_unavailable' });
        tableMinimum = Number(rows[0].minimumOrderTotal || 0);
      } catch (error) { return json(res, 409, { error: 'reservation_table_lookup_failed', detail: error.message }); }
    } else {
      const tableZone = floor.find((zone) => zone.tables.some((entry) => entry.id === input.tableId));
      table = tableZone?.tables.find((entry) => entry.id === input.tableId);
      if (!table) return json(res, 400, { error: 'table_not_found' });
      zoneName = tableZone.name || '';
      tableName = table.name;
      tableMaximum = Number(table.maxCapacity || table.capacity || 50);
      if (table.status === 'blocked') return json(res, 409, { error: 'table_unavailable' });
      tableMinimum = Number(table.minimumOrderTotal || 0);
    }
    if (Number(input.guests || 1) > tableMaximum) return json(res, 400, { error: 'table_capacity_exceeded', maximumGuests: tableMaximum });
    const deposit = Number(input.deposit || 0);
    if (!Number.isFinite(deposit) || deposit < tableMinimum) return json(res, 409, { error: 'vip_deposit_below_minimum', requiredDeposit: tableMinimum, providedDeposit: deposit });
    if (repositories?.pool) {
      try {
        const conflict = await repositories.pool.query(`SELECT r.id FROM reservations r JOIN venues v ON v.id=r.venue_id WHERE r.venue_id=$1 AND r.table_id=$2 AND r.starts_at=($3::timestamp AT TIME ZONE COALESCE(NULLIF(v.timezone,''),'Asia/Yekaterinburg')) AND r.status='confirmed' LIMIT 1`, [venueDbId, input.tableId, `${input.date}T${input.time}:00`]);
        if (conflict.rows[0]) return json(res, 409, { error: 'table_already_reserved', reservationId: conflict.rows[0].id });
      } catch (error) { return json(res, 409, { error: 'reservation_conflict_check_failed', detail: error.message }); }
    } else if (reservations.some((entry) => entry.status === 'confirmed' && entry.tableId === input.tableId && entry.date === input.date && entry.time === input.time)) {
      return json(res, 409, { error: 'table_already_reserved' });
    }
    if (repositories?.pool) { try { const reservation = await repositories.reservations.create({ ...input, tableName, zoneName, deposit, venueId: venueDbId }); recordAudit(req, 'reservation.created', 'reservation', reservation.id, null, reservation); return json(res, 201, reservation); } catch (error) { return json(res, 409, { error: 'reservation_create_failed', detail: error.message }); } }
    const reservation = { id: `res-${Date.now()}`, clientId: input.clientId || null, guestName: input.guestName, phone: input.phone || '', date: input.date, time: input.time, tableId: input.tableId, tableName, zoneName, guests: Number(input.guests || 1), status: 'confirmed', deposit, notes: input.notes || '', createdBy: req.user?.id || null, createdByName: String(input.createdByName || req.user?.name || 'Сотрудник').slice(0, 120), createdByRole: String(input.createdByRole || (req.user?.role === 'owner' ? 'Владелец' : req.user?.role === 'admin' ? 'Администратор' : 'Сотрудник')).slice(0, 40), createdAt: new Date().toISOString() };
    reservations.push(reservation);
    if (input.date === today()) table.status = 'reserved';
    recordAudit(req, 'reservation.created', 'reservation', reservation.id, null, reservation);
    return json(res, 201, reservation);
  }
  if (pathname.startsWith('/api/reservations/') && req.method === 'POST' && pathname.endsWith('/cancel')) {
    if (denyUnless(req, res, 'reservations')) return;
    const reservationId = pathname.split('/')[3];
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(reservationId)) {
      try {
        const { rows } = await repositories.pool.query(`UPDATE reservations SET status='cancelled' WHERE id=$1 AND venue_id=$2 AND status='confirmed' RETURNING id,table_id AS "tableId",starts_at AS "startsAt",status`, [reservationId, venueDbId]);
        if (!rows[0]) return json(res, 404, { error: 'reservation_not_found_or_cancelled' });
        await repositories.pool.query(`UPDATE tables t SET status=CASE WHEN EXISTS (SELECT 1 FROM orders o WHERE o.table_id=$1 AND o.venue_id=$2 AND o.status IN ('open','in_progress','ready')) THEN 'occupied'::table_status ELSE 'free'::table_status END FROM zones z WHERE t.id=$1 AND t.zone_id=z.id AND z.venue_id=$2 AND t.status <> 'blocked' AND NOT EXISTS (SELECT 1 FROM reservations WHERE table_id=$1 AND venue_id=$2 AND status='confirmed' AND starts_at::date=$3::date)`, [rows[0].tableId, venueDbId, rows[0].startsAt]);
        recordAudit(req, 'reservation.cancelled', 'reservation', rows[0].id, { status: 'confirmed' }, rows[0]);
        return json(res, 200, rows[0]);
      } catch (error) { return json(res, 409, { error: 'reservation_cancel_failed', detail: error.message }); }
    }
    const reservation = reservations.find((entry) => entry.id === pathname.split('/')[3]);
    if (!reservation) return json(res, 404, { error: 'reservation_not_found' });
    reservation.status = 'cancelled';
    const stillReserved = reservations.some((entry) => entry.id !== reservation.id && entry.status === 'confirmed' && entry.tableId === reservation.tableId && entry.date === reservation.date);
    if (!stillReserved) { const activeOrder = orders.some((order) => order.tableId === reservation.tableId && ['open', 'in_progress', 'ready'].includes(order.status)); setMemoryTableStatus(reservation.tableId, activeOrder ? 'occupied' : 'free'); }
    recordAudit(req, 'reservation.cancelled', 'reservation', reservation.id, { status: 'confirmed' }, reservation);
    return json(res, 200, reservation);
  }
  if (pathname === '/api/orders' && req.method === 'GET') {
    if (denyUnless(req, res, 'orders')) return;
    const requestedDate = url.searchParams.get('date');
    const validDate = requestedDate && /^\d{4}-\d{2}-\d{2}$/.test(requestedDate) ? requestedDate : null;
    const attentionOnly = url.searchParams.get('attention') === '1';
    const needsAttention = (order) => ['open','in_progress','ready'].includes(order.status) || Number(order.depositBalance || 0) > 0 || Number(order.paidAmount || 0) < Number(order.total || order.finalTotal || 0);
    if (orderRepository) {
      try { const result = await orderRepository.listOpen(venueDbId, url.searchParams.get('scope') === 'all'); const items = (attentionOnly ? result.filter(needsAttention) : result).filter((order) => !validDate || String(order.createdAt || '').slice(0, 10) === validDate); return json(res, 200, { items }); } catch (_) { return json(res, 503, { error: 'database_unavailable' }); }
    }
    const tableNames = new Map(floor.flatMap((zone) => zone.tables || []).map((table) => [table.id, table.name]));
    return json(res, 200, { items: (attentionOnly ? orders.filter(needsAttention) : orders).filter((order) => !validDate || String(order.createdAt || '').slice(0, 10) === validDate).map((order) => ({ ...order, tableName: tableNames.get(order.tableId) || order.tableName || null })) });
  }
  if (pathname === '/api/orders' && req.method === 'POST') {
    if (denyUnless(req, res, 'orders')) return;
    if (await requireOpenShift(req, res)) return;
    const input = await body(req);
    if (!input.tableId || typeof input.tableId !== 'string' || input.tableId.length > 80) return json(res, 400, { error: 'table_id_required' });
    const requestedMinimumOrderTotal = Number(input.minimumOrderTotal || 0);
    if (!Number.isFinite(requestedMinimumOrderTotal) || requestedMinimumOrderTotal < 0) return json(res, 400, { error: 'invalid_vip_minimum' });
    if (repositories?.orders) {
      try {
        const openedBy = /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : '20000000-0000-0000-0000-000000000001';
        const persisted = await repositories.orders.create({ venueId: venueDbId, tableId: input.tableId, openedBy, reservationId: input.reservationId, vipMinimum: requestedMinimumOrderTotal, notes: input.notes });
        recordAudit(req, 'order.created', 'order', persisted.id, null, persisted);
        return json(res, 201, { ...persisted, items: [] });
      } catch (error) { return json(res, 409, { error: 'order_create_failed', detail: error.message }); }
    }
    if (input.tableId && orders.some((entry) => entry.tableId === input.tableId && ['open', 'in_progress', 'ready'].includes(entry.status))) return json(res, 409, { error: 'table_has_active_order' });
    const tableMinimum = floor.flatMap((zone) => zone.tables || []).find((table) => table.id === input.tableId)?.minimumOrderTotal || 0;
    const minimumOrderTotal = Math.max(requestedMinimumOrderTotal, Number(tableMinimum));
    const order = { id: `ord-${Date.now()}`, tableId: input.tableId || null, status: 'open', orderType: input.orderType || 'regular', minimumOrderTotal, notes: input.notes || '', items: [], createdByName: req.user?.name || 'сотрудник', openedBy: req.user?.id || null, createdAt: new Date().toISOString() };
    orders.push(order);
    setMemoryTableStatus(order.tableId, 'occupied');
    recordAudit(req, 'order.created', 'order', order.id, null, order);
    return json(res, 201, order);
  }
  const orderEdit = pathname.match(/^\/api\/orders\/([^/]+)$/);
  if (orderEdit && req.method === 'PATCH') {
    if (denyUnless(req, res, 'orders')) return;
    const input = await body(req); if (input.notes === undefined && input.guestName === undefined && input.phone === undefined && input.clientId === undefined) return json(res, 400, { error: 'supported_fields_required' });
    if (input.clientId !== undefined && input.clientId !== null && String(input.clientId).length > 120) return json(res, 400, { error: 'invalid_client_id' });
    if (input.phone !== undefined && input.phone && !/^\+7[0-9 ()-]{7,24}$/.test(String(input.phone).trim())) return json(res, 400, { error: 'invalid_guest_phone' });
    if (input.guestName !== undefined && String(input.guestName).trim().length > 120) return json(res, 400, { error: 'guest_name_too_long' });
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(orderEdit[1])) {
      let client;
      try {
        client = await repositories.pool.connect();
        await client.query('BEGIN');
        const { rows: currentRows } = await client.query('SELECT status FROM orders WHERE id=$1 AND venue_id=$2 FOR UPDATE', [orderEdit[1], venueDbId]);
        if (!currentRows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'order_not_found' }); }
        if (!['open', 'in_progress', 'ready'].includes(currentRows[0].status)) { await client.query('ROLLBACK'); return json(res, 409, { error: 'order_not_editable' }); }
        let guest = null;
        if (input.clientId !== undefined && input.clientId !== null && String(input.clientId).trim()) {
          const { rows } = await client.query('SELECT id,phone,full_name AS "name" FROM guests WHERE id=$1 AND venue_id=$2', [String(input.clientId), venueDbId]);
          if (!rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'client_not_found' }); }
          guest = rows[0];
          await client.query('UPDATE orders SET guest_id=$1 WHERE id=$2 AND venue_id=$3', [guest.id, orderEdit[1], venueDbId]);
        } else if (input.guestName !== undefined || input.phone !== undefined) {
          const { rows } = await client.query(`INSERT INTO guests (venue_id,phone,full_name) VALUES ($1,$2,$3) ON CONFLICT (venue_id,phone) DO UPDATE SET full_name=EXCLUDED.full_name RETURNING id,phone,full_name AS "name"`, [venueDbId, String(input.phone || '').trim() || null, String(input.guestName || '').trim() || null]);
          guest = rows[0];
          await client.query('UPDATE orders SET guest_id=$1 WHERE id=$2 AND venue_id=$3', [guest.id, orderEdit[1], venueDbId]);
        }
        if (input.notes !== undefined) await client.query('UPDATE orders SET notes=$1 WHERE id=$2 AND venue_id=$3', [String(input.notes).slice(0, 2000), orderEdit[1], venueDbId]);
        const { rows } = await client.query(`SELECT o.id,o.notes,o.guest_id AS "guestId",g.phone,g.full_name AS "guestName" FROM orders o LEFT JOIN guests g ON g.id=o.guest_id WHERE o.id=$1 AND o.venue_id=$2`, [orderEdit[1], venueDbId]);
        await client.query('COMMIT');
        recordAudit(req, guest ? 'order.guest_updated' : 'order.notes_updated', 'order', rows[0].id, null, rows[0]); return json(res, 200, rows[0]);
      } catch (error) { if (client) await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'order_update_failed', detail: error.message }); } finally { client?.release(); }
    }
    const order = orders.find((entry) => entry.id === orderEdit[1]); if (!order) return json(res, 404, { error: 'order_not_found' }); if (!['open', 'in_progress', 'ready'].includes(order.status)) return json(res, 409, { error: 'order_not_editable' });
    const linkedClient = input.clientId !== undefined && input.clientId !== null && String(input.clientId).trim() ? clients.find((entry) => entry.id === String(input.clientId)) : null;
    if (input.clientId !== undefined && input.clientId !== null && String(input.clientId).trim() && !linkedClient) return json(res, 404, { error: 'client_not_found' });
    if (input.notes !== undefined) order.notes = String(input.notes).slice(0, 2000);
    if (linkedClient) { order.clientId = linkedClient.id; order.guestName = linkedClient.name; order.guestPhone = linkedClient.phoneNumbers?.find((phone) => phone.primary)?.number || linkedClient.phoneNumbers?.[0]?.number || ''; } else if (input.guestName !== undefined || input.phone !== undefined) { order.clientId = null; order.guestName = String(input.guestName || '').trim(); order.guestPhone = String(input.phone || '').trim(); }
    recordAudit(req, input.clientId !== undefined || input.guestName !== undefined || input.phone !== undefined ? 'order.guest_updated' : 'order.notes_updated', 'order', order.id, null, { notes: order.notes, clientId: order.clientId || null, guestName: order.guestName, guestPhone: order.guestPhone }); return json(res, 200, order);
  }
  const orderDelete = pathname.match(/^\/api\/orders\/([^/]+)$/);
  if (orderDelete && req.method === 'DELETE') {
    if (denyUnless(req, res, 'orders')) return;
    if (await requireOpenShift(req, res)) return;
    const input = await body(req); const comment = String(input.comment || input.reason || '').trim();
    if (!comment || comment.length > 1000) return json(res, 400, { error: 'order_delete_comment_required' });
    if (typeof input.writeoff !== 'boolean') return json(res, 400, { error: 'order_delete_writeoff_required' });
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(orderDelete[1])) {
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        const { rows: orderRows } = await client.query('SELECT id,status,table_id AS "tableId",notes FROM orders WHERE id=$1 AND venue_id=$2 FOR UPDATE', [orderDelete[1], venueDbId]);
        const persisted = orderRows[0]; if (!persisted) { await client.query('ROLLBACK'); return json(res, 404, { error: 'order_not_found' }); }
        if (!['open', 'in_progress', 'ready'].includes(persisted.status)) { await client.query('ROLLBACK'); return json(res, 409, { error: 'order_not_deletable', status: persisted.status }); }
        const deleteBalance = await pgOrderBalance(client, orderDelete[1]);
        if (Math.round(deleteBalance.paid * 100) > 0) { await client.query('ROLLBACK'); return json(res, 409, { error: 'paid_order_cannot_cancel', paid: deleteBalance.paid }); }
        const { rows: itemRows } = await client.query('SELECT oi.id,oi.product_id AS "productId",p.name,oi.quantity,oi.unit_price AS "unitPrice" FROM order_items oi LEFT JOIN products p ON p.id=oi.product_id WHERE oi.order_id=$1 ORDER BY oi.id', [orderDelete[1]]);
        let depletion = { totalCost: 0 };
        if (input.writeoff) depletion = await depleteRecipeForOrder(repositories.pool, orderDelete[1], venueDbId, req.user?.id, client);
        const note = `${String(persisted.notes || '').trim()}${persisted.notes ? '\n' : ''}Удаление: ${comment}`.slice(0, 4000);
        const { rows } = await client.query('UPDATE orders SET status=\'cancelled\',closed_at=COALESCE(closed_at,now()),notes=$1 WHERE id=$2 AND venue_id=$3 AND status IN (\'open\',\'in_progress\',\'ready\') RETURNING id,status,table_id AS "tableId",notes,closed_at AS "closedAt"', [note, orderDelete[1], venueDbId]);
        if (!rows[0]) { await client.query('ROLLBACK'); return json(res, 409, { error: 'order_not_deletable' }); }
        if (persisted.tableId) await client.query(`UPDATE tables t SET status=CASE WHEN EXISTS (SELECT 1 FROM reservations r WHERE r.table_id=$1 AND r.venue_id=$2 AND r.status='confirmed' AND r.starts_at::date=CURRENT_DATE) THEN 'reserved'::table_status ELSE 'free'::table_status END FROM zones z WHERE t.id=$1 AND t.zone_id=z.id AND z.venue_id=$2 AND t.status <> 'blocked' AND NOT EXISTS (SELECT 1 FROM orders o WHERE o.table_id=$1 AND o.venue_id=$2 AND o.status IN ('open','in_progress','ready'))`, [persisted.tableId, venueDbId]);
        await client.query('COMMIT');
        const notification = { type: 'order_deleted', orderId: rows[0].id, comment, writeoff: Boolean(input.writeoff), deletedItems: itemRows, totalCost: Number(depletion.totalCost || 0), createdAt: new Date().toISOString(), notificationRecipients: ['owner', 'admin', 'manager'] };
        recordAudit(req, 'order.deleted', 'order', rows[0].id, { status: persisted.status, items: itemRows }, { ...rows[0], ...notification });
        return json(res, 200, { ...rows[0], deleted: true, comment, writeoff: Boolean(input.writeoff), totalCost: Number(depletion.totalCost || 0), notification });
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); if (['product_inventory_mode_required','product_recipe_required','product_recipe_ambiguous','product_inventory_mode_invalid'].includes(error.code || error.message)) return json(res, 409, { error: error.code || error.message, productId: error.productId, productName: error.productName }); return json(res, 409, { error: error.message === 'insufficient_recipe_stock' ? 'insufficient_recipe_stock' : 'order_delete_failed', missing: error.missing, detail: error.message }); } finally { client.release(); }
    }
    const order = orders.find((entry) => entry.id === orderDelete[1]);
    if (!order) return json(res, 404, { error: 'order_not_found' });
    if (!['open', 'in_progress', 'ready'].includes(order.status)) return json(res, 409, { error: 'order_not_deletable', status: order.status });
    if (Math.round(receivedOrderPayments(order) * 100) > 0) return json(res, 409, { error: 'paid_order_cannot_cancel', paid: receivedOrderPayments(order) });
    let depletion = { totalCost: 0 };
    try { if (input.writeoff) depletion = depleteMemoryOrder(order); } catch (error) { if (['product_inventory_mode_required','product_recipe_required','product_recipe_ambiguous','product_inventory_mode_invalid'].includes(error.code || error.message)) return json(res, 409, { error: error.code || error.message, productId: error.productId, productName: error.productName }); return json(res, 409, { error: error.message === 'insufficient_recipe_stock' ? 'insufficient_recipe_stock' : 'order_delete_failed', missing: error.missing, detail: error.message }); }
    const notification = { type: 'order_deleted', orderId: order.id, comment, writeoff: Boolean(input.writeoff), deletedItems: order.items || [], totalCost: Number(depletion.totalCost || 0), createdAt: new Date().toISOString(), notificationRecipients: ['owner', 'admin', 'manager'] };
    order.status = 'cancelled'; order.notes = `${String(order.notes || '').trim()}${order.notes ? '\n' : ''}Удаление: ${comment}`.slice(0, 4000); order.closedAt = notification.createdAt;
    releaseMemoryTableIfIdle(order.tableId); staffNotifications.push({ id: `order-deleted-${crypto.randomUUID()}`, venueId: notificationVenueScope(req, venueDbId), ...notification }); recordAudit(req, 'order.deleted', 'order', order.id, { status: 'open', items: order.items || [] }, notification);
    return json(res, 200, { ...order, deleted: true, comment, writeoff: Boolean(input.writeoff), totalCost: Number(depletion.totalCost || 0), notification });
  }
  const orderAction = pathname.match(/^\/api\/orders\/([^/]+)\/(status|transfer)$/);
  if (orderAction && req.method === 'POST') {
    if (denyUnless(req, res, 'orders')) return;
    if (await requireOpenShift(req, res)) return;
    const input = await body(req);
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(orderAction[1])) {
      try {
        if (orderAction[2] === 'status') {
          const allowed = ['open', 'in_progress', 'ready', 'closed', 'cancelled'];
          if (!allowed.includes(input.status)) return json(res, 400, { error: 'invalid_order_status' });
          if (input.status === 'closed') return json(res, 409, { error: 'order_close_requires_payment', action: 'POST /api/orders/:id/close' });
            let client;
            try {
              client = await repositories.pool.connect();
              await client.query('BEGIN');
              const { rows: currentRows } = await client.query('SELECT id,status,table_id AS "tableId" FROM orders WHERE id=$1 AND venue_id=$2 FOR UPDATE', [orderAction[1], venueDbId]);
              if (!currentRows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'order_not_found' }); }
              if (!validOrderTransition(currentRows[0].status, input.status)) { await client.query('ROLLBACK'); return json(res, 409, { error: 'invalid_order_transition', from: currentRows[0].status, to: input.status }); }
              if (input.status === 'cancelled') { const balance = await pgOrderBalance(client, orderAction[1]); if (Math.round(balance.paid * 100) > 0) { await client.query('ROLLBACK'); return json(res, 409, { error: 'paid_order_cannot_cancel', paid: balance.paid }); } }
              const updateOrderStatusSql = input.status === 'cancelled'
                ? 'UPDATE orders SET status=$1,closed_at=COALESCE(closed_at,now()) WHERE id=$2 AND venue_id=$3 AND status=$4 RETURNING id,status,table_id AS "tableId"'
                : 'UPDATE orders SET status=$1 WHERE id=$2 AND venue_id=$3 AND status=$4 RETURNING id,status,table_id AS "tableId"';
              const { rows } = await client.query(updateOrderStatusSql, [input.status, orderAction[1], venueDbId, currentRows[0].status]);
              if (!rows[0]) { await client.query('ROLLBACK'); return json(res, 409, { error: 'order_state_changed' }); }
              if (['closed', 'cancelled'].includes(input.status) && rows[0].tableId) await client.query(`UPDATE tables t SET status=CASE WHEN EXISTS (SELECT 1 FROM reservations r WHERE r.table_id=$1 AND r.venue_id=$2 AND r.status='confirmed' AND r.starts_at::date=CURRENT_DATE) THEN 'reserved'::table_status ELSE 'free'::table_status END FROM zones z WHERE t.id=$1 AND t.zone_id=z.id AND z.venue_id=$2 AND t.status <> 'blocked' AND NOT EXISTS (SELECT 1 FROM orders o WHERE o.table_id=$1 AND o.venue_id=$2 AND o.status IN ('open','in_progress','ready'))`, [rows[0].tableId, venueDbId]);
              await client.query('COMMIT');
              recordAudit(req, 'order.status_changed', 'order', rows[0].id, { status: currentRows[0].status, tableId: rows[0].tableId }, rows[0]); return json(res, 200, rows[0]);
            } catch (error) { if (client) await client.query('ROLLBACK').catch(() => {}); throw error; } finally { client?.release(); }
        }
        if (typeof input.tableId !== 'string' || !input.tableId.trim() || input.tableId.length > 80) return json(res, 400, { error: 'table_id_required' });
        let client;
        try {
          client = await repositories.pool.connect();
          await client.query('BEGIN');
          const { rows: beforeRows } = await client.query('SELECT id,status,table_id AS "tableId" FROM orders WHERE id=$1 AND venue_id=$2 FOR UPDATE', [orderAction[1], venueDbId]);
          if (!beforeRows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'order_not_found' }); }
          if (!['open', 'in_progress', 'ready'].includes(beforeRows[0].status)) { await client.query('ROLLBACK'); return json(res, 409, { error: 'order_not_transferable' }); }
          const targetTable = await client.query("SELECT t.id FROM tables t JOIN zones z ON z.id=t.zone_id WHERE t.id=$1 AND z.venue_id=$2 AND t.status <> 'blocked' FOR UPDATE OF t", [input.tableId, venueDbId]);
          if (!targetTable.rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'target_table_not_found' }); }
          const occupied = await client.query(`SELECT id FROM orders WHERE venue_id=$1 AND table_id=$2 AND id<>$3 AND status IN ('open','in_progress','ready') LIMIT 1`, [venueDbId, input.tableId, orderAction[1]]);
          if (occupied.rows[0]) { await client.query('ROLLBACK'); return json(res, 409, { error: 'target_table_has_active_order' }); }
          const { rows } = await client.query('UPDATE orders SET table_id=$1 WHERE id=$2 AND venue_id=$3 AND status=$4 RETURNING id,status,table_id AS "tableId"', [input.tableId, orderAction[1], venueDbId, beforeRows[0].status]);
          if (!rows[0]) { await client.query('ROLLBACK'); return json(res, 409, { error: 'order_state_changed' }); }
          if (beforeRows[0].tableId && beforeRows[0].tableId !== rows[0].tableId) { await client.query(`UPDATE tables t SET status=CASE WHEN EXISTS (SELECT 1 FROM reservations r WHERE r.table_id=$1 AND r.venue_id=$2 AND r.status='confirmed' AND r.starts_at::date=CURRENT_DATE) THEN 'reserved'::table_status ELSE 'free'::table_status END FROM zones z WHERE t.id=$1 AND t.zone_id=z.id AND z.venue_id=$2 AND t.status <> 'blocked' AND NOT EXISTS (SELECT 1 FROM orders WHERE table_id=$1 AND venue_id=$2 AND status IN ('open','in_progress','ready'))`, [beforeRows[0].tableId, venueDbId]); await client.query(`UPDATE tables t SET status='occupied'::table_status FROM zones z WHERE t.id=$1 AND t.zone_id=z.id AND z.venue_id=$2 AND t.status <> 'blocked'`, [rows[0].tableId, venueDbId]); }
          await client.query('COMMIT');
          recordAudit(req, 'order.transferred', 'order', rows[0].id, beforeRows[0], rows[0]); return json(res, 200, rows[0]);
        } catch (error) { if (client) await client.query('ROLLBACK').catch(() => {}); throw error; } finally { client?.release(); }
      } catch (error) { return json(res, 409, { error: 'order_action_failed', detail: error.message }); }
    }
    const order = orders.find((entry) => entry.id === orderAction[1]);
    if (!order) return json(res, 404, { error: 'order_not_found' });
    if (orderAction[2] === 'status') {
       if (!['open', 'in_progress', 'ready', 'closed', 'cancelled'].includes(input.status)) return json(res, 400, { error: 'invalid_order_status' });
       if (input.status === 'closed') return json(res, 409, { error: 'order_close_requires_payment', action: 'POST /api/orders/:id/close' });
       if (!validOrderTransition(order.status, input.status)) return json(res, 409, { error: 'invalid_order_transition', from: order.status, to: input.status });
      if (input.status === 'cancelled' && Math.round(receivedOrderPayments(order) * 100) > 0) return json(res, 409, { error: 'paid_order_cannot_cancel', paid: receivedOrderPayments(order) });
      const before = { status: order.status, tableId: order.tableId }; order.status = input.status; if (input.status === 'closed') order.closedAt = new Date().toISOString();
      if (['closed', 'cancelled'].includes(input.status)) releaseMemoryTableIfIdle(order.tableId);
      recordAudit(req, 'order.status_changed', 'order', order.id, before, { status: order.status, tableId: order.tableId }); return json(res, 200, order);
    }
    if (typeof input.tableId !== 'string' || !input.tableId.trim() || input.tableId.length > 80) return json(res, 400, { error: 'table_id_required' });
    if (!['open', 'in_progress', 'ready'].includes(order.status)) return json(res, 409, { error: 'order_not_transferable' });
    const targetTable = floor.flatMap((zone) => zone.tables || []).find((table) => table.id === input.tableId.trim() && table.status !== 'blocked');
    if (!targetTable) return json(res, 404, { error: 'target_table_not_found' });
    if (orders.some((entry) => entry.id !== order.id && entry.tableId === input.tableId.trim() && ['open', 'in_progress', 'ready'].includes(entry.status))) return json(res, 409, { error: 'target_table_has_active_order' });
    const before = { tableId: order.tableId }; const previousTable = order.tableId; order.tableId = input.tableId.trim(); setMemoryTableStatus(order.tableId, 'occupied'); releaseMemoryTableIfIdle(previousTable); recordAudit(req, 'order.transferred', 'order', order.id, before, { tableId: order.tableId }); return json(res, 200, order);
  }
  const itemMatch = pathname.match(/^\/api\/orders\/([^/]+)\/items$/);
  if (itemMatch && req.method === 'POST') {
    if (denyUnless(req, res, 'orders')) return;
    if (await requireOpenShift(req, res)) return;
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(itemMatch[1])) {
      const input = await body(req); const quantity = Number(input.quantity || 1); if (!Number.isInteger(quantity) || quantity < 1 || quantity > 999) return json(res, 400, { error: 'quantity_must_be_positive' });
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        const { rows: orderRows } = await client.query('SELECT id,status,vip_minimum AS "minimumOrderTotal" FROM orders WHERE id=$1 AND venue_id=$2 FOR UPDATE', [itemMatch[1], venueDbId]);
        if (!orderRows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'order_not_found' }); }
        if (!['open', 'in_progress', 'ready'].includes(orderRows[0].status)) { await client.query('ROLLBACK'); return json(res, 409, { error: 'order_not_editable' }); }
        const { rows: productRows } = await client.query('SELECT id,name,sale_price AS "unitPrice",category AS station FROM products WHERE id=$1 AND venue_id=$2 AND is_active=true FOR UPDATE', [input.productId, venueDbId]);
        const product = productRows[0];
        if (!product) { await client.query('ROLLBACK'); return json(res, 400, { error: 'product_not_found' }); }
        const { rows: existingRows } = await client.query('SELECT id,product_id AS "productId",quantity,unit_price AS "unitPrice",station FROM order_items WHERE order_id=$1 AND product_id=$2 AND unit_price=$3 ORDER BY id LIMIT 1', [itemMatch[1], product.id, product.unitPrice]);
        let result;
        let status;
        if (existingRows[0]) {
          const nextQuantity = Number(existingRows[0].quantity) + quantity;
          if (nextQuantity > 999) { await client.query('ROLLBACK'); return json(res, 400, { error: 'quantity_must_be_positive' }); }
          const { rows } = await client.query('UPDATE order_items SET quantity=$1 WHERE id=$2 RETURNING id,product_id AS "productId",quantity,unit_price AS "unitPrice",station', [nextQuantity, existingRows[0].id]);
          result = { ...rows[0], quantity: Number(rows[0].quantity), unitPrice: Number(rows[0].unitPrice), name: product.name }; status = 200;
        } else {
          const { rows } = await client.query('INSERT INTO order_items (order_id,product_id,quantity,unit_price,station) VALUES ($1,$2,$3,$4,$5) RETURNING id,product_id AS "productId",quantity,unit_price AS "unitPrice",station', [itemMatch[1], product.id, quantity, product.unitPrice, product.station]);
          result = { ...rows[0], quantity: Number(rows[0].quantity), unitPrice: Number(rows[0].unitPrice), name: product.name }; status = 201;
        }
        const balance = await pgOrderBalance(client, itemMatch[1], orderRows[0].minimumOrderTotal);
        if (orderBalanceConflict(balance)) { await client.query('ROLLBACK'); return json(res, 409, orderBalanceConflictBody(balance)); }
        await client.query('COMMIT');
        recordAudit(req, existingRows[0] ? 'order.item_quantity_increased' : 'order.item_added', 'order_item', result.id, existingRows[0] || null, result);
        return json(res, status, result);
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'order_item_create_failed', detail: error.message }); } finally { client.release(); }
    }
    const order = orders.find((entry) => entry.id === itemMatch[1]);
    if (order && !['open', 'in_progress', 'ready'].includes(order.status)) return json(res, 409, { error: 'order_not_editable' });
    const input = await body(req); const quantity = Number(input.quantity || 1);
    const product = products.find((entry) => entry.id === input.productId);
    if (!order) return json(res, 404, { error: 'order_not_found' });
    if (!product) return json(res, 400, { error: 'product_not_found' });
    if (!Number.isFinite(quantity) || quantity < 1) return json(res, 400, { error: 'quantity_must_be_positive' });
    const existing = order.items.find((entry) => entry.productId === product.id && Number(entry.unitPrice) === Number(product.price));
    if (existing) { const nextQuantity = Number(existing.quantity || 0) + quantity; if (nextQuantity > 999) return json(res, 400, { error: 'quantity_must_be_positive' }); const before = { ...existing }; existing.quantity = nextQuantity; const balance = memoryOrderBalance(order); if (orderBalanceConflict(balance)) { existing.quantity = before.quantity; return json(res, 409, orderBalanceConflictBody(balance)); } recordAudit(req, 'order.item_quantity_increased', 'order_item', existing.id, before, existing); return json(res, 200, existing); }
    const item = { id: `item-${Date.now()}`, productId: product.id, name: product.name, quantity, unitPrice: product.price, station: product.station };
    order.items.push(item);
    const balance = memoryOrderBalance(order); if (orderBalanceConflict(balance)) { order.items.pop(); return json(res, 409, orderBalanceConflictBody(balance)); }
    recordAudit(req, 'order.item_added', 'order_item', item.id, null, item);
    return json(res, 201, item);
  }
  const itemAction = pathname.match(/^\/api\/orders\/([^/]+)\/items\/([^/]+)$/);
  if (itemAction && (req.method === 'PATCH' || req.method === 'DELETE')) {
    if (denyUnless(req, res, 'orders')) return;
    if (await requireOpenShift(req, res)) return;
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(itemAction[1]) && /^[0-9a-f-]{36}$/i.test(itemAction[2])) {
      let client;
      try {
        const input = req.method === 'PATCH' ? await body(req) : {};
        const quantity = req.method === 'PATCH' ? Number(input.quantity) : null;
        if (req.method === 'PATCH' && (!Number.isInteger(quantity) || quantity < 1 || quantity > 999)) return json(res, 400, { error: 'quantity_must_be_positive' });
        client = await repositories.pool.connect();
        await client.query('BEGIN');
        const { rows: orderRows } = await client.query('SELECT id,status,vip_minimum AS "minimumOrderTotal" FROM orders WHERE id=$1 AND venue_id=$2 FOR UPDATE', [itemAction[1], venueDbId]);
        if (!orderRows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'order_not_found' }); }
        if (!['open', 'in_progress', 'ready'].includes(orderRows[0].status)) { await client.query('ROLLBACK'); return json(res, 409, { error: 'order_not_editable' }); }
        const query = req.method === 'DELETE'
          ? await client.query('DELETE FROM order_items WHERE id=$1 AND order_id=$2 RETURNING id,quantity,unit_price AS "unitPrice"', [itemAction[2], itemAction[1]])
          : await client.query('UPDATE order_items SET quantity=$1 WHERE id=$2 AND order_id=$3 RETURNING id,quantity,unit_price AS "unitPrice"', [quantity, itemAction[2], itemAction[1]]);
        if (!query.rows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'order_item_not_found' }); }
        const balance = await pgOrderBalance(client, itemAction[1], orderRows[0].minimumOrderTotal);
        if (orderBalanceConflict(balance)) { await client.query('ROLLBACK'); return json(res, 409, orderBalanceConflictBody(balance)); }
        await client.query('COMMIT');
        recordAudit(req, req.method === 'DELETE' ? 'order.item_removed' : 'order.item_quantity_changed', 'order_item', query.rows[0].id, null, req.method === 'DELETE' ? null : query.rows[0]);
        return json(res, 200, { ...query.rows[0], quantity: Number(query.rows[0].quantity), unitPrice: Number(query.rows[0].unitPrice) });
      } catch (error) { if (client) await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'order_item_update_failed', detail: error.message }); } finally { client?.release(); }
    }
    const order = orders.find((entry) => entry.id === itemAction[1]); if (order && !['open', 'in_progress', 'ready'].includes(order.status)) return json(res, 409, { error: 'order_not_editable' }); const item = order?.items?.find((entry) => entry.id === itemAction[2]); if (!item) return json(res, 404, { error: 'order_item_not_found' });
    if (req.method === 'DELETE') { const beforeItems = order.items; order.items = order.items.filter((entry) => entry.id !== item.id); const balance = memoryOrderBalance(order); if (orderBalanceConflict(balance)) { order.items = beforeItems; return json(res, 409, orderBalanceConflictBody(balance)); } recordAudit(req, 'order.item_removed', 'order_item', item.id, item, null); return json(res, 200, { id: item.id }); }
    const input = await body(req); const quantity = Number(input.quantity); if (!Number.isInteger(quantity) || quantity < 1 || quantity > 999) return json(res, 400, { error: 'quantity_must_be_positive' }); const beforeQuantity = item.quantity; item.quantity = quantity; const balance = memoryOrderBalance(order); if (orderBalanceConflict(balance)) { item.quantity = beforeQuantity; return json(res, 409, orderBalanceConflictBody(balance)); } recordAudit(req, 'order.item_quantity_changed', 'order_item', item.id, { quantity: beforeQuantity }, item); return json(res, 200, item);
  }
  const paymentPath = pathname.match(/^\/api\/orders\/([^/]+)\/payments$/);
  if (paymentPath && (req.method === 'GET' || req.method === 'POST')) {
    if (denyUnless(req, res, 'orders')) return;
    if (req.method === 'POST' && await requireOpenShift(req, res)) return;
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(paymentPath[1])) {
      if (req.method === 'GET') {
        try {
          const { rows: orderRows } = await repositories.pool.query('SELECT id,status,vip_minimum AS "minimumOrderTotal" FROM orders WHERE id=$1 AND venue_id=$2', [paymentPath[1], venueDbId]);
          const persisted = orderRows[0]; if (!persisted) return json(res, 404, { error: 'order_not_found' });
          const { rows: itemRows } = await repositories.pool.query('SELECT quantity,unit_price AS "unitPrice" FROM order_items WHERE order_id=$1', [paymentPath[1]]);
          const subtotal = itemRows.reduce((sum, item) => sum + Number(item.quantity) * Number(item.unitPrice), 0); const { rows: discountRows } = await repositories.pool.query('SELECT type,value FROM discounts WHERE order_id=$1 AND status=\'approved\'', [paymentPath[1]]); const discount = discountRows.reduce((sum, item) => sum + (item.type === 'percent' ? subtotal * Math.min(100, Math.max(0, Number(item.value || 0))) / 100 : Math.max(0, Number(item.value || 0))), 0); const due = roundMoney(Math.max(subtotal - discount, Number(persisted.minimumOrderTotal || 0)));
          const { rows } = await repositories.pool.query('SELECT id,method,amount,status,created_at AS "createdAt" FROM payments WHERE order_id=$1 ORDER BY created_at', [paymentPath[1]]); const paid = rows.filter((item) => ['paid', 'partially_paid'].includes(item.status)).reduce((sum, item) => sum + Number(item.amount), 0);
          return json(res, 200, { items: rows, due, paid, remaining: Math.max(0, due - paid) });
        } catch (error) { return json(res, 409, { error: 'payment_create_failed', detail: error.message }); }
      }

      const input = await body(req); const amount = Number(input.amount); const method = String(input.method || 'cash');
      if (!validPaymentAmount(amount) || !['cash', 'card', 'qr'].includes(method)) return json(res, 400, { error: 'valid_method_and_amount_required' });
      let client;
      try {
        client = await repositories.pool.connect();
        await client.query('BEGIN');
        // Serialize concurrent payments and close requests using the same order lock.
        const { rows: orderRows } = await client.query('SELECT id,status,table_id AS "tableId",vip_minimum AS "minimumOrderTotal" FROM orders WHERE id=$1 AND venue_id=$2 FOR UPDATE', [paymentPath[1], venueDbId]);
        const persisted = orderRows[0];
        if (!persisted) { await client.query('ROLLBACK'); return json(res, 404, { error: 'order_not_found' }); }
        if (persisted.status === 'closed' || persisted.status === 'cancelled') { await client.query('ROLLBACK'); return json(res, 409, { error: 'order_already_final' }); }
        const { rows: shiftRows } = await client.query('SELECT id FROM shifts WHERE venue_id=$1 AND closed_at IS NULL ORDER BY opened_at DESC LIMIT 1 FOR UPDATE', [venueDbId]);
        const activeShiftId = shiftRows[0]?.id;
        if (!activeShiftId) { await client.query('ROLLBACK'); return json(res, 409, { error: 'open_shift_required' }); }
        const { rows: itemRows } = await client.query('SELECT quantity,unit_price AS "unitPrice" FROM order_items WHERE order_id=$1', [paymentPath[1]]);
        const subtotal = itemRows.reduce((sum, item) => sum + Number(item.quantity) * Number(item.unitPrice), 0);
        const { rows: discountRows } = await client.query('SELECT type,value FROM discounts WHERE order_id=$1 AND status=\'approved\'', [paymentPath[1]]);
        const discount = discountRows.reduce((sum, item) => sum + (item.type === 'percent' ? subtotal * Math.min(100, Math.max(0, Number(item.value || 0))) / 100 : Math.max(0, Number(item.value || 0))), 0);
        const due = roundMoney(Math.max(subtotal - discount, Number(persisted.minimumOrderTotal || 0)));
        const { rows: paidRows } = await client.query("SELECT COALESCE(SUM(amount),0) AS paid FROM payments WHERE order_id=$1 AND status IN ('paid','partially_paid')", [paymentPath[1]]);
        const paid = Number(paidRows[0]?.paid || 0);
        if (orderBalanceConflict({ due, paid: paid + amount })) { await client.query('ROLLBACK'); return json(res, 409, { error: 'payment_exceeds_due', remaining: Math.max(0, due - paid) }); }
        const { rows } = await client.query('INSERT INTO payments (order_id,method,amount,status,shift_id) VALUES ($1,$2,$3,\'paid\',$4) RETURNING id,method,amount,status,shift_id AS "shiftId",created_at AS "createdAt"', [paymentPath[1], method, amount, activeShiftId]);
        const nextPaid = paid + amount;
        const closed = moneyCents(nextPaid) >= moneyCents(due);
        const finalMeta = closed ? { finalTotal: due, discountTotal: discount, minimumAdjustment: Math.max(0, Number(persisted.minimumOrderTotal || 0) - (subtotal - discount)), paymentMethod: paid > 0 ? 'mixed' : method } : {};
        if (closed) {
          const depletion = await depleteRecipeForOrder(repositories.pool, paymentPath[1], venueDbId, req.user?.id, client);
          const { rows: closedRows } = await client.query('UPDATE orders SET status=\'closed\',closed_at=now(),closed_in_shift_id=$3 WHERE id=$1 AND venue_id=$2 AND status NOT IN (\'closed\',\'cancelled\') RETURNING id', [paymentPath[1], venueDbId, activeShiftId]);
          if (!closedRows[0]) throw Object.assign(new Error('order_already_final'), { code: 'order_already_final' });
          await client.query('INSERT INTO order_costs (venue_id,order_id,cost) VALUES ($1,$2,$3) ON CONFLICT (order_id) DO UPDATE SET cost=EXCLUDED.cost', [venueDbId, paymentPath[1], depletion.totalCost]);
          if (persisted.tableId) await client.query(`UPDATE tables t SET status=CASE WHEN EXISTS (SELECT 1 FROM reservations r WHERE r.table_id=$1 AND r.venue_id=$2 AND r.status=\'confirmed\' AND r.starts_at::date=CURRENT_DATE) THEN \'reserved\'::table_status ELSE \'free\'::table_status END FROM zones z WHERE t.id=$1 AND t.zone_id=z.id AND z.venue_id=$2 AND t.status <> \'blocked\'::table_status AND NOT EXISTS (SELECT 1 FROM orders o WHERE o.table_id=$1 AND o.venue_id=$2 AND o.status IN (\'open\',\'in_progress\',\'ready\'))`, [persisted.tableId, venueDbId]);
        }
        const response = { ...rows[0], due, paid: nextPaid, remaining: Math.max(0, due - nextPaid), closed, ...finalMeta };
        await client.query('COMMIT');
        recordAudit(req, 'order.payment_added', 'payment', rows[0].id, null, { ...rows[0], orderId: paymentPath[1], paid: nextPaid, due, closed });
        return json(res, 201, response);
      } catch (error) {
        if (client) await client.query('ROLLBACK').catch(() => {});
        if (error.message === 'expired_premix_stock') return json(res, 409, { error: 'expired_premix_stock' }); if (error.message === 'insufficient_recipe_stock') return json(res, 409, { error: 'insufficient_recipe_stock', missing: error.missing });
        if (['product_inventory_mode_required','product_recipe_required','product_recipe_ambiguous','product_inventory_mode_invalid'].includes(error.code || error.message)) return json(res, 409, { error: error.code || error.message, productId: error.productId, productName: error.productName });
        if (['recipe_invalid', 'recipe_ingredient_not_found', 'recipe_ingredient_unit_mismatch', 'invalid_recipe_quantity'].includes(error.code || error.message)) return json(res, 409, { error: error.code || error.message, ingredient: error.ingredient, sourceUnit: error.sourceUnit, targetUnit: error.targetUnit });
        if (error.code === 'order_already_final') return json(res, 409, { error: 'order_already_final' });
        return json(res, 409, { error: 'payment_create_failed', detail: error.message });
      } finally {
        client?.release();
      }
    }
    const order = orders.find((entry) => entry.id === paymentPath[1]); if (!order) return json(res, 404, { error: 'order_not_found' }); if (req.method === 'POST' && (order.status === 'closed' || order.status === 'cancelled')) return json(res, 409, { error: 'order_already_final' }); order.payments ||= []; const subtotal = orderTotal(order); const discount = approvedDiscountTotal(order.id, subtotal); const due = roundMoney(Math.max(subtotal - discount, Number(order.minimumOrderTotal || 0))); const paid = receivedOrderPayments(order);
    if (req.method === 'GET') return json(res, 200, { items: order.payments, due, paid, remaining: Math.max(0, due - paid) });
    const input = await body(req); const amount = Number(input.amount); const method = String(input.method || 'cash'); if (!validPaymentAmount(amount) || !['cash', 'card', 'qr'].includes(method)) return json(res, 400, { error: 'valid_method_and_amount_required' }); if (orderBalanceConflict({ due, paid: paid + amount })) return json(res, 409, { error: 'payment_exceeds_due', remaining: Math.max(0, due - paid) }); const activeShift = shifts.find((shift) => !shift.closedAt); if (!activeShift) return json(res, 409, { error: 'open_shift_required' }); const nextPaid = paid + amount; const closed = moneyCents(nextPaid) >= moneyCents(due); let depletion = null; if (closed) { try { depletion = depleteMemoryOrder(order); } catch (error) { if (error.message === 'expired_premix_stock') return json(res, 409, { error: 'expired_premix_stock' }); if (error.message === 'insufficient_recipe_stock') return json(res, 409, { error: 'insufficient_recipe_stock', missing: error.missing }); if (['product_inventory_mode_required','product_recipe_required','product_recipe_ambiguous','product_inventory_mode_invalid'].includes(error.code || error.message)) return json(res, 409, { error: error.code || error.message, productId: error.productId, productName: error.productName }); if (['recipe_invalid', 'recipe_ingredient_not_found', 'recipe_ingredient_unit_mismatch', 'invalid_recipe_quantity'].includes(error.code || error.message)) return json(res, 409, { error: error.code || error.message, ingredient: error.ingredient, sourceUnit: error.sourceUnit, targetUnit: error.targetUnit }); return json(res, 409, { error: 'recipe_depletion_failed', detail: error.message }); } } const payment = { id: `pay-${Date.now()}`, method, amount, status: 'paid', shiftId: activeShift.id, createdAt: new Date().toISOString() }; order.payments.push(payment); if (closed) { order.status = 'closed'; order.closedAt = payment.createdAt; order.closedInShiftId = activeShift.id; order.subtotal = subtotal; order.discountTotal = discount; order.finalTotal = due; order.minimumAdjustment = Math.max(0, Number(order.minimumOrderTotal || 0) - (subtotal - discount)); order.paymentMethod = order.payments.length === 1 ? method : 'mixed'; order.paid = nextPaid; order.remaining = 0; order.costOfGoods = Number(depletion?.totalCost || 0); releaseMemoryTableIfIdle(order.tableId); } recordAudit(req, 'order.payment_added', 'payment', payment.id, null, { ...payment, orderId: order.id, paid: nextPaid, due, closed, costOfGoods: closed ? order.costOfGoods : undefined }); return json(res, 201, { ...payment, due, paid: nextPaid, remaining: Math.max(0, due - nextPaid), closed, ...(closed ? { finalTotal: order.finalTotal, discountTotal: order.discountTotal, minimumAdjustment: order.minimumAdjustment, paymentMethod: order.paymentMethod, costOfGoods: order.costOfGoods } : {}) });
  }
  const orderPath = pathname.match(/^\/api\/orders\/([^/]+)\/(summary|close|split|discount-requests)$/);
  if (orderPath && req.method === 'GET' && orderPath[2] === 'summary') {
    if (denyUnless(req, res, 'orders')) return;
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(orderPath[1])) {
      try {
        const { rows: orderRows } = await repositories.pool.query('SELECT id,vip_minimum AS "minimumOrderTotal" FROM orders WHERE id=$1 AND venue_id=$2', [orderPath[1], venueDbId]);
        if (!orderRows[0]) return json(res, 404, { error: 'order_not_found' });
        const { rows: itemRows } = await repositories.pool.query('SELECT quantity,unit_price AS "unitPrice" FROM order_items WHERE order_id=$1', [orderPath[1]]);
        const total = itemRows.reduce((sum, item) => sum + Number(item.quantity) * Number(item.unitPrice), 0);
        const minimum = Number(orderRows[0].minimumOrderTotal || 0);
        return json(res, 200, { orderId: orderRows[0].id, total, minimum, shortfall: Math.max(0, minimum - total), minimumApplied: minimum > 0 });
      } catch (error) { return json(res, 503, { error: 'database_unavailable', detail: error.message }); }
    }
    const order = orders.find((entry) => entry.id === orderPath[1]);
    return order ? json(res, 200, vipSummary(order)) : json(res, 404, { error: 'order_not_found' });
  }
  if (orderPath && req.method === 'POST' && orderPath[2] === 'close') {
    if (denyUnless(req, res, 'orders')) return;
    if (await requireOpenShift(req, res)) return;
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(orderPath[1])) {
      const input = await body(req); const paymentMethod = String(input.paymentMethod || 'cash'); if (!['cash', 'card', 'qr'].includes(paymentMethod)) return json(res, 400, { error: 'valid_payment_method_required' });
      let client;
      let result;
      try {
        client = await repositories.pool.connect();
        await client.query('BEGIN');
        // Serialize concurrent close attempts before reading totals or depleting stock.
        const { rows: orderRows } = await client.query('SELECT id,status,table_id AS "tableId",vip_minimum AS "minimumOrderTotal" FROM orders WHERE id=$1 AND venue_id=$2 FOR UPDATE', [orderPath[1], venueDbId]);
        const persisted = orderRows[0];
        if (!persisted) {
          await client.query('ROLLBACK');
          return json(res, 404, { error: 'order_not_found' });
        }
        if (['closed', 'cancelled'].includes(persisted.status)) {
          await client.query('ROLLBACK');
          return json(res, 409, { error: 'order_already_final' });
        }

        const { rows: shiftRows } = await client.query('SELECT id FROM shifts WHERE venue_id=$1 AND closed_at IS NULL ORDER BY opened_at DESC LIMIT 1 FOR UPDATE', [venueDbId]);
        const activeShiftId = shiftRows[0]?.id;
        if (!activeShiftId) { await client.query('ROLLBACK'); return json(res, 409, { error: 'open_shift_required' }); }

        const { rows: itemRows } = await client.query('SELECT quantity,unit_price AS "unitPrice" FROM order_items WHERE order_id=$1', [orderPath[1]]);
        const subtotal = itemRows.reduce((sum, item) => sum + Number(item.quantity) * Number(item.unitPrice), 0);
        const { rows: discountRows } = await client.query('SELECT type,value FROM discounts WHERE order_id=$1 AND status=\'approved\'', [orderPath[1]]);
        const discount = discountRows.reduce((sum, item) => sum + (item.type === 'percent' ? subtotal * Math.min(100, Math.max(0, Number(item.value || 0))) / 100 : Math.max(0, Number(item.value || 0))), 0);
        const minimum = Number(persisted.minimumOrderTotal || 0);
        const finalTotal = roundMoney(Math.max(subtotal - discount, minimum));
        const { rows: paidRows } = await client.query("SELECT COALESCE(SUM(amount),0) AS paid FROM payments WHERE order_id=$1 AND status IN ('paid','partially_paid')", [orderPath[1]]);
        const paid = Number(paidRows[0]?.paid || 0);
        if (orderBalanceConflict({ due: finalTotal, paid })) { await client.query('ROLLBACK'); return json(res, 409, orderBalanceConflictBody({ due: finalTotal, paid })); }
        const remaining = Math.max(0, finalTotal - paid);

        const depletion = await depleteRecipeForOrder(repositories.pool, orderPath[1], venueDbId, req.user?.id, client);
        const { rows } = await client.query('UPDATE orders SET status=$1,closed_at=now(),closed_in_shift_id=$4 WHERE id=$2 AND venue_id=$3 AND status NOT IN (\'closed\',\'cancelled\') RETURNING *', ['closed', orderPath[1], venueDbId, activeShiftId]);
        if (!rows[0]) throw Object.assign(new Error('order_already_final'), { code: 'order_already_final' });
        await client.query('INSERT INTO order_costs (venue_id,order_id,cost) VALUES ($1,$2,$3) ON CONFLICT (order_id) DO UPDATE SET cost=EXCLUDED.cost', [venueDbId, orderPath[1], depletion.totalCost]);
        if (remaining > 0) await client.query('INSERT INTO payments (order_id,method,amount,status,shift_id) VALUES ($1,$2,$3,$4,$5)', [orderPath[1], paymentMethod, remaining, 'paid', activeShiftId]);
        if (persisted.tableId) await client.query(`UPDATE tables t SET status=CASE WHEN EXISTS (SELECT 1 FROM reservations r WHERE r.table_id=$1 AND r.venue_id=$2 AND r.status=\'confirmed\' AND r.starts_at::date=CURRENT_DATE) THEN \'reserved\'::table_status ELSE \'free\'::table_status END FROM zones z WHERE t.id=$1 AND t.zone_id=z.id AND z.venue_id=$2 AND t.status <> \'blocked\'::table_status AND NOT EXISTS (SELECT 1 FROM orders o WHERE o.table_id=$1 AND o.venue_id=$2 AND o.status IN (\'open\',\'in_progress\',\'ready\'))`, [persisted.tableId, venueDbId]);
        result = { ...rows[0], subtotal, discountTotal: discount, finalTotal, paid: paid + remaining, remaining: 0, minimumAdjustment: Math.max(0, minimum - (subtotal - discount)), paymentMethod };
        await client.query('COMMIT');
        // Audit is intentionally emitted after commit so it never describes a rolled-back close.
        recordAudit(req, 'order.closed', 'order', orderPath[1], { status: persisted.status }, result);
      } catch (error) {
        if (client) await client.query('ROLLBACK').catch(() => {});
        if (error.message === 'expired_premix_stock') return json(res, 409, { error: 'expired_premix_stock' }); if (error.message === 'insufficient_recipe_stock') {
          return json(res, 409, { error: 'insufficient_recipe_stock', missing: error.missing });
        }
        if (['product_inventory_mode_required','product_recipe_required','product_recipe_ambiguous','product_inventory_mode_invalid'].includes(error.code || error.message)) return json(res, 409, { error: error.code || error.message, productId: error.productId, productName: error.productName });
        if (['recipe_invalid', 'recipe_ingredient_not_found', 'recipe_ingredient_unit_mismatch', 'invalid_recipe_quantity'].includes(error.code || error.message)) {
          return json(res, 409, { error: error.code || error.message, ingredient: error.ingredient, sourceUnit: error.sourceUnit, targetUnit: error.targetUnit });
        }
        if (error.code === 'order_already_final') {
          return json(res, 409, { error: 'order_already_final' });
        }
        return json(res, 409, { error: 'order_close_failed', detail: error.message });
      } finally {
        client?.release();
      }
      return json(res, 200, result);
    }
    const order = orders.find((entry) => entry.id === orderPath[1]);
    if (!order) return json(res, 404, { error: 'order_not_found' });
    if (['closed', 'cancelled'].includes(order.status)) return json(res, 409, { error: 'order_already_final' });
    const input = await body(req); const paymentMethod = String(input.paymentMethod || 'cash'); if (!['cash', 'card', 'qr'].includes(paymentMethod)) return json(res, 400, { error: 'valid_payment_method_required' });
    const total = orderTotal(order); const discount = approvedDiscountTotal(order.id, total); const minimum = Number(order.minimumOrderTotal || 0);
    const activeShift = shifts.find((shift) => !shift.closedAt); if (!activeShift) return json(res, 409, { error: 'open_shift_required' });
    const closeBalance = memoryOrderBalance(order); if (orderBalanceConflict(closeBalance)) return json(res, 409, orderBalanceConflictBody(closeBalance));
    let depletion; try { depletion = depleteMemoryOrder(order); } catch (error) { if (error.message === 'expired_premix_stock') return json(res, 409, { error: 'expired_premix_stock' }); if (error.message === 'insufficient_recipe_stock') return json(res, 409, { error: 'insufficient_recipe_stock', missing: error.missing }); if (['product_inventory_mode_required','product_recipe_required','product_recipe_ambiguous','product_inventory_mode_invalid'].includes(error.code || error.message)) return json(res, 409, { error: error.code || error.message, productId: error.productId, productName: error.productName }); if (['recipe_invalid', 'recipe_ingredient_not_found', 'recipe_ingredient_unit_mismatch', 'invalid_recipe_quantity'].includes(error.code || error.message)) return json(res, 409, { error: error.code || error.message, ingredient: error.ingredient, sourceUnit: error.sourceUnit, targetUnit: error.targetUnit }); return json(res, 409, { error: 'recipe_depletion_failed', detail: error.message }); }
    order.status = 'closed'; order.closedAt = new Date().toISOString(); order.closedInShiftId = activeShift.id; releaseMemoryTableIfIdle(order.tableId); order.subtotal = total; order.discountTotal = discount; order.finalTotal = roundMoney(Math.max(total - discount, minimum)); order.payments ||= []; const alreadyPaid = receivedOrderPayments(order); const remaining = Math.max(0, order.finalTotal - alreadyPaid); if (remaining > 0) order.payments.push({ id: `pay-${Date.now()}`, method: paymentMethod, amount: remaining, status: 'paid', shiftId: activeShift.id, createdAt: order.closedAt }); order.paid = alreadyPaid + remaining; order.remaining = 0; order.minimumAdjustment = Math.max(0, minimum - (total - discount)); order.paymentMethod = paymentMethod; order.costOfGoods = Number(depletion?.totalCost || 0);
    recordAudit(req, 'order.closed', 'order', order.id, { status: 'open' }, { status: order.status, subtotal: order.subtotal, discountTotal: order.discountTotal, finalTotal: order.finalTotal, minimumAdjustment: order.minimumAdjustment, paymentMethod: order.paymentMethod });
    return json(res, 200, order);
  }
  if (orderPath && req.method === 'POST' && orderPath[2] === 'split') {
    if (denyUnless(req, res, 'orders')) return;
    if (await requireOpenShift(req, res)) return;
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(orderPath[1])) {
      const input = await body(req); const ids = Array.isArray(input.itemIds) ? input.itemIds : [];
      if (!ids.length) return json(res, 400, { error: 'item_ids_required' });
      if (ids.some((id) => typeof id !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) || new Set(ids).size !== ids.length) return json(res, 400, { error: 'invalid_item_ids' });
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        const { rows: sourceRows } = await client.query('SELECT id,venue_id,table_id,reservation_id,guest_id,notes,opened_by,vip_minimum,status FROM orders WHERE id=$1 AND venue_id=$2 FOR UPDATE', [orderPath[1], venueDbId]);
        const source = sourceRows[0]; if (!source) { await client.query('ROLLBACK'); return json(res, 404, { error: 'order_not_found' }); }
        if (!['open', 'in_progress', 'ready'].includes(source.status)) { await client.query('ROLLBACK'); return json(res, 409, { error: 'order_not_editable' }); }
        const { rows: moved } = await client.query('SELECT oi.id,oi.product_id AS "productId",p.name,oi.quantity,oi.unit_price AS "unitPrice",oi.station,oi.status,oi.guest_number AS "guestNumber" FROM order_items oi LEFT JOIN products p ON p.id=oi.product_id WHERE oi.order_id=$1 AND oi.id=ANY($2::uuid[]) FOR UPDATE OF oi', [source.id, ids]);
        if (moved.length !== ids.length) { await client.query('ROLLBACK'); return json(res, 409, { error: 'item_ids_not_in_order' }); }
        const { rows: countRows } = await client.query('SELECT count(*)::int AS count FROM order_items WHERE order_id=$1', [source.id]);
        const { rows: targetRows } = await client.query('INSERT INTO orders (venue_id,table_id,reservation_id,guest_id,notes,opened_by,vip_minimum,status) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id,venue_id AS "venueId",table_id AS "tableId",reservation_id AS "reservationId",guest_id AS "guestId",notes,status,vip_minimum AS "minimumOrderTotal",created_at AS "createdAt"', [source.venue_id, source.table_id, source.reservation_id, source.guest_id, source.notes, source.opened_by, 0, 'open']);
        const target = targetRows[0]; await client.query('UPDATE order_items SET order_id=$1 WHERE id=ANY($2::uuid[]) AND order_id=$3', [target.id, ids, source.id]);
        const balance = await pgOrderBalance(client, source.id, source.vip_minimum);
        if (orderBalanceConflict(balance)) { await client.query('ROLLBACK'); return json(res, 409, orderBalanceConflictBody(balance)); }
        if (moved.length >= countRows[0].count) { await client.query('ROLLBACK'); return json(res, 409, { error: 'split_requires_remaining_item' }); }
        await client.query('COMMIT');
        const result = { ...target, items: moved, splitFrom: source.id }; recordAudit(req, 'order.split', 'order', source.id, { itemCount: moved.length }, { itemCount: moved.length, newOrderId: target.id }); return json(res, 201, result);
      } catch (error) { await client.query('ROLLBACK'); return json(res, 409, { error: 'order_split_failed', detail: error.message }); } finally { client.release(); }
    }
    const source = orders.find((entry) => entry.id === orderPath[1]);
    if (!source) return json(res, 404, { error: 'order_not_found' });
    if (!['open', 'in_progress', 'ready'].includes(source.status)) return json(res, 409, { error: 'order_not_editable' });
    const input = await body(req); const requested = Array.isArray(input.itemIds) ? input.itemIds : [];
    if (!requested.length) return json(res, 400, { error: 'item_ids_required' });
    if (requested.some((id) => typeof id !== 'string' || !id.trim()) || new Set(requested).size !== requested.length) return json(res, 400, { error: 'invalid_item_ids' });
    const ids = new Set(requested); const moved = source.items.filter((item) => ids.has(item.id));
    if (moved.length !== requested.length) return json(res, 409, { error: 'item_ids_not_in_order' });
    const beforeItems = source.items; source.items = source.items.filter((item) => !ids.has(item.id));
    const balance = memoryOrderBalance(source); if (orderBalanceConflict(balance)) { source.items = beforeItems; return json(res, 409, orderBalanceConflictBody(balance)); }
    if (moved.length >= beforeItems.length) { source.items = beforeItems; return json(res, 409, { error: 'split_requires_remaining_item' }); }
    const target = { id: `ord-${Date.now()}`, tableId: source.tableId, status: 'open', items: moved, clientId: source.clientId || null, guestName: source.guestName || null, guestPhone: source.guestPhone || null, notes: source.notes || '', openedBy: source.openedBy || source.openedById || null, splitFrom: source.id, createdAt: new Date().toISOString() };
    orders.push(target); recordAudit(req, 'order.split', 'order', source.id, { itemCount: source.items.length + moved.length }, { itemCount: source.items.length, newOrderId: target.id }); return json(res, 201, target);
  }
  if (orderPath && req.method === 'POST' && orderPath[2] === 'discount-requests') {
    if (denyUnless(req, res, 'orders')) return;
    if (await requireOpenShift(req, res)) return;
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(orderPath[1])) {
      const input = await body(req); const type = String(input.type || 'percent'); const value = Number(input.value); const reason = String(input.reason || '').trim(); if (!reason || !Number.isFinite(value) || value <= 0 || type !== 'percent' || value > 100 || reason.length > 500) return json(res, 400, { error: 'invalid_discount_request' });
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        const { rows: stateRows } = await client.query('SELECT status FROM orders WHERE id=$1 AND venue_id=$2 FOR UPDATE', [orderPath[1], venueDbId]);
        if (!stateRows[0]) { await client.query('ROLLBACK'); return json(res, 404, { error: 'order_not_found' }); }
        if (['closed', 'cancelled'].includes(stateRows[0].status)) { await client.query('ROLLBACK'); return json(res, 409, { error: 'order_already_final' }); }
        const { rows: duplicateRows } = await client.query("SELECT id FROM discounts WHERE order_id=$1 AND status='requested' LIMIT 1", [orderPath[1]]);
        if (duplicateRows[0]) { await client.query('ROLLBACK'); return json(res, 409, { error: 'discount_request_pending' }); }
        const requestedBy = /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : '20000000-0000-0000-0000-000000000001';
        const { rows } = await client.query("INSERT INTO discounts (order_id,requested_by,type,value,reason,status,approved_by,decided_at) VALUES ($1,$2,$3,$4,$5,'requested',NULL,NULL) RETURNING id,order_id AS \"orderId\",type,value,reason,status,requested_by AS \"requestedBy\",approved_by AS \"approvedBy\",created_at AS \"createdAt\",decided_at AS \"decidedAt\"", [orderPath[1], requestedBy, type, value, reason]);
        await client.query('COMMIT');
        recordAudit(req, 'discount.applied_by_staff', 'discount', rows[0].id, null, { ...rows[0], notificationRecipients: ['owner', 'admin'] });
        return json(res, 201, { ...rows[0], notificationRecipients: ['owner', 'admin'] });
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'discount_create_failed', detail: error.message }); } finally { client.release(); }
    }
    const order = orders.find((entry) => entry.id === orderPath[1]); const input = await body(req);
    if (!order) return json(res, 404, { error: 'order_not_found' }); if (['closed', 'cancelled'].includes(order.status)) return json(res, 409, { error: 'order_already_final' });
    const type = String(input.type || 'percent'); const value = Number(input.value); const reason = String(input.reason || '').trim(); if (!reason || !Number.isFinite(value) || value <= 0 || type !== 'percent' || value > 100 || reason.length > 500) return json(res, 400, { error: 'invalid_discount_request' }); if (discountRequests.some((entry) => entry.orderId === order.id && entry.status === 'requested')) return json(res, 409, { error: 'discount_request_pending' });
    const request = { id: `disc-${crypto.randomUUID()}`, venueId: notificationVenueScope(req, venueDbId), orderId: order.id, type, value, reason, guestName: order.guestName || null, guestPhone: order.guestPhone || null, status: 'requested', requestedBy: req.user?.id || req.user?.name || 'unknown', createdAt: new Date().toISOString(), notificationRecipients: ['owner', 'admin'] };
    discountRequests.push(request); recordAudit(req, 'discount.applied_by_staff', 'discount', request.id, null, request); return json(res, 201, request);
  }
  if (pathname === '/api/discount-requests' && req.method === 'GET') {
    if (denyUnlessAny(req, res, ['finance', 'finance_read'])) return;
    if (repositories?.pool) { try { const { rows } = await repositories.pool.query('SELECT d.id,d.order_id AS "orderId",d.type,d.value,d.reason,d.status,d.requested_by AS "requestedBy",d.approved_by AS "approvedBy",d.created_at AS "createdAt",d.decided_at AS "decidedAt",g.full_name AS "guestName",g.phone AS "guestPhone" FROM discounts d JOIN orders o ON o.id=d.order_id LEFT JOIN guests g ON g.id=o.guest_id WHERE o.venue_id=$1 ORDER BY d.created_at DESC', [venueDbId]); return json(res, 200, { items: rows }); } catch (error) { return json(res, 503, { error: 'database_unavailable' }); } }
    return json(res, 200, { items: discountRequests });
  }
  const decision = pathname.match(/^\/api\/discount-requests\/([^/]+)\/(approve|reject)$/);
  if (decision && req.method === 'POST') {
    if (denyUnless(req, res, 'finance')) return;
    if (repositories?.pool && /^[0-9a-f-]{36}$/i.test(decision[1])) {
      const input = await body(req); const status = decision[2] === 'approve' ? 'approved' : 'rejected'; const decidedBy = /^[0-9a-f-]{36}$/i.test(req.user?.id || '') ? req.user.id : '20000000-0000-0000-0000-000000000001';
      const client = await repositories.pool.connect();
      try {
        await client.query('BEGIN');
        const { rows: discountRows } = await client.query('SELECT order_id FROM discounts WHERE id=$1', [decision[1]]);
        if (!discountRows[0]) { await client.query('ROLLBACK'); return json(res, 409, { error: 'discount_not_found_or_decided' }); }
        const { rows: orderRows } = await client.query('SELECT id,status,vip_minimum AS "minimumOrderTotal" FROM orders WHERE id=$1 AND venue_id=$2 FOR UPDATE', [discountRows[0].order_id, venueDbId]);
        if (!orderRows[0] || ['closed', 'cancelled'].includes(orderRows[0].status)) { await client.query('ROLLBACK'); return json(res, 409, { error: 'discount_not_found_or_decided' }); }
        const { rows } = await client.query(`UPDATE discounts SET status=$1,approved_by=$2,decided_at=now() WHERE id=$3 AND status=$4 AND order_id=$5 RETURNING id,order_id AS "orderId",type,value,reason,status,requested_by AS "requestedBy",approved_by AS "approvedBy",created_at AS "createdAt",decided_at AS "decidedAt"`, [status, decidedBy, decision[1], 'requested', orderRows[0].id]);
        if (!rows[0]) { await client.query('ROLLBACK'); return json(res, 409, { error: 'discount_not_found_or_decided' }); }
        if (status === 'approved') { const balance = await pgOrderBalance(client, orderRows[0].id, orderRows[0].minimumOrderTotal); if (orderBalanceConflict(balance)) { await client.query('ROLLBACK'); return json(res, 409, orderBalanceConflictBody(balance)); } }
        await client.query('COMMIT');
        recordAudit(req, `discount.${status}`, 'discount', rows[0].id, { status: 'requested' }, rows[0]); return json(res, 200, rows[0]);
      } catch (error) { await client.query('ROLLBACK').catch(() => {}); return json(res, 409, { error: 'discount_decision_failed', detail: error.message }); } finally { client.release(); }
    }
    const request = discountRequests.find((entry) => entry.id === decision[1]);
    if (!request) return json(res, 404, { error: 'discount_not_found' });
    if (request.status !== 'requested') return json(res, 409, { error: 'already_decided' });
    const input = await body(req); const before = { ...request }; request.status = decision[2] === 'approve' ? 'approved' : 'rejected';
    const targetOrder = orders.find((entry) => entry.id === request.orderId);
    if (!targetOrder || ['closed', 'cancelled'].includes(targetOrder.status)) { request.status = before.status; return json(res, 409, { error: 'discount_not_found_or_decided' }); }
    if (request.status === 'approved') { const balance = memoryOrderBalance(targetOrder); if (orderBalanceConflict(balance)) { request.status = before.status; return json(res, 409, orderBalanceConflictBody(balance)); } }
    request.decidedBy = req.user?.id || req.user?.name || 'unknown'; request.decidedAt = new Date().toISOString(); recordAudit(req, `discount.${request.status}`, 'discount', request.id, before, request);
    return json(res, 200, request);
  }
  return null;
}

function staticFile(req, res) {
  const requestUrl = new URL(req.url, 'http://localhost');
  let requestPath = requestUrl.pathname;
  const routePath = requestPath.length > 1 ? requestPath.replace(/\/+$/, '') : requestPath;
  const aliases = { '/': '/index.html', '/admin': '/admin.html', '/login': '/login.html', '/inventory': '/inventory.html', '/finance': '/finance.html', '/finance/categories': '/finance-categories.html', '/finance/report': '/finance-report.html', '/reservations': '/reservations.html', '/clients': '/clients.html', '/orders': '/orders.html', '/integrations': '/integrations.html', '/network': '/network.html', '/delivery': '/delivery.html', '/platform': '/platform.html' };
  const canonicalByFile = Object.fromEntries(Object.entries(aliases).map(([canonical, file]) => [file, canonical]));
  // Keep one public URL per page. Direct HTML filenames are implementation
  // details and redirect to the canonical tree so links, history and analytics
  // never split across duplicate addresses.
  if (canonicalByFile[routePath] && routePath !== canonicalByFile[routePath]) {
    const canonical = canonicalByFile[routePath];
    const location = `${canonical}${requestUrl.search}`;
    res.writeHead(308, { Location: location, 'Cache-Control': 'no-store' });
    return res.end();
  }
  requestPath = aliases[routePath] || requestPath;
  // Only browser runtime files are public. Never expose the project directory.
  const publicFiles = new Set([
    '/phone-format.js',
    ...Object.values(aliases), '/style.css', '/platform.css', '/app.js', '/portal.js', '/header-shell.js', '/admin.js',
    '/login.js', '/platform.js', '/catalog-seed.js', '/lock.js', '/staff-profile.js', '/staff-audit.js',
    '/staff-phone-fields.js', '/staff-sensitive-fields.js', '/staff-admin-card.js',
    '/purchase-document-validation.js', '/notification-center.js', '/audit-privacy.js', '/staff-identity.js',
    '/staff-telegram-link.js', '/vip-deposit.js', '/vip-deposit-ui.js',
    '/assets/tabler-icons.svg', '/assets/login-hookah-reference.jpg', '/assets/login-smoke-ambient.png', '/assets/login-smoke-ambient.mp4', '/auth-smoke.css', '/auth-smoke.js',
    '/assets/brand/hookah-pos-lockup.svg', '/assets/brand/hookah-pos-symbol.svg',
    ...[400, 500, 600, 700, 800].map(weight => `/assets/fonts/manrope-${weight}.ttf`)
  ]);
  const isBrandAsset = requestPath.startsWith('/assets/brand/');
  if (!publicFiles.has(requestPath) && !isBrandAsset) { res.writeHead(404); return res.end('Not found'); }
  if (!['GET', 'HEAD'].includes(req.method)) { res.writeHead(405, { Allow: 'GET, HEAD' }); return res.end(); }
  const localPreviewFiles = {};
  const file = path.resolve(root, localPreviewFiles[requestPath] || `.${requestPath}`);
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404); return res.end('Not found'); }
  const relative = path.relative(fs.realpathSync(root), fs.realpathSync(file));
  if (relative.startsWith('..') || path.isAbsolute(relative)) { res.writeHead(404); return res.end('Not found'); }
  const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'application/javascript', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.mp4': 'video/mp4', '.ttf': 'font/ttf' };
  const isVideo = path.extname(file) === '.mp4';
  const headers = { 'Content-Type': isVideo ? 'video/mp4' : `${types[path.extname(file)] || 'application/octet-stream'}; charset=utf-8`, 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'strict-origin-when-cross-origin' };
  if (isVideo) {
    const size = fs.statSync(file).size;
    headers['Accept-Ranges'] = 'bytes';
    headers['Content-Length'] = String(size);
    const range = req.headers.range;
    if (range && req.method === 'GET') {
      const match = /^bytes=(\d*)-(\d*)$/.exec(range);
      if (!match || (!match[1] && !match[2])) {
        res.writeHead(416, { ...headers, 'Content-Length': '0', 'Content-Range': `bytes */${size}` });
        return res.end();
      }
      const start = match[1] ? Number(match[1]) : Math.max(0, size - Number(match[2]));
      const end = match[1] ? (match[2] ? Number(match[2]) : size - 1) : size - 1;
      if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start > end || start >= size) {
        res.writeHead(416, { ...headers, 'Content-Length': '0', 'Content-Range': `bytes */${size}` });
        return res.end();
      }
      const last = Math.min(end, size - 1);
      headers['Content-Range'] = `bytes ${start}-${last}/${size}`;
      headers['Content-Length'] = String(last - start + 1);
      res.writeHead(206, headers);
      return fs.createReadStream(file, { start, end: last }).pipe(res);
    }
  }
  // The login document contains the initial setup form as a hidden alternative;
  // never let a browser keep an older first-run document after a local release.
  if (requestPath === '/login.html') headers['Cache-Control'] = 'no-store';
  res.writeHead(200, headers);
  return res.end(req.method === 'HEAD' ? undefined : fs.readFileSync(file));
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.url.startsWith('/api/')) { const result = await api(req, res); if (result !== null) return result; }
    return staticFile(req, res);
  } catch (error) { return json(res, 500, { error: 'internal_error', message: error.message }); }
});
server.listen(process.env.PORT || 3000, process.env.HOST || undefined, () => console.log(`CRM running on http://localhost:${server.address().port}`));







