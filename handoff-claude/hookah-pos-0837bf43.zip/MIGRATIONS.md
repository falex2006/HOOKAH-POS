# Миграция PostgreSQL

1. Создать базу и пользователя из `.env`.
2. Применить `schema.sql` одним запуском.
3. Применить `seed.sql` только для тестовой площадки.
4. Проверить индексы и healthcheck CRM.
5. Для production использовать отдельные миграции и резервную копию перед изменением схемы.
6. Для существующей базы применить `migrations/001_auth_sessions.sql` перед включением persistent sessions.

Пример для контейнера:

```bash
docker compose up -d db
# init scripts из /docker-entrypoint-initdb.d выполняются автоматически на новом томе
```

Для существующего тома:

```bash
docker compose exec -T db psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" < migrations/001_auth_sessions.sql
```

Либо использовать подготовленный `./migrate-vps.sh`: он дождётся готовности PostgreSQL и применит все SQL-файлы из `migrations/`.

Проверку остановки и повтора оболочки runner можно выполнить командой `bash scripts/migrate-vps-runner-qa.sh`. Она использует временные SQL-файлы и подмену Docker/psql, не подключается к базе и не доказывает откат транзакции PostgreSQL.

Миграция `006_guest_venue_phone_unique.sql` переводит уникальность телефона гостя на составной ключ точки и телефона для сетевого режима.

Миграция `011_user_preferences.sql` добавляет JSON-поле персональных настроек аккаунта: таймер блокировки рабочего места и настройки отображения главной/аналитики. Она безопасна для повторного запуска через `ADD COLUMN IF NOT EXISTS`.
